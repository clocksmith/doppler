"""Bootstrap a self-hosting Sprout -> JavaScript/WGSL compiler.

Executed by ../build.py. The generated compiler never imports this builder.
Sprout is structured register assembly. Compiled outputs contain direct host
statements; they do not interpret Sprout at runtime.
"""
OPS = ['nop','set','mov','add','sub','mul','div','mod','eq','lt','data','input','put','decimal','while','end','if','else','fi']
OPNUM={name:i for i,name in enumerate(OPS)}
JS_OP=[
';\n','r[~a]=~b;\n','r[~a]=r[~b];\n','r[~a]=(r[~b]+r[~c])>>>0;\n',
'r[~a]=(r[~b]-r[~c])>>>0;\n','r[~a]=Math.imul(r[~b],r[~c])>>>0;\n',
'r[~a]=Math.floor(r[~b]/r[~c])>>>0;\n','r[~a]=(r[~b]%r[~c])>>>0;\n',
'r[~a]=Number(r[~b]===r[~c]);\n','r[~a]=Number(r[~b]<r[~c]);\n',
'r[~a]=at(P,r[~b]);\n','r[~a]=at(input,r[~b]);\n','put(r[~a]);\n','decimal(r[~a]);\n',
'while(r[~a]!==0){\n','}\n','if(r[~a]!==0){\n','}else{\n','}\n']
WG_OP=[
'{}\n','r[~a]=~bu;\n','r[~a]=r[~b];\n','r[~a]=r[~b]+r[~c];\n',
'r[~a]=r[~b]-r[~c];\n','r[~a]=r[~b]*r[~c];\n',
'r[~a]=safe_div(r[~b],r[~c]);\n','r[~a]=safe_mod(r[~b],r[~c]);\n',
'r[~a]=select(0u,1u,r[~b]==r[~c]);\n','r[~a]=select(0u,1u,r[~b]<r[~c]);\n',
'r[~a]=data_at(r[~b]);\n','r[~a]=input_at(r[~b]);\n','put(r[~a]);\n','decimal(r[~a]);\n',
'while(r[~a]!=0u){\n','}\n','if(r[~a]!=0u){\n','}else{\n','}\n']

JS_VALIDATE=r'''function at(a, i) { return i < a.length ? a[i] : 0; }
function validateProgram(p) {
  if (!p || p.length < 3 || p.length > 60000 || p[0] !== 21331 || p[2] % 4 || p.length !== 3+p[1]+p[2]) throw new Error("Invalid Sprout header.");
  if (Array.from(p).some(n => !Number.isSafeInteger(n) || n < 0 || n > 4294967295)) throw new Error("Sprout words must be u32.");
  const stack = [];
  for (let pc = 3+p[1]; pc < p.length; pc += 4) {
    const [op,a,b,c] = Array.from(p.slice(pc,pc+4));
    if (op > 18 || a >= 64 || (op >= 2 && op <= 11 && b >= 64) || (op >= 3 && op <= 9 && c >= 64)) throw new Error("Invalid Sprout instruction.");
    if (op === 14 || op === 16) stack.push(op);
    if (op === 15 && stack.pop() !== 14) throw new Error("Unbalanced while.");
    if (op === 17) { if (stack.pop() !== 16) throw new Error("Unbalanced else."); stack.push(17); }
    if (op === 18 && ![16,17].includes(stack.pop())) throw new Error("Unbalanced if.");
    if (stack.length > 64) throw new Error("Control nesting is too deep.");
  }
  if (stack.length) throw new Error("Unclosed control block.");
}'''

JS_PARTS=[
'(() => {\n"use strict";\nconst PROGRAM_LENGTH = ',
';\nconst P = Object.freeze([',
']);\n'+JS_VALIDATE+r'''
function execute(input = P, target = 0) {
  validateProgram(input);
  if (target !== 0 && target !== 1) throw new Error("Use target 0 (JS) or 1 (WGSL).");
  const r = new Uint32Array(64);
  r[0] = target; r[1] = input.length;
  const output = [];
  const put = c => { if (c > 127 || output.length >= 262143) throw new Error("Invalid or oversized compiler output."); output.push(c); };
  const decimal = n => { for (const c of String(n >>> 0)) put(c.charCodeAt(0)); };
''',
r'''  return new TextDecoder().decode(Uint8Array.from(output));
}
'''+HOST+PRINT_JS+r'''
const api = { id: "compiler", program: P, execute, self: () => execute(P, 0), wgsl: () => execute(P, 1),
  compile: (program, target = "js") => execute(program, target === "js" ? 0 : target === "wgsl" ? 1 : -1),
  run: (target = "js", input = null) => {
    if (!["js", "wgsl"].includes(target)) throw new Error("Use js or wgsl.");
    if (input !== null) validateProgram(input);
    return withDevice(device => dispatchText(device, execute(P, 1), "main", { TARGET: target === "js" ? 0 : 1, EXTERNAL: input === null ? 0 : 1 }, input ?? []));
  }
};
const DEFAULT_GPU = false;
'''+AUTORUN+'\n})();\n'
]

WG_RUNTIME=r'''override TARGET: u32 = 1u;
override EXTERNAL: u32 = 0u;
@group(0) @binding(0) var<storage, read_write> output: array<u32>;
@group(0) @binding(1) var<storage, read> supplied: array<u32>;
var<private> cursor: u32 = 1u;
var<private> bad: bool = false;
fn put(c: u32) {
  if (c > 127u || cursor >= arrayLength(&output)) { bad = true; return; }
  output[cursor] = c; cursor += 1u;
}
fn decimal(n: u32) {
  var divisor = 1u;
  while (n / divisor >= 10u) { divisor *= 10u; }
  var value = n;
  loop {
    put(48u + value / divisor); value %= divisor;
    if (divisor == 1u) { break; }
    divisor /= 10u;
  }
}
fn data_at(i: u32) -> u32 { if (i >= PROGRAM_LENGTH) { return 0u; } return P[i]; }
fn input_length() -> u32 { if (EXTERNAL == 0u) { return PROGRAM_LENGTH; } return supplied[0]; }
fn input_at(i: u32) -> u32 {
  if (EXTERNAL == 0u) { return data_at(i); }
  if (i >= supplied[0] || i + 1u >= arrayLength(&supplied)) { return 0u; }
  return supplied[i + 1u];
}
fn safe_div(a: u32, b: u32) -> u32 { if (b == 0u) { return 0u; } return a / b; }
fn safe_mod(a: u32, b: u32) -> u32 { if (b == 0u) { return 0u; } return a % b; }
fn valid_input() -> bool {
  let n = input_length();
  if (TARGET > 1u || n < 3u || n > 60000u || input_at(0u) != 21331u) { return false; }
  if (EXTERNAL != 0u && n >= arrayLength(&supplied)) { return false; }
  let data_length = input_at(1u); let code_length = input_at(2u);
  if (data_length > n || code_length > n || code_length % 4u != 0u || 3u + data_length + code_length != n) { return false; }
  var stack: array<u32, 64>;
  var depth = 0u;
  for (var pc = 3u + data_length; pc < n; pc += 4u) {
    let op = input_at(pc); let a = input_at(pc+1u); let b = input_at(pc+2u); let c = input_at(pc+3u);
    if (op > 18u || a >= 64u || (op >= 2u && op <= 11u && b >= 64u) || (op >= 3u && op <= 9u && c >= 64u)) { return false; }
    if (op == 14u || op == 16u) {
      if (depth == 64u) { return false; }
      stack[depth] = op; depth += 1u;
    } else if (op == 15u) {
      if (depth == 0u) { return false; } depth -= 1u;
      if (stack[depth] != 14u) { return false; }
    } else if (op == 17u) {
      if (depth == 0u || stack[depth-1u] != 16u) { return false; }
      stack[depth-1u] = 17u;
    } else if (op == 18u) {
      if (depth == 0u) { return false; } depth -= 1u;
      if (stack[depth] != 16u && stack[depth] != 17u) { return false; }
    }
  }
  return depth == 0u;
}
@compute @workgroup_size(1)
fn main() {
  if (!valid_input()) { output[0] = 0u; return; }
  var r: array<u32, 64>;
  r[0] = TARGET; r[1] = input_length();
'''
WG_PARTS=['const PROGRAM_LENGTH = ', 'u;\nconst P = array<u32, PROGRAM_LENGTH>(', ');\n'+WG_RUNTIME, '  output[0] = select(cursor - 1u, 0u, bad);\n}\n']

# The compiler's own embedded data consists only of generic code-emission
# templates. It also includes its Sprout instructions, compiled below.
ALL_TABLES=JS_PARTS+WG_PARTS+JS_OP+WG_OP
DESC_WORDS=2*len(ALL_TABLES)
data=[0]*DESC_WORDS
for index,text in enumerate(ALL_TABLES):
    data[2*index]=3+len(data)
    data[2*index+1]=len(text)
    data.extend(text.encode('ascii'))

code=[]
listing=[]
def ins(op,a=0,b=0,c=0):
    code.extend([OPNUM[op],a,b,c]); listing.append(f'{op} {a} {b} {c}')
def note(text): listing.append('; '+text)

# Registers: 0 target; 1 source length; 2 constant zero; 3 constant one;
# 4 wrapper descriptor base; 5 table address; 6 text pointer; 7 length;
# 8 index; 9 condition; 10 character; 11 temporary; 12 operation-table base;
# 13 input PC; 14 opcode; 15/16/17 operands; 18 loop condition; 19 marker flag;
# 20 marker code 126; 21 etc constants.
ins('set',2,0); ins('set',3,1); ins('set',20,126)
ins('set',21,2); ins('set',22,4); ins('set',23,8)
# descriptor base = 3 + target*8
ins('mul',4,0,23); ins('set',11,3); ins('add',4,4,11)
# opcode descriptor base = 3 + 16 + target*(2*OP_COUNT)
ins('set',11,2*len(OPS)); ins('mul',12,0,11); ins('set',11,19); ins('add',12,12,11)

def emit_piece(k):
    note(f'Emit backend wrapper part {k}')
    ins('set',11,2*k); ins('add',5,4,11)
    ins('data',6,5); ins('add',5,5,3); ins('data',7,5)
    ins('set',8,0); ins('lt',9,8,7); ins('while',9)
    ins('add',11,6,8); ins('data',10,11); ins('put',10)
    ins('add',8,8,3); ins('lt',9,8,7); ins('end')

emit_piece(0)
note('Emit source length and the opening of its numeric literal')
ins('decimal',1)
emit_piece(1)
note('Quote the source program as comma-separated unsigned integers')
ins('set',8,0); ins('lt',9,8,1); ins('while',9)
ins('if',8); ins('set',10,44); ins('put',10); ins('fi')
ins('input',10,8); ins('decimal',10)
ins('add',8,8,3); ins('lt',9,8,1); ins('end')
emit_piece(2)
note('Compile each structured register instruction into direct host statements')
ins('set',11,1); ins('input',13,11); ins('set',11,3); ins('add',13,13,11)
ins('lt',18,13,1); ins('while',18)
ins('input',14,13)
for delta,register in [(1,15),(2,16),(3,17)]:
    ins('set',11,delta); ins('add',11,13,11); ins('input',register,11)
ins('mul',5,14,21); ins('add',5,12,5)
ins('data',6,5); ins('add',5,5,3); ins('data',7,5)
ins('set',8,0); ins('lt',9,8,7); ins('while',9)
ins('add',11,6,8); ins('data',10,11)
ins('eq',19,10,20); ins('if',19)
ins('add',8,8,3); ins('add',11,6,8); ins('data',10,11)
for char,register in [('a',15),('b',16),('c',17)]:
    ins('set',11,ord(char)); ins('eq',19,10,11); ins('if',19); ins('decimal',register); ins('fi')
ins('else'); ins('put',10); ins('fi')
ins('add',8,8,3); ins('lt',9,8,7); ins('end')
ins('add',13,13,22); ins('lt',18,13,1); ins('end')
emit_piece(3)
PROGRAM=[21331,len(data),len(code)]+data+code
assert len(PROGRAM)<60000

def bootstrap_compile(p,target):
    parts=JS_PARTS if target==0 else WG_PARTS
    templates=JS_OP if target==0 else WG_OP
    body=[]
    for pc in range(3+p[1],len(p),4):
        op,a,b,c=p[pc:pc+4]
        s=templates[op].replace('~a',str(a)).replace('~b',str(b)).replace('~c',str(c))
        body.append(s)
    return parts[0]+str(len(p))+parts[1]+numbers(p)+parts[2]+''.join(body)+parts[3]

(ROOT/'quines/05-compiler.js').write_text(bootstrap_compile(PROGRAM,0))
(ROOT/'quines/05-compiler.wgsl').write_text(bootstrap_compile(PROGRAM,1))
(ROOT/'compiler/compiler-program.json').write_text(json.dumps(PROGRAM,separators=(',',':'))+'\n')
(ROOT/'compiler/compiler.sprout').write_text('; Self-hosted compiler: generic backend templates are embedded data.\n.data\n'+'\n'.join(numbers(data[i:i+32]).replace(',',' ') for i in range(0,len(data),32))+'\n.code\n'+'\n'.join(listing)+'\n')

# Other programs prove the compiler is not merely a fixed-point string emitter.
examples={
'fibonacci': ([],[('set',2,20),('set',3,0),('set',4,1),('set',5,1),('while',2),('add',6,3,4),('mov',3,4),('mov',4,6),('sub',2,2,5),('end',),('decimal',3),('set',7,10),('put',7)],'6765\n'),
'factorial': ([],[('set',2,10),('set',3,1),('set',4,1),('while',2),('mul',3,3,2),('sub',2,2,4),('end',),('decimal',3),('set',7,10),('put',7)],'3628800\n'),
'hello': (list(b'Hello from Sprout!\n'),[('set',2,3),('set',3,22),('set',4,1),('lt',5,2,3),('while',5),('data',6,2),('put',6),('add',2,2,4),('lt',5,2,3),('end',)],'Hello from Sprout!\n'),
'branch': ([],[('set',2,7),('set',3,7),('eq',4,2,3),('if',4),('set',5,89),('else',),('set',5,78),('fi',),('put',5),('set',5,10),('put',5)],'Y\n'),
'overflow': ([],[('set',2,4294967295),('set',3,1),('add',4,2,3),('decimal',4),('set',5,10),('put',5)],'0\n')
}
# end address for embedded hello bytes is derived rather than guessed
hello_data,hello_ops,hello_expected=examples['hello']
hello_ops[1]=('set',3,3+len(hello_data))
example_manifest=[]
for name,(sample_data,instructions,expected) in examples.items():
    sample_code=[]
    lines=[]
    for instruction in instructions:
        op,*args=instruction; args=(args+[0,0,0])[:3]
        sample_code.extend([OPNUM[op],*args]); lines.append(op+' '+' '.join(map(str,args)))
    p=[21331,len(sample_data),len(sample_code)]+sample_data+sample_code
    (ROOT/f'compiler/{name}.json').write_text(json.dumps(p,separators=(',',':'))+'\n')
    (ROOT/f'compiler/{name}.sprout').write_text('.data\n'+numbers(sample_data).replace(',',' ')+'\n.code\n'+'\n'.join(lines)+'\n')
    (ROOT/f'compiler/{name}.js').write_text(bootstrap_compile(p,0))
    (ROOT/f'compiler/{name}.wgsl').write_text(bootstrap_compile(p,1))
    example_manifest.append({'name':name,'expected':expected})
(ROOT/'compiler/examples.json').write_text(json.dumps(example_manifest,indent=2)+'\n')
print(f'Sprout compiler: {len(PROGRAM):,} words; {len(code)//4} instructions; {len(data):,} data words')
