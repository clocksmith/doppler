# Sprout

Sprout is a small structured register language designed so its compiler can itself
be expressed in the language. It is not JavaScript or WGSL syntax.

There are 64 unsigned 32-bit registers, initially zero except:

- r0: compiler target, 0 for JavaScript, 1 for WGSL.
- r1: supplied input program's word count. Input defaults to the embedded program.

Every instruction is four u32 words: `[opcode, a, b, c]`. Unused operands are zero.
The readable form uses instruction names and decimal operands. `.data` introduces
embedded u32 data, `.code` introduces instructions, and `;` starts a comment.
The numeric form is `[21331, data_word_count, code_word_count, ...data, ...code]`.
Code length is measured in words, not instructions.

| Code | Instruction | Meaning |
|---:|---|---|
| 0 | `nop` | No operation |
| 1 | `set a b` | r[a] = immediate b |
| 2 | `mov a b` | r[a] = r[b] |
| 3 | `add a b c` | r[a] = r[b] + r[c], modulo 2^32 |
| 4 | `sub a b c` | r[a] = r[b] - r[c], modulo 2^32 |
| 5 | `mul a b c` | r[a] = r[b] * r[c], modulo 2^32 |
| 6 | `div a b c` | Unsigned integer quotient, zero when divisor is zero |
| 7 | `mod a b c` | Remainder, zero when divisor is zero |
| 8 | `eq a b c` | r[a] = 1 when r[b] equals r[c], otherwise zero |
| 9 | `lt a b c` | r[a] = 1 when r[b] is less than r[c], otherwise zero |
| 10 | `data a b` | r[a] = embedded program[r[b]] |
| 11 | `input a b` | r[a] = supplied input program[r[b]] |
| 12 | `put a` | Write ASCII byte r[a] |
| 13 | `decimal a` | Write r[a] as unsigned decimal ASCII |
| 14 | `while a` | While r[a] is nonzero; the body must update its condition |
| 15 | `end` | Close a while block |
| 16 | `if a` | Enter when r[a] is nonzero |
| 17 | `else` | Alternative branch |
| 18 | `fi` | Close an if block |

`data` is an explicit embedded-data read, not reflection on the running JS/WGSL
source file. The compiled compiler's embedded data includes its original Sprout
source. A normal compiled program's embedded data includes that normal program.
`input` lets the compiler receive another program without replacing its own
code-generation tables.

No user-defined functions, arbitrary strings, recursion, indirect jumps, or
floating-point arithmetic are claimed. The compiler emits direct statements and
structured loops/branches. The generated wrapper supplies standard byte and
number output, input access, bounds checks, and u32 storage.

Programs have a maximum of 60,000 words and 64 nested control blocks. Output is
limited by the execution buffer (the supplied runner allows at most 262,143 ASCII
bytes). Invalid inputs fail. These are finite implementation limits, not claims
about unbounded self-replication.

The language can express nonterminating loops. The public demo runs only bundled
programs. The Node compiler driver emits code but does not automatically execute
untrusted output. Do not treat GPU timeouts or JavaScript workers as a security
sandbox.

## Fibonacci

```text
.data
.code
set 2 20
set 3 0
set 4 1
set 5 1
while 2
add 6 3 4
mov 3 4
mov 4 6
sub 2 2 5
end
decimal 3
set 7 10
put 7
```

This emits `6765` and a newline. The same compiler produces both the JavaScript
and WGSL implementations.
