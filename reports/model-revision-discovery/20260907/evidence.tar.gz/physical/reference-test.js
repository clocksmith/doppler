import assert from 'node:assert/strict';

const { probeNodeGPU } = await import('../helpers/gpu-probe.js');
const { acquireBuffer, uploadData, readBuffer, releaseBuffer } = await import('../../src/memory/buffer-pool.js');
const { createTensor } = await import('../../src/gpu/tensor.js');
const { destroyDevice } = await import('../../src/gpu/device.js');
const { runLinearAttentionCoreGPU } = await import('../../src/gpu/kernels/linear-attention-core.js');
const { CommandRecorder } = await import('../../src/gpu/command-recorder.js');
const { float16ToFloat32, float32ToFloat16 } = await import('../../src/converter/quantizer.js');
const { setRuntimeConfig, resetRuntimeConfig } = await import('../../src/config/runtime.js');

function silu(x) {
  return x / (1 + Math.exp(-x));
}

function softplus(x) {
  if (x > 20) return x;
  if (x < -20) return Math.exp(x);
  return Math.log(1 + Math.exp(x));
}

function assertArraysClose(actual, expected, tolerance, label) {
  assert.equal(actual.length, expected.length, `${label} length mismatch`);
  for (let i = 0; i < actual.length; i += 1) {
    const delta = Math.abs(actual[i] - expected[i]);
    assert.ok(
      delta <= tolerance,
      `${label}[${i}] mismatch: actual=${actual[i]} expected=${expected[i]} delta=${delta} tolerance=${tolerance}`
    );
  }
}

function buildReferenceOutput({ qkv, z, a, b, layerState, numTokens, qkL2NormEps }) {
  const convState = new Float32Array(layerState.convState);
  const recurrentState = new Float32Array(layerState.recurrentState);
  const convOut = new Float32Array(numTokens * layerState.convDim);
  const output = new Float32Array(numTokens * layerState.valueDim);

  for (let channel = 0; channel < layerState.convDim; channel += 1) {
    const stateBase = channel * layerState.convKernelSize;
    for (let tokenIdx = 0; tokenIdx < numTokens; tokenIdx += 1) {
      const newest = qkv[tokenIdx * layerState.convDim + channel];
      for (let k = 0; k + 1 < layerState.convKernelSize; k += 1) {
        convState[stateBase + k] = convState[stateBase + k + 1];
      }
      convState[stateBase + layerState.convKernelSize - 1] = newest;

      let mixed = 0;
      for (let k = 0; k < layerState.convKernelSize; k += 1) {
        mixed += convState[stateBase + k] * layerState.convWeight[k + stateBase];
      }
      convOut[tokenIdx * layerState.convDim + channel] = silu(mixed);
    }
  }

  for (let head = 0; head < layerState.numVHeads; head += 1) {
    const headScale = 1 / Math.sqrt(layerState.headKDim);
    const recurrentHeadBase = head * layerState.headKDim * layerState.headVDim;
    const srcHead = Math.floor(head / Math.max(layerState.qRep, 1));
    const qBase = srcHead * layerState.headKDim;
    const kBase = layerState.qSize + srcHead * layerState.headKDim;
    const vBase = layerState.qSize + layerState.kSize + head * layerState.headVDim;

    for (let tokenIdx = 0; tokenIdx < numTokens; tokenIdx += 1) {
      const convRowBase = tokenIdx * layerState.convDim;
      const zRowBase = tokenIdx * layerState.valueDim + head * layerState.headVDim;
      const abRowBase = tokenIdx * layerState.numVHeads + head;
      const outRowBase = tokenIdx * layerState.valueDim + head * layerState.headVDim;

      let qNormSq = 0;
      let kNormSq = 0;
      for (let d = 0; d < layerState.headKDim; d += 1) {
        const qValue = convOut[convRowBase + qBase + d];
        const kValue = convOut[convRowBase + kBase + d];
        qNormSq += qValue * qValue;
        kNormSq += kValue * kValue;
      }

      const qNormScale = headScale / Math.sqrt(qNormSq + qkL2NormEps);
      const kNormScale = 1 / Math.sqrt(kNormSq + qkL2NormEps);
      const beta = 1 / (1 + Math.exp(-b[abRowBase]));
      const g = -Math.exp(layerState.aLog[head]) * softplus(a[abRowBase] + layerState.dtBias[head]);
      const gExp = Math.exp(g);

      for (let i = 0; i < layerState.headKDim * layerState.headVDim; i += 1) {
        recurrentState[recurrentHeadBase + i] *= gExp;
      }

      for (let vd = 0; vd < layerState.headVDim; vd += 1) {
        let kvMem = 0;
        for (let kd = 0; kd < layerState.headKDim; kd += 1) {
          const kNormed = convOut[convRowBase + kBase + kd] * kNormScale;
          const stateIdx = recurrentHeadBase + kd * layerState.headVDim + vd;
          kvMem += recurrentState[stateIdx] * kNormed;
        }
        const delta = (convOut[convRowBase + vBase + vd] - kvMem) * beta;
        for (let kd = 0; kd < layerState.headKDim; kd += 1) {
          const kNormed = convOut[convRowBase + kBase + kd] * kNormScale;
          const stateIdx = recurrentHeadBase + kd * layerState.headVDim + vd;
          recurrentState[stateIdx] += kNormed * delta;
        }
      }

      let meanSq = 0;
      for (let vd = 0; vd < layerState.headVDim; vd += 1) {
        let outValue = 0;
        for (let kd = 0; kd < layerState.headKDim; kd += 1) {
          const qNormed = convOut[convRowBase + qBase + kd] * qNormScale;
          const stateIdx = recurrentHeadBase + kd * layerState.headVDim + vd;
          outValue += recurrentState[stateIdx] * qNormed;
        }
        output[outRowBase + vd] = outValue;
        meanSq += outValue * outValue;
      }

      const invRms = 1 / Math.sqrt(meanSq / layerState.headVDim + layerState.rmsNormEps);
      for (let vd = 0; vd < layerState.headVDim; vd += 1) {
        const gate = silu(z[zRowBase + vd]);
        const normIndex = layerState.normMode === 'per_head'
          ? head * layerState.headVDim + vd
          : vd;
        output[outRowBase + vd] = output[outRowBase + vd] * invRms * layerState.normWeight[normIndex] * gate;
      }
    }
  }

  return { output, recurrentState };
}

function createGpuBuffer(values, label) {
  const buffer = acquireBuffer(values.byteLength, undefined, label);
  uploadData(buffer, values);
  return buffer;
}

function createF16View(values) {
  const encoded = new Uint16Array(values.length);
  const rounded = new Float32Array(values.length);
  for (let i = 0; i < values.length; i += 1) {
    encoded[i] = float32ToFloat16(values[i]);
    rounded[i] = float16ToFloat32(encoded[i]);
  }
  return { encoded, rounded };
}

const gpuProbe = await probeNodeGPU();
if (!gpuProbe.ready) {
  console.log(`linear-attention-core-gpu-regression.test: skipped (${gpuProbe.reason})`);
  process.exit(0);
}

const numTokens = 3;
const qkL2NormEps = 1e-6;
const qkv = new Float32Array([
  0.2, -0.1, 0.4, 0.3, 0.5, -0.2, 0.1, 0.7,
  -0.3, 0.6, -0.5, 0.2, 0.8, 0.4, -0.2, 0.9,
  0.7, 0.1, 0.2, -0.4, -0.6, 0.3, 0.5, -0.8,
]);
const z = new Float32Array([
  0.3, -0.2, 0.5, 0.1,
  -0.4, 0.6, 0.2, -0.1,
  0.7, 0.2, -0.3, 0.4,
]);
const a = new Float32Array([0.1, -0.2, 0.3, 0.4, -0.5, 0.2]);
const b = new Float32Array([0.2, -0.1, -0.3, 0.7, 0.4, -0.2]);
const layerState = {
  layerIdx: 0,
  convKernelSize: 1,
  convDim: 8,
  keyDim: 2,
  valueDim: 4,
  numKHeads: 1,
  numVHeads: 2,
  headKDim: 2,
  headVDim: 2,
  qSize: 2,
  kSize: 2,
  vSize: 4,
  qRep: 2,
  normMode: 'shared',
  rmsNormEps: 1e-6,
  convWeight: new Float32Array([1, 1, 1, 1, 1, 1, 1, 1]),
  dtBias: new Float32Array([0.2, -0.1]),
  aLog: new Float32Array([Math.log(0.6), Math.log(0.4)]),
  normWeight: new Float32Array([1.1, 0.9]),
  convState: new Float32Array(8),
  recurrentState: new Float32Array(8),
};

async function runCase(inputDtype) {
  const qkvInput = inputDtype === 'f16' ? createF16View(qkv) : null;
  const zInput = inputDtype === 'f16' ? createF16View(z) : null;
  const aInput = inputDtype === 'f16' ? createF16View(a) : null;
  const bInput = inputDtype === 'f16' ? createF16View(b) : null;
  const reference = buildReferenceOutput({
    qkv: qkvInput?.rounded ?? qkv,
    z: zInput?.rounded ?? z,
    a: aInput?.rounded ?? a,
    b: bInput?.rounded ?? b,
    layerState,
    numTokens,
    qkL2NormEps,
  });
  const gpuLayerState = {
    ...layerState,
    convWeightGPU: createGpuBuffer(layerState.convWeight, `linear_conv_weight_${inputDtype}`),
    dtBiasGPU: createGpuBuffer(layerState.dtBias, `linear_dt_bias_${inputDtype}`),
    aLogGPU: createGpuBuffer(layerState.aLog, `linear_a_log_${inputDtype}`),
    normWeightGPU: createGpuBuffer(layerState.normWeight, `linear_norm_weight_${inputDtype}`),
    convStateGPU: createGpuBuffer(layerState.convState, `linear_conv_state_${inputDtype}`),
    recurrentStateGPU: createGpuBuffer(layerState.recurrentState, `linear_recurrent_state_${inputDtype}`),
  };
  const qkvBuffer = createGpuBuffer(qkvInput?.encoded ?? qkv, `linear_qkv_${inputDtype}`);
  const zBuffer = createGpuBuffer(zInput?.encoded ?? z, `linear_z_${inputDtype}`);
  const aBuffer = createGpuBuffer(aInput?.encoded ?? a, `linear_a_${inputDtype}`);
  const bBuffer = createGpuBuffer(bInput?.encoded ?? b, `linear_b_${inputDtype}`);

  let outputTensor = null;
  try {
    outputTensor = await runLinearAttentionCoreGPU(
      createTensor(qkvBuffer, inputDtype, [numTokens, layerState.convDim], `linear_qkv_${inputDtype}`),
      createTensor(zBuffer, inputDtype, [numTokens, layerState.valueDim], `linear_z_${inputDtype}`),
      createTensor(aBuffer, inputDtype, [numTokens, layerState.numVHeads], `linear_a_${inputDtype}`),
      createTensor(bBuffer, inputDtype, [numTokens, layerState.numVHeads], `linear_b_${inputDtype}`),
      gpuLayerState,
      { numTokens, qkL2NormEps, outputDtype: 'f32' }
    );

    const gpuOutput = new Float32Array(await readBuffer(outputTensor.buffer, reference.output.byteLength));
    const gpuState = new Float32Array(
      await readBuffer(gpuLayerState.recurrentStateGPU, reference.recurrentState.byteLength)
    );
    const tolerance = inputDtype === 'f16' ? 7e-4 : 1e-5;
    assertArraysClose(gpuOutput, reference.output, tolerance, `${inputDtype} output`);
    assertArraysClose(gpuState, reference.recurrentState, tolerance, `${inputDtype} recurrent_state`);
  } finally {
    if (outputTensor?.buffer) {
      releaseBuffer(outputTensor.buffer);
    }
    for (const buffer of [
      qkvBuffer,
      zBuffer,
      aBuffer,
      bBuffer,
      gpuLayerState.convWeightGPU,
      gpuLayerState.dtBiasGPU,
      gpuLayerState.aLogGPU,
      gpuLayerState.normWeightGPU,
      gpuLayerState.convStateGPU,
      gpuLayerState.recurrentStateGPU,
    ]) {
      releaseBuffer(buffer);
    }
  }
}

await runCase('f32');
await runCase('f16');

const fusedDecodeQkv = new Float32Array([
  0.2, -0.1, 0.4, 0.3,
  0.5, -0.2, 0.1, 0.7,
  -0.3, 0.6, -0.5, 0.2,
]);
const fusedDecodeZ = new Float32Array([0.3, -0.2, 0.5, 0.1]);
const fusedDecodeA = new Float32Array([0.1, -0.2]);
const fusedDecodeB = new Float32Array([0.2, -0.1]);
const fusedDecodeLayerState = {
  layerIdx: 0,
  convKernelSize: 1,
  convDim: 12,
  keyDim: 4,
  valueDim: 4,
  numKHeads: 2,
  numVHeads: 2,
  headKDim: 2,
  headVDim: 2,
  qSize: 4,
  kSize: 4,
  vSize: 4,
  qRep: 1,
  normMode: 'shared',
  rmsNormEps: 1e-6,
  convWeight: new Float32Array(12).fill(1),
  dtBias: new Float32Array([0.2, -0.1]),
  aLog: new Float32Array([Math.log(0.6), Math.log(0.4)]),
  normWeight: new Float32Array([1.1, 0.9]),
  convState: new Float32Array(12),
  recurrentState: new Float32Array(8),
};

async function runFusedDecodeCase(inputDtype) {
  const fusedDecodeAB = new Float32Array([...fusedDecodeA, ...fusedDecodeB]);
  const qkvInput = inputDtype === 'f16' ? createF16View(fusedDecodeQkv) : null;
  const zInput = inputDtype === 'f16' ? createF16View(fusedDecodeZ) : null;
  const abInput = inputDtype === 'f16' ? createF16View(fusedDecodeAB) : null;
  const reference = buildReferenceOutput({
    qkv: qkvInput?.rounded ?? fusedDecodeQkv,
    z: zInput?.rounded ?? fusedDecodeZ,
    a: abInput ? abInput.rounded.slice(0, fusedDecodeA.length) : fusedDecodeA,
    b: abInput ? abInput.rounded.slice(fusedDecodeA.length) : fusedDecodeB,
    layerState: fusedDecodeLayerState,
    numTokens: 1,
    qkL2NormEps,
  });
  const gpuLayerState = {
    ...fusedDecodeLayerState,
    convWeightGPU: createGpuBuffer(fusedDecodeLayerState.convWeight, `linear_fused_conv_weight_${inputDtype}`),
    dtBiasGPU: createGpuBuffer(fusedDecodeLayerState.dtBias, `linear_fused_dt_bias_${inputDtype}`),
    aLogGPU: createGpuBuffer(fusedDecodeLayerState.aLog, `linear_fused_a_log_${inputDtype}`),
    normWeightGPU: createGpuBuffer(fusedDecodeLayerState.normWeight, `linear_fused_norm_weight_${inputDtype}`),
    convStateGPU: createGpuBuffer(fusedDecodeLayerState.convState, `linear_fused_conv_state_${inputDtype}`),
    recurrentStateGPU: createGpuBuffer(fusedDecodeLayerState.recurrentState, `linear_fused_recurrent_state_${inputDtype}`),
  };
  const qkvBuffer = createGpuBuffer(qkvInput?.encoded ?? fusedDecodeQkv, `linear_fused_qkv_${inputDtype}`);
  const zBuffer = createGpuBuffer(zInput?.encoded ?? fusedDecodeZ, `linear_fused_z_${inputDtype}`);
  const abBuffer = createGpuBuffer(abInput?.encoded ?? fusedDecodeAB, `linear_fused_ab_${inputDtype}`);

  let outputTensor = null;
  try {
    setRuntimeConfig({
      inference: {
        session: {
          useLinearAttentionFusedDecodeCore: true,
        },
      },
    });
    outputTensor = await runLinearAttentionCoreGPU(
      createTensor(qkvBuffer, inputDtype, [1, fusedDecodeLayerState.convDim], `linear_fused_qkv_${inputDtype}`),
      createTensor(zBuffer, inputDtype, [1, fusedDecodeLayerState.valueDim], `linear_fused_z_${inputDtype}`),
      createTensor(abBuffer, inputDtype, [1, fusedDecodeLayerState.numVHeads * 2], `linear_fused_ab_${inputDtype}`),
      createTensor(abBuffer, inputDtype, [1, fusedDecodeLayerState.numVHeads * 2], `linear_fused_ab_${inputDtype}`),
      gpuLayerState,
      {
        numTokens: 1,
        qkL2NormEps,
        outputDtype: 'f32',
        abPacked: true,
        bProjOffsetElements: fusedDecodeLayerState.numVHeads,
      }
    );

    const gpuOutput = new Float32Array(await readBuffer(outputTensor.buffer, reference.output.byteLength));
    const gpuState = new Float32Array(
      await readBuffer(gpuLayerState.recurrentStateGPU, reference.recurrentState.byteLength)
    );
    const tolerance = inputDtype === 'f16' ? 7e-4 : 1e-5;
    assertArraysClose(gpuOutput, reference.output, tolerance, `${inputDtype} fused output`);
    assertArraysClose(gpuState, reference.recurrentState, tolerance, `${inputDtype} fused recurrent_state`);
  } finally {
    resetRuntimeConfig();
    if (outputTensor?.buffer) {
      releaseBuffer(outputTensor.buffer);
    }
    for (const buffer of [
      qkvBuffer,
      zBuffer,
      abBuffer,
      gpuLayerState.convWeightGPU,
      gpuLayerState.dtBiasGPU,
      gpuLayerState.aLogGPU,
      gpuLayerState.normWeightGPU,
      gpuLayerState.convStateGPU,
      gpuLayerState.recurrentStateGPU,
    ]) {
      releaseBuffer(buffer);
    }
  }
}

await runFusedDecodeCase('f32');
await runFusedDecodeCase('f16');

async function runFusedDecodePackedQkvzCase(inputDtype) {
  const fusedDecodeQkvz = new Float32Array([...fusedDecodeQkv, ...fusedDecodeZ]);
  const fusedDecodeAB = new Float32Array([...fusedDecodeA, ...fusedDecodeB]);
  const qkvzInput = inputDtype === 'f16' ? createF16View(fusedDecodeQkvz) : null;
  const abInput = inputDtype === 'f16' ? createF16View(fusedDecodeAB) : null;
  const qkvzReference = qkvzInput?.rounded ?? fusedDecodeQkvz;
  const reference = buildReferenceOutput({
    qkv: qkvzReference.slice(0, fusedDecodeLayerState.convDim),
    z: qkvzReference.slice(fusedDecodeLayerState.convDim),
    a: abInput ? abInput.rounded.slice(0, fusedDecodeA.length) : fusedDecodeA,
    b: abInput ? abInput.rounded.slice(fusedDecodeA.length) : fusedDecodeB,
    layerState: fusedDecodeLayerState,
    numTokens: 1,
    qkL2NormEps,
  });
  const gpuLayerState = {
    ...fusedDecodeLayerState,
    convWeightGPU: createGpuBuffer(fusedDecodeLayerState.convWeight, `linear_fused_qkvz_conv_weight_${inputDtype}`),
    dtBiasGPU: createGpuBuffer(fusedDecodeLayerState.dtBias, `linear_fused_qkvz_dt_bias_${inputDtype}`),
    aLogGPU: createGpuBuffer(fusedDecodeLayerState.aLog, `linear_fused_qkvz_a_log_${inputDtype}`),
    normWeightGPU: createGpuBuffer(fusedDecodeLayerState.normWeight, `linear_fused_qkvz_norm_weight_${inputDtype}`),
    convStateGPU: createGpuBuffer(fusedDecodeLayerState.convState, `linear_fused_qkvz_conv_state_${inputDtype}`),
    recurrentStateGPU: createGpuBuffer(fusedDecodeLayerState.recurrentState, `linear_fused_qkvz_recurrent_state_${inputDtype}`),
  };
  const qkvzBuffer = createGpuBuffer(qkvzInput?.encoded ?? fusedDecodeQkvz, `linear_fused_qkvz_${inputDtype}`);
  const abBuffer = createGpuBuffer(abInput?.encoded ?? fusedDecodeAB, `linear_fused_qkvz_ab_${inputDtype}`);
  const recorder = new CommandRecorder(null, `linear_fused_qkvz_${inputDtype}`, { recordLabels: true });

  let outputTensor = null;
  try {
    setRuntimeConfig({
      inference: {
        session: {
          useLinearAttentionFusedDecodeCore: true,
        },
      },
    });
    outputTensor = await runLinearAttentionCoreGPU(
      createTensor(qkvzBuffer, inputDtype, [1, fusedDecodeLayerState.convDim + fusedDecodeLayerState.valueDim], `linear_fused_qkvz_${inputDtype}`),
      createTensor(qkvzBuffer, inputDtype, [1, fusedDecodeLayerState.convDim + fusedDecodeLayerState.valueDim], `linear_fused_qkvz_${inputDtype}`),
      createTensor(abBuffer, inputDtype, [1, fusedDecodeLayerState.numVHeads * 2], `linear_fused_qkvz_ab_${inputDtype}`),
      createTensor(abBuffer, inputDtype, [1, fusedDecodeLayerState.numVHeads * 2], `linear_fused_qkvz_ab_${inputDtype}`),
      gpuLayerState,
      {
        numTokens: 1,
        qkL2NormEps,
        outputDtype: 'f32',
        recorder,
        abPacked: true,
        qkvzPacked: true,
        bProjOffsetElements: fusedDecodeLayerState.numVHeads,
      }
    );
    await recorder.submitAndWait();

    const stats = recorder.getStats();
    assert.equal(stats.opLabelCounts.linear_attention_fused_decode_core, 1, `${inputDtype} packed QKVZ must use fused decode core`);
    assert.equal(stats.opLabelCounts.linear_attention_conv ?? 0, 0, `${inputDtype} packed QKVZ must not use split conv`);
    assert.equal(stats.opLabelCounts.linear_attention_recurrent ?? 0, 0, `${inputDtype} packed QKVZ must not use split recurrent`);

    const gpuOutput = new Float32Array(await readBuffer(outputTensor.buffer, reference.output.byteLength));
    const gpuState = new Float32Array(
      await readBuffer(gpuLayerState.recurrentStateGPU, reference.recurrentState.byteLength)
    );
    const tolerance = inputDtype === 'f16' ? 7e-4 : 1e-5;
    assertArraysClose(gpuOutput, reference.output, tolerance, `${inputDtype} packed QKVZ fused output`);
    assertArraysClose(gpuState, reference.recurrentState, tolerance, `${inputDtype} packed QKVZ fused recurrent_state`);
  } finally {
    resetRuntimeConfig();
    if (!recorder.getStats().submitted) {
      recorder.abort();
    }
    if (outputTensor?.buffer) {
      releaseBuffer(outputTensor.buffer);
    }
    for (const buffer of [
      qkvzBuffer,
      abBuffer,
      gpuLayerState.convWeightGPU,
      gpuLayerState.dtBiasGPU,
      gpuLayerState.aLogGPU,
      gpuLayerState.normWeightGPU,
      gpuLayerState.convStateGPU,
      gpuLayerState.recurrentStateGPU,
    ]) {
      releaseBuffer(buffer);
    }
  }
}

await runFusedDecodePackedQkvzCase('f32');
await runFusedDecodePackedQkvzCase('f16');

destroyDevice();
console.log('linear-attention-core-gpu-regression.test: ok');
