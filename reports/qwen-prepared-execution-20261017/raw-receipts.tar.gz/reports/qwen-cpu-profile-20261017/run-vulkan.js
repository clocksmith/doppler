import fs from 'node:fs/promises';
import { chromium } from 'playwright';
const launch = chromium.launchPersistentContext.bind(chromium);
const instrumentContext = async (context) => {
  const newPage = context.newPage.bind(context);
  let session;
  context.newPage = async (...pageArgs) => {
    const page = await newPage(...pageArgs);
    session = await context.newCDPSession(page);
    await session.send('Profiler.enable');
    await session.send('Profiler.setSamplingInterval', { interval: 100 });
    await session.send('Profiler.start');
    return page;
  };
  const close = context.close.bind(context);
  context.close = async (...closeArgs) => {
    if (session) {
      const { profile } = await session.send('Profiler.stop');
      await fs.writeFile('cpu-prefill.cpuprofile', JSON.stringify(profile));
    }
    return close(...closeArgs);
  };
  return context;
};
chromium.launchPersistentContext = async (...args) => instrumentContext(await launch(...args));
const launchBrowser = chromium.launch.bind(chromium);
chromium.launch = async (...args) => {
  const browser = await launchBrowser(...args);
  const newContext = browser.newContext.bind(browser);
  browser.newContext = async (...contextArgs) => instrumentContext(await newContext(...contextArgs));
  return browser;
};
process.argv = ['node', 'baseline/src/cli/doppler-cli.js', 'bench', '--surface', 'browser', '--config', 'cpu-prefill-config.json', '--json'];
await import('./baseline/src/cli/doppler-cli.js');
