import json,os,pathlib,signal,subprocess,sys,time
host,baseline,candidate,*model_override=sys.argv[1:]
root=pathlib.Path('reports/weight-representation-20261017');base=root/host
first=base/('current-baseline-27b-first/receipt.json' if model_override else 'candidate-2b-first/receipt.json')
deadline=time.monotonic()+900
while not first.exists():
 if time.monotonic()>deadline:raise RuntimeError('First candidate receipt did not settle')
 time.sleep(1)
assert json.loads(first.read_text())['passed'], 'First candidate failed; inspect before continuing'
rows=[]
cases=[('candidate','27b','first'),('candidate','27b','second'),('baseline','27b','second')] if model_override else [('candidate','2b','second'),('baseline','2b','second'),('baseline','27b','first'),('candidate','27b','first'),('candidate','27b','second'),('baseline','27b','second')]
for engine,size,order in cases:
 out=base/(("current-" if model_override else "")+f'{engine}-{size}-{order}');out.mkdir(parents=True,exist_ok=False)
 model='qwen-3-5-2b-q4k-ehaf16' if size=='2b' else 'qwen-3-6-27b-q4k-ehaf16'
 command=['node',str(root/'browser-compare.mjs'),baseline if engine=='baseline' else candidate,
  model_override[0] if model_override else 'models/local/'+model,str(root/f'{host}-{size}-config.json'),str(out/'receipt.json')]
 row={'command':command,'started':time.time()};print('START',engine,size,order,flush=True)
 with (out/'run.log').open('w') as log:
  process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:row['returncode']=process.wait(timeout=900)
  except subprocess.TimeoutExpired:
   row['timeoutSeconds']=900;os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
 row['elapsedSeconds']=time.time()-row['started'];rows.append(row)
 (base/('current-27b-campaign-status.json' if model_override else 'campaign-status.json')).write_text(json.dumps(rows,indent=2)+'\n');print('DONE',engine,size,order,row,flush=True)
