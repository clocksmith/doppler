import hashlib,json,pathlib,sys,time
import blake3
root,out=map(pathlib.Path,sys.argv[1:]);raw=(root/'manifest.json').read_bytes();manifest=json.loads(raw)
receipt={'modelId':manifest['modelId'],'manifestSha256':hashlib.sha256(raw).hexdigest(),'algorithm':manifest['hashAlgorithm'],'started':time.time(),'files':[],'passed':False}
try:
 for shard in manifest['shards']:
  h=blake3.blake3() if manifest['hashAlgorithm']=='blake3' else hashlib.sha256();size=0
  with (root/shard['filename']).open('rb') as f:
   while chunk:=f.read(2**21):h.update(chunk);size+=len(chunk)
  actual=h.hexdigest();expected=shard['hash'].split(':')[-1]
  receipt['files'].append({'file':shard['filename'],'bytes':size,'hash':actual,'expected':expected,'passed':actual==expected and size==shard['size']})
  assert receipt['files'][-1]['passed'],shard['filename']
 token=root/manifest['tokenizer']['file'];receipt['tokenizerSha256']=hashlib.sha256(token.read_bytes()).hexdigest();receipt['passed']=True
except Exception as error:receipt['failure']=repr(error);raise
finally:receipt['elapsedSeconds']=time.time()-receipt['started'];out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':receipt['passed'],'shards':len(receipt['files']),'elapsedSeconds':receipt['elapsedSeconds']}))
