import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const [repoArgument, restoredArgument, vendorArgument, outputArgument] = process.argv.slice(2);
assert(repoArgument && restoredArgument && vendorArgument && outputArgument);
const [repo, restored, vendor, output] = [repoArgument, restoredArgument, vendorArgument, outputArgument].map(p => path.resolve(p));
const bundle = import.meta.dirname;
const read = async p => JSON.parse(await fs.readFile(p));
const sha = async p => createHash('sha256').update(await fs.readFile(p)).digest('hex');
const write = async (p, value) => fs.writeFile(p, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const expected = await read(path.join(bundle, 'expected-vendor-acquisition.json'));
const acquired = await read(path.join(vendor, 'acquisition.json'));
assert.deepEqual(acquired.files, expected.files, 'Exported vendor files must match every retained identity.');
const runtime = await read(path.join(restored, 'receipt.json'));
assert.equal(runtime.package.sha256, '61a23b9cafd17eb2b420c7bd8bb1f7e8cfae859048f581e42a5fb01ad767ed19');
await fs.mkdir(output);
const capsule = path.join(output, 'capsule');
await fs.cp(path.join(bundle, 'capsule'), capsule, { recursive: true });
await fs.cp(path.join(restored, 'retained/application/capsules/reranker'), path.join(capsule, 'distribution'), { recursive: true });
const plan = await read(path.join(bundle, 'original-plan.json'));
plan.references = await Promise.all(plan.references.map(async (reference, i) => {
  const filename = path.join(bundle, 'references', `${i}.json`);
  assert.equal(`sha256:${await sha(filename)}`, reference.digest);
  return { ...reference, path: filename };
}));
plan.implementationCommit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
for (const tool of plan.tools) tool.sha256 = await sha(path.join(repo, tool.path));
plan.vendorAcquisitionSha256 = await sha(path.join(vendor, 'acquisition.json'));
plan.qualificationPrerequisites = ['transformersjs', 'doppler'].map(engine => path.join(output, `quality-${engine}`, 'qualification.json'));
for (const engine of ['doppler', 'transformersjs']) {
  const config = await read(path.join(bundle, 'inputs', `${engine}.json`));
  config.references = plan.references; config.outputDir = path.join(output, `quality-${engine}`);
  config.repeatRuns = 2; delete config.sampling;
  if (engine === 'doppler') { config.packageBundlePath = restored; config.capsuleRoot = capsule; }
  else config.modelRoot = vendor;
  await write(path.join(output, `quality-${engine}.json`), config);
  for (const [index, selected] of plan.order.entries()) {
    if (selected !== engine) continue;
    const name = `${String(index).padStart(2, '0')}-${engine}`;
    await write(path.join(output, `${name}.json`), { ...config, repeatRuns: 1,
      outputDir: path.join(output, name), sampling: plan.sampling, cachePolicy: plan.cachePolicy });
  }
}
await write(path.join(output, 'plan.json'), plan);
console.log(JSON.stringify({ output, implementationCommit: plan.implementationCommit }));
