import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
const { auditRerankerReferencePair } = await import(pathToFileURL(path.join(process.argv[2], 'tools/compare-reranker-reference-runs.js')));
const root = path.resolve(process.argv[3]);
const repo = path.resolve(process.argv[2]);
const read = async p => JSON.parse(await fs.readFile(p));
const sha = async p => createHash('sha256').update(await fs.readFile(p)).digest('hex');
const plan = await read(path.join(root, 'plan.json'));
const report = { schema: 'doppler.reranker-paired-reference-result/v1', passed: false, plan,
 startedAtUtc: new Date().toISOString(), attempts: [], pairs: [], claimAllowed: false,
 scope: 'Repeated browser startup, model loading, renderer RSS and source-valid reranking. Cancellation and recovery are separately qualified and excluded from superiority claims.' };
async function prerequisite(file) {
 while (true) {
  try { const value = await read(file); assert.equal(value.passed, true, `Prerequisite failed: ${file}`); return; }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  await new Promise(resolve => setTimeout(resolve, 5000));
 }
}
const references = await Promise.all(plan.references.map(async input => ({
 digest: input.digest, reference: await read(input.path),
})));
const reports = [];
try {
 for (const input of plan.references) assert.equal(`sha256:${await sha(input.path)}`, input.digest);
 for (const source of plan.tools) assert.equal(await sha(path.join(repo, source.path)), source.sha256);
 for (const filename of plan.qualificationPrerequisites) await prerequisite(filename);
 for (const [index, engine] of plan.order.entries()) {
  const name = `${String(index).padStart(2, '0')}-${engine}`;
  const configPath = path.join(root, name + '.json');
  const config = await read(configPath);
  assert.equal(config.repeatRuns, 1); assert.deepEqual(config.sampling, plan.sampling);
  assert.deepEqual(config.references, plan.references); assert.deepEqual(config.cachePolicy, plan.cachePolicy);
  const tool = engine === 'doppler' ? 'qualify-installed-reranker-browser.js' : 'qualify-transformersjs-reranker.js';
  const log = await fs.open(path.join(root, name + '.log'), 'wx');
  const args = [path.join(repo, 'tools', tool), configPath];
  const attempt = { index, engine, executable: process.execPath, args, configSha256: await sha(configPath) };
  report.attempts.push(attempt); console.log(JSON.stringify({ index, engine, stage: 'start' }));
  try {
   attempt.exitCode = await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, { cwd: repo, stdio: ['ignore', log.fd, log.fd], env: { ...process.env, TMPDIR: '/var/tmp' } });
    child.once('error', reject); child.once('exit', (code, signal) => resolve(code ?? signal));
   });
  } finally { await log.close(); }
  const resultPath = path.join(config.outputDir, 'qualification.json');
  const result = await read(resultPath); attempt.receiptSha256 = await sha(resultPath);
  reports.push({ engine, result });
  assert.equal(attempt.exitCode, 0); assert.equal(result.passed, true);
  if (index % 2 === 1) {
   const pair = Object.fromEntries(reports.slice(-2).map(row => [row.engine, row.result]));
   const audit = auditRerankerReferencePair(pair.doppler, pair.transformersjs, references);
   report.pairs.push(audit); assert(audit.timingComparable, 'Paired raw-reference and timing gate failed.');
  }
  await fs.writeFile(path.join(root, 'progress.json'), JSON.stringify(report, null, 2) + '\n');
 }
 const median = values => { const rows = [...values].sort((a,b) => a-b); return rows[Math.floor(rows.length/2)]; };
 report.summary = Object.fromEntries(['doppler','transformersjs'].map(engine => {
  const rows = reports.filter(row => row.engine === engine).map(row => {
   const r = row.result, phase = r.phases[0].observation;
   const timed = phase.runs.filter(run => run.phase === 'timed');
   const documents = timed.reduce((n,run) => n + references[run.referenceIndex].reference.input.documents.length, 0);
   return { modelReadyMs: r.startup.modelReadyMs, firstResultMs: r.startup.firstResultMs,
    modelLoadMs: phase.modelLoadMs, peakRendererRssBytes: r.peakRendererRssBytes,
    documentsPerSecond: documents * 1000 / timed.reduce((n,run) => n + run.durationMs, 0) };
  });
  return [engine, { samples: rows.length, rows, median: Object.fromEntries(Object.keys(rows[0]).map(key => [key,median(rows.map(row => row[key]))])) }];
 }));
 report.passed = true;
} catch (error) { report.error = { message: error.message, stack: error.stack }; process.exitCode = 1; }
finally {
 report.completedAtUtc = new Date().toISOString();
 await fs.writeFile(path.join(root, 'comparison.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
 console.log(JSON.stringify({ passed: report.passed, error: report.error, summary: report.summary }));
}
