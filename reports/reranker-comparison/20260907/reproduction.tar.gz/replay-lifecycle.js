import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const repo = path.resolve(process.argv[2]), output = path.resolve(process.argv[3]);
for (const engine of ['doppler', 'transformersjs']) {
  const qualificationPath = path.join(output, `quality-${engine}`, 'qualification.json');
  const bytes = await fs.readFile(qualificationPath); assert.equal(JSON.parse(bytes).passed, true);
  const config = { schema: 'doppler.reranker-browser-lifecycle/v1', engine, qualificationPath,
    qualificationDigest: `sha256:${createHash('sha256').update(bytes).digest('hex')}`,
    operationTimeoutMs: 30000, maxRecoveryMs: 600000, outputDir: path.join(output, `lifecycle-${engine}`) };
  const configPath = path.join(output, `lifecycle-${engine}.json`);
  await fs.writeFile(configPath, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
  await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(repo, 'tools/observe-reranker-browser-lifecycle.js'), configPath], {
      cwd: repo, stdio: 'inherit', env: { ...process.env, TMPDIR: '/var/tmp' } });
    child.once('error', reject); child.once('exit', code => code === 0 ? resolve() : reject(new Error(`${engine}: lifecycle observation failed (${code}).`)));
  });
}
