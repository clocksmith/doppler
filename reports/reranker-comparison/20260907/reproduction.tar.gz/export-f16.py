from pathlib import Path
import json,shutil,hashlib,platform,sys
import torch,transformers,onnx
from transformers import AutoModelForCausalLM,AutoTokenizer
source=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]).resolve();root.mkdir();repo='Qwen/Qwen3-Reranker-0.6B';revision='e61197ed45024b0ed8a2d74b80b4d909f1255473';out=root/repo;(out/'onnx').mkdir(parents=True)
torch.set_num_threads(8);torch.manual_seed(0)
model=AutoModelForCausalLM.from_pretrained(source,local_files_only=True,dtype=torch.float16,attn_implementation='eager').eval()
tokenizer=AutoTokenizer.from_pretrained(source,local_files_only=True)
class Reranker(torch.nn.Module):
 def __init__(self,model):super().__init__();self.model=model
 def forward(self,input_ids,attention_mask,position_ids):
  length=input_ids.shape[1];indices=torch.arange(length,device=input_ids.device)
  allowed=(indices[:,None]>=indices[None,:])[None,None,:,:] & attention_mask[:,None,None,:].bool()
  mask=torch.where(allowed,torch.tensor(0.,dtype=torch.float16),torch.tensor(torch.finfo(torch.float16).min))
  return self.model(input_ids=input_ids,attention_mask=mask,position_ids=position_ids,use_cache=False,logits_to_keep=1).logits
wrapper=Reranker(model);ids=torch.tensor([[151644,8948,198,1234,5678,151645,198,151644,77091,198]]);mask=torch.ones_like(ids);positions=torch.arange(ids.shape[1])[None,:]
with torch.inference_mode():
 expected=model(input_ids=ids,attention_mask=mask,position_ids=positions,use_cache=False,logits_to_keep=1).logits;actual=wrapper(ids,mask,positions)
 assert torch.allclose(expected,actual,atol=1e-5,rtol=1e-5)
 torch.onnx.export(wrapper,(ids,mask,positions),str(out/'onnx/model_fp16.onnx'),input_names=['input_ids','attention_mask','position_ids'],output_names=['logits'],dynamic_axes={'input_ids':{1:'sequence_length'},'attention_mask':{1:'sequence_length'},'position_ids':{1:'sequence_length'}},opset_version=18,dynamo=False,external_data=True)
for p in source.iterdir():
 if p.is_file() and p.suffix!='.safetensors':shutil.copy2(p,out/p.name)
tokenizer.save_pretrained(out)
c=json.loads((out/'config.json').read_text());c['transformers.js_config']={'use_external_data_format':False};(out/'config.json').write_text(json.dumps(c,indent=2)+'\n')
# Normalize all external tensor locations to the loader's declared filename.
m=onnx.load(str(out/'onnx/model_fp16.onnx'),load_external_data=True);onnx.save_model(m,str(out/'onnx/model_fp16.onnx'),save_as_external_data=False)
files=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  h=hashlib.sha256()
  with p.open('rb')as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  files.append({'path':str(p.relative_to(out)),'size':p.stat().st_size,'sha256':h.hexdigest()})
report={'schema':'doppler.vendor-artifact-acquisition/v1','repository':repo,'revision':revision,'license':'apache-2.0','files':files,'preparation':{'sourceDirectory':str(source),'torch':torch.__version__,'transformers':transformers.__version__,'onnx':onnx.__version__,'python':platform.python_version(),'dtype':'float16','attention':'eager','useCache':False,'output':'last-position full-vocabulary logits','opset':18,'wrapperMaxAbs':(actual-expected).abs().max().item(),'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(root/'acquisition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'files':len(files),'output':str(root)}))
