const SUPPORTED_TJS_DTYPES = Object.freeze(['fp32', 'fp16', 'q8', 'q4', 'q4f16']);
const SUPPORTED_TJS_FORMATS = Object.freeze(['onnx', 'safetensors']);
const DEFAULT_TJS_FORMAT = 'onnx';
const DEFAULT_CACHE_MODE = 'warm';
const DEFAULT_TJS_VERSION = '4';
const UNKNOWN_LABEL = 'unknown';
const EMPTY_STRING = '';
const HF_CACHE_TOKEN_FILE = '.cache/huggingface/token';

export function normalizePreferredDtype(dtype) {
  const normalized = String(dtype || 'fp16').trim().toLowerCase();
  if (!SUPPORTED_TJS_DTYPES.includes(normalized)) {
    throw new Error(`Unsupported Transformers.js dtype: ${normalized}. Expected ${SUPPORTED_TJS_DTYPES.join(', ')}.`);
  }
  return normalized;
}

export function normalizeFormat(format) {
  const normalized = String(format || DEFAULT_TJS_FORMAT).trim().toLowerCase();
  return SUPPORTED_TJS_FORMATS.includes(normalized) ? normalized : DEFAULT_TJS_FORMAT;
}

export function buildStrictWebgpuExecution(preferredDtype = 'fp16') {
  const requestedDtype = normalizePreferredDtype(preferredDtype);
  return Object.freeze({
    requestedDtype,
    effectiveDtype: requestedDtype,
    executionProviderMode: 'webgpu-only',
    effectiveOrtProxy: false,
    fallbackUsed: false,
    ortProxyFallbackUsed: false,
    executionProviderFallbackUsed: false,
  });
}

export function requiresPersistentBrowserContext(cacheMode, loadMode) {
  return cacheMode === 'warm' || loadMode === 'opfs';
}

export function persistentContextFailureMessage(cacheMode, loadMode) {
  if (loadMode === 'opfs') {
    return 'loadMode=opfs requires persistent browser context; persistent launch failed.';
  }
  if (cacheMode === 'warm') {
    return 'cacheMode=warm requires persistent browser context; persistent launch failed.';
  }
  return 'persistent browser context required by benchmark contract; persistent launch failed.';
}

export { SUPPORTED_TJS_DTYPES };
export { SUPPORTED_TJS_FORMATS };
export { DEFAULT_TJS_FORMAT };
export {
  DEFAULT_CACHE_MODE,
  DEFAULT_TJS_VERSION,
  UNKNOWN_LABEL,
  EMPTY_STRING,
  HF_CACHE_TOKEN_FILE,
};
