import fs from 'node:fs/promises';
import { create, globals } from '/var/tmp/doppler-release-20260907-public-node/consumer/node_modules/webgpu/index.js';
Object.assign(globalThis,globals);const gpu=create(['backend=vulkan']);const adapter=await gpu.requestAdapter();const device=await adapter.requestDevice();
const root='/var/tmp/doppler-esm2-8m-20260907';const reference=JSON.parse(await fs.readFile(root+'/gelu-diagnostic.json'));
const input=new Float32Array(reference.sourceBoundaries['first-pre-gelu']);const buffers=[];
try {
 const make=(size,usage)=>{const b=device.createBuffer({size,usage});buffers.push(b);return b;};
 const src=make(input.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);device.queue.writeBuffer(src,0,input);
 const out=make(input.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC);const uniform=make(16,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);device.queue.writeBuffer(uniform,0,new Uint32Array([input.length,0,0,0]));
 const staging=make(input.byteLength,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
 const module=device.createShaderModule({code:await fs.readFile('/var/tmp/doppler-release-20260907-public-node/consumer/node_modules/doppler-gpu/src/gpu/kernels/gelu.wgsl','utf8')});
 const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'main'}});
 const bind=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[uniform,src,out,src].map((buffer,binding)=>({binding,resource:{buffer}}))});
 const encoder=device.createCommandEncoder();const pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bind);pass.dispatchWorkgroups(Math.ceil(input.length/256));pass.end();encoder.copyBufferToBuffer(out,0,staging,0,input.byteLength);device.queue.submit([encoder.finish()]);await staging.mapAsync(GPUMapMode.READ);const values=Array.from(new Float32Array(staging.getMappedRange()));staging.unmap();
 const compare=expected=>Math.max(...values.map((v,i)=>Math.abs(v-expected[i])));
 const report={stage:'first-ffn-gelu',elements:input.length,sourceErfMaxAbs:compare(reference.sourceBoundaries['first-post-gelu']),sourceTanhMaxAbs:compare(reference.tanhBoundaries['first-post-gelu']),values};
 await fs.writeFile(root+'/gelu-gpu-probe.json',JSON.stringify(report)+'\n',{flag:'wx'});console.log({...report,values:undefined});
} finally {for(const buffer of buffers)buffer.destroy();device.destroy();}
