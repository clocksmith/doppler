import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root = '/var/tmp/doppler-esm2-8m-20260907';
const upstream = JSON.parse(await fs.readFile(path.join(root, 'upstream.json')));
const repository = 'facebook/esm2_t6_8M_UR50D';
const revision = 'c731040fcd8d73dceaa04b0a8e6329b345b0f5df';
assert.equal(upstream.sha, revision);
const source = path.join(root, 'source'); await fs.mkdir(source);
const files = [];
for (const name of ['README.md', 'config.json', 'model.safetensors', 'special_tokens_map.json', 'tokenizer_config.json', 'vocab.txt']) {
 const metadata = upstream.siblings.find(file => file.rfilename === name); assert(metadata);
 const url = `https://huggingface.co/${repository}/resolve/${revision}/${name}`;
 const response = await fetch(url, { signal: AbortSignal.timeout(180000) }); assert(response.ok);
 const bytes = Buffer.from(await response.arrayBuffer()); assert.equal(bytes.length, metadata.size);
 const sha256 = createHash('sha256').update(bytes).digest('hex');
 if (metadata.lfs) assert.equal(sha256, metadata.lfs.sha256);
 else assert.equal(createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'), metadata.blobId);
 await fs.writeFile(path.join(source, name), bytes, { flag: 'wx' });
 files.push({ path: name, url, sizeBytes: bytes.length, sha256, gitBlob: metadata.blobId });
 console.log(JSON.stringify({ file: name, sha256 }));
}
await fs.writeFile(path.join(root, 'acquisition.json'), JSON.stringify({ repository, revision, files, license: upstream.cardData.license }, null, 2) + '\n', { flag: 'wx' });
