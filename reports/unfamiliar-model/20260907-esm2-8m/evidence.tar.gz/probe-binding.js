import fs from 'node:fs';
import { globals } from '/var/tmp/doppler-esm2-8m-20260907/package-erf-01/consumer/node_modules/webgpu/index.js';
const modules=new WeakSet();const p=globals.GPUDevice.prototype;const shader=p.createShaderModule;
p.createShaderModule=function(d){const m=shader.call(this,d);if(d.code.includes('fn erf_gelu'))modules.add(m);return m;};
for(const name of ['createComputePipeline','createComputePipelineAsync']){const original=p[name];p[name]=function(d){if(modules.has(d.compute.module))fs.appendFileSync('/var/tmp/doppler-esm2-8m-20260907/binding-probe.jsonl',JSON.stringify({name,label:d.label,entryPoint:d.compute.entryPoint,constants:d.compute.constants})+'\n');return original.call(this,d);};}
