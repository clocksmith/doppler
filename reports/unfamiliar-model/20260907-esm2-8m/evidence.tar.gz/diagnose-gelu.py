from pathlib import Path
import json,torch
import transformers.models.esm.modeling_esm as esm
from transformers import AutoTokenizer
r=Path('/var/tmp/doppler-esm2-8m-20260907');s=json.loads((r/'full-source-references.json').read_text());gpu=json.loads((r/'node-01/qualification.json').read_text())['phases'][0]['observation']
torch.set_num_threads(8);torch.manual_seed(0)
m=esm.EsmModel.from_pretrained(r/'source',local_files_only=True,dtype=torch.float32,attn_implementation='eager',add_pooling_layer=False).eval();t=AutoTokenizer.from_pretrained(r/'source',local_files_only=True)
x=t(s['policy']['sequences'][0],return_tensors='pt');boundaries={}
def hook(name):
 def capture(module,args,output):boundaries[name]=output.detach().reshape(-1).tolist()
 return capture
m.embeddings.register_forward_hook(hook('embedding'))
m.encoder.layer[0].intermediate.dense.register_forward_hook(hook('first-pre-gelu'))
m.encoder.layer[0].intermediate.register_forward_hook(hook('first-post-gelu'))
with torch.inference_mode(): exact=m(**x).last_hidden_state[0]
original=boundaries.copy();esm.gelu=lambda x:0.5*x*(1+torch.tanh(torch.clamp(0.7978845608*(x+0.044715*x*x*x),-15,15)))
with torch.inference_mode():approx=m(**x).last_hidden_state[0]
g=torch.tensor(gpu['tokenEmbeddings']).reshape_as(approx)
report={'hypothesis':'Runtime tanh GELU differs from source erf GELU','exactGpuMaxAbs':(exact-g).abs().max().item(),'tanhGpuMaxAbs':(approx-g).abs().max().item(),'sourceBoundaries':original,'tanhBoundaries':boundaries}
(r/'gelu-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if 'Boundaries' not in k})
