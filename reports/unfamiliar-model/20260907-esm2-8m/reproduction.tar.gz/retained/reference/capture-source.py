from pathlib import Path
import json,hashlib,platform
import torch,transformers
from transformers import EsmModel,AutoTokenizer
root=Path('/var/tmp/doppler-esm2-8m-20260907')
policy=json.loads((root/'source-policy.json').read_text()); acquisition=json.loads((root/'acquisition.json').read_text())
assert acquisition['repository']==policy['repository'] and acquisition['revision']==policy['revision']
source=Path(policy['sourceDirectory'])
for file in acquisition['files']:assert hashlib.sha256((source/file['path']).read_bytes()).hexdigest()==file['sha256']
assert policy['device']=='cpu' and policy['dtype']=='float32' and policy['attention']=='eager'
torch.set_num_threads(policy['threads']);torch.manual_seed(policy['seed'])
tokenizer=AutoTokenizer.from_pretrained(source,local_files_only=True,trust_remote_code=False)
model=EsmModel.from_pretrained(source,local_files_only=True,trust_remote_code=False,dtype=torch.float32,attn_implementation='eager',add_pooling_layer=False).eval()
references=[]
for sequence in policy['sequences']:
 encoded=tokenizer(sequence,return_tensors='pt')
 with torch.inference_mode():result=model(**encoded).last_hidden_state[0]
 ids=encoded.input_ids[0].tolist(); keep=torch.tensor([i not in policy['pooling']['excludeTokenIds'] for i in ids]);pooled=result[keep].mean(dim=0)
 assert result.shape[1]==320 and torch.isfinite(result).all() and torch.isfinite(pooled).all()
 reference={'schema':'doppler.sequenceModelReference.v1','modelId':policy['modelId'],'source':{'checkpointId':policy['repository']+'@'+policy['revision'],'repository':policy['repository'],'revision':policy['revision'],'runtime':{'framework':'pytorch','torchVersion':torch.__version__,'transformersVersion':transformers.__version__,'pythonVersion':platform.python_version(),'weightDtype':'f32','device':'cpu','attention':'eager','threads':policy['threads'],'seed':policy['seed']},'files':{f['path']:'sha256:'+f['sha256'] for f in acquisition['files']}},'input':{'alphabet':'amino_acid','sequence':sequence,'tokenIds':ids},'outputs':{'logits':False},'probes':{'pooledEmbedding':{'indices':list(range(result.shape[1])),'values':pooled.tolist()},'tokenEmbeddings':[{'position':i,'indices':list(range(result.shape[1])),'values':row.tolist()}for i,row in enumerate(result)]},'tolerances':policy['tolerances']}
 references.append(reference); print(json.dumps({'tokens':len(ids),'tokenElements':result.numel(),'pooledElements':pooled.numel()}),flush=True)
with (root/'full-source-references.json').open('x') as f:json.dump({'schema':'doppler.sequence-source-reference-set/v1','policy':policy,'references':references},f,indent=2);f.write('\n')
