import json,hashlib,platform,re
from pathlib import Path
import torch,transformers
from transformers import AutoModelForCausalLM,AutoTokenizer

import sys
root=Path(sys.argv[1])
output=Path(sys.argv[2])
assert not output.exists()
policy=json.loads((root/'generation-source-policy.json').read_text())
source=Path(policy['sourceDirectory'])
files=['config.json','generation_config.json','model.safetensors','tokenizer.json','tokenizer_config.json','README.md','LICENSE']
for name in files:
    metadata=source/'.cache/huggingface/download'/(name+'.metadata')
    assert metadata.read_text().splitlines()[0]==policy['revision'], name
torch.set_num_threads(policy['threads'])
tokenizer=AutoTokenizer.from_pretrained(source,local_files_only=True,trust_remote_code=False)
model=AutoModelForCausalLM.from_pretrained(source,local_files_only=True,trust_remote_code=False,dtype=torch.float32,attn_implementation='eager').eval()
rows=[]
for item in policy['prompts']:
    prompt=tokenizer.apply_chat_template([{'role':'user','content':item['prompt']}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
    encoded=tokenizer(prompt,return_tensors='pt',add_special_tokens=False)
    with torch.inference_mode():
        generated=model.generate(**encoded,do_sample=False,max_new_tokens=policy['maxNewTokens'],use_cache=True)
    ids=generated[0,encoded.input_ids.shape[1]:].tolist()
    text=tokenizer.decode(ids,skip_special_tokens=True)
    row={**item,'formattedPrompt':prompt,'promptTokenIds':encoded.input_ids[0].tolist(),'generatedTokenIds':ids,'text':text,'citations':[int(x)for x in re.findall(r'\[(\d+)\]',text)]}
    rows.append(row)
    print(json.dumps({'queryIndex':item['queryIndex'],'tokens':len(ids),'text':text,'citations':row['citations']}),flush=True)
    report={'schema':'doppler.document-generation-source-reference/v1','source':{'model':policy['repository'],'revision':policy['revision'],'engine':'hf-transformers-pytorch','torchVersion':torch.__version__,'transformersVersion':transformers.__version__,'pythonVersion':platform.python_version(),'device':'cpu','dtype':'float32','files':[{'path':name,'hash':'sha256:'+hashlib.sha256((source/name).read_bytes()).hexdigest()}for name in files]},'policy':policy,'outputs':rows}
output.write_text(json.dumps(report,indent=2)+'\n')
