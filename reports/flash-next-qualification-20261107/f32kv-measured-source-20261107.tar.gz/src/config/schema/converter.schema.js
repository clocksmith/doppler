import { DEFAULT_RMS_NORM_EPS, SHARD_SIZE } from './manifest.schema.js';
import { DEFAULT_QUANTIZATION_DEFAULTS } from './quantization-defaults.schema.js';
import { MB } from './units.schema.js';

// =============================================================================
// Converter Config
// =============================================================================

export const DEFAULT_CONVERTER_QUANTIZATION_CONFIG = {
  weights: null,
  w8a8: null,
  fp8: null,
  embeddings: null,
  lmHead: null,
  sourceTrainingQuantization: null,
  sourceQuantizationTarget: null,
  preserveSourceTensors: false,
  sourceQuantizationFormat: null,
  vision: DEFAULT_QUANTIZATION_DEFAULTS.visionDtype,
  audio: DEFAULT_QUANTIZATION_DEFAULTS.audioDtype,
  projector: DEFAULT_QUANTIZATION_DEFAULTS.projectorDtype,
  perLayerEmbeddings: null,
  modulesToNotConvert: null,
  // Q4K layout: 'row' (fused kernel compatible, fast) or 'col' (dequant fallback)
  q4kLayout: 'row',
  computePrecision: 'f16',
};

export const DEFAULT_CONVERTER_SHARDING_CONFIG = {
  shardSizeBytes: SHARD_SIZE,
};

export const DEFAULT_CONVERTER_STREAMING_CONFIG = {
  chunkSizeBytes: 64 * MB,
};

export const DEFAULT_CONVERTER_HTTP_CONFIG = {
  allowDownloadFallback: true,
  maxDownloadBytes: null,
};

export const DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG = {
  transposeWeights: false,
  fuseGateUp: false,
};

export const DEFAULT_CONVERTER_MANIFEST_CONFIG = {
  hashAlgorithm: 'sha256',
  optimizations: null,
  conversion: null,
  artifactIdentity: null,
  weightsRef: null,
  eosTokenId: null,
  visionConfig: null,
  audioConfig: null,
};

export const DEFAULT_CONVERTER_INFERENCE_CONFIG = {
  session: null,
  execution: null,
};

export const DEFAULT_GGUF_PARSER_DEFAULTS = {
  contextLength: 2048,
  attentionLayerNormEpsilon: DEFAULT_RMS_NORM_EPS,
  attentionLayerNormRMSEpsilon: DEFAULT_RMS_NORM_EPS,
  ropeFreqBase: 10000,
};

export const DEFAULT_CONVERTER_OUTPUT_CONFIG = {
  modelBaseId: null,
  dir: null,
  baseDir: null,
  textOnly: false,
  fast: false,
};

export const DEFAULT_CONVERTER_EXECUTION_CONFIG = {
  workers: 8,
  workerCountPolicy: 'cap',
  rowChunkRows: null,
  rowChunkMinTensorBytes: 32 * MB,
  maxInFlightJobs: null,
  useGpuCast: false,
  gpuCastMinTensorBytes: 32 * MB,
  // How retained source files become artifact shards: 'link' (no copy) or an explicit 'copy'.
  retainedSourceFiles: 'link',
};

export const DEFAULT_CONVERTER_CONFIG = {
  quantization: DEFAULT_CONVERTER_QUANTIZATION_CONFIG,
  sharding: DEFAULT_CONVERTER_SHARDING_CONFIG,
  streaming: DEFAULT_CONVERTER_STREAMING_CONFIG,
  http: DEFAULT_CONVERTER_HTTP_CONFIG,
  weightLayout: DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG,
  manifest: DEFAULT_CONVERTER_MANIFEST_CONFIG,
  inference: DEFAULT_CONVERTER_INFERENCE_CONFIG,
  output: DEFAULT_CONVERTER_OUTPUT_CONFIG,
  architecture: null,
  sourceTensors: null,
  sourceTokenizer: null,
  sourceRotaryFrequencies: null,
  moeConfig: null,
};

export function createConverterConfig(overrides) {
  if (!overrides) {
    return {
      quantization: { ...DEFAULT_CONVERTER_QUANTIZATION_CONFIG },
      sharding: { ...DEFAULT_CONVERTER_SHARDING_CONFIG },
      streaming: { ...DEFAULT_CONVERTER_STREAMING_CONFIG },
      http: { ...DEFAULT_CONVERTER_HTTP_CONFIG },
      weightLayout: { ...DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG },
      manifest: { ...DEFAULT_CONVERTER_MANIFEST_CONFIG },
      inference: { ...DEFAULT_CONVERTER_INFERENCE_CONFIG },
      output: { ...DEFAULT_CONVERTER_OUTPUT_CONFIG },
      architecture: null,
      sourceTensors: null,
      sourceTokenizer: null,
      sourceRotaryFrequencies: null,
    };
  }

  const config = {
    quantization: overrides.quantization
      ? { ...DEFAULT_CONVERTER_QUANTIZATION_CONFIG, ...overrides.quantization }
      : { ...DEFAULT_CONVERTER_QUANTIZATION_CONFIG },
    sharding: overrides.sharding
      ? { ...DEFAULT_CONVERTER_SHARDING_CONFIG, ...overrides.sharding }
      : { ...DEFAULT_CONVERTER_SHARDING_CONFIG },
    streaming: overrides.streaming
      ? { ...DEFAULT_CONVERTER_STREAMING_CONFIG, ...overrides.streaming }
      : { ...DEFAULT_CONVERTER_STREAMING_CONFIG },
    http: overrides.http
      ? { ...DEFAULT_CONVERTER_HTTP_CONFIG, ...overrides.http }
      : { ...DEFAULT_CONVERTER_HTTP_CONFIG },
    weightLayout: overrides.weightLayout
      ? { ...DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG, ...overrides.weightLayout }
      : { ...DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG },
    manifest: overrides.manifest
      ? { ...DEFAULT_CONVERTER_MANIFEST_CONFIG, ...overrides.manifest }
      : { ...DEFAULT_CONVERTER_MANIFEST_CONFIG },
    inference: overrides.inference
      ? { ...DEFAULT_CONVERTER_INFERENCE_CONFIG, ...overrides.inference }
      : { ...DEFAULT_CONVERTER_INFERENCE_CONFIG },
    output: overrides.output
      ? { ...DEFAULT_CONVERTER_OUTPUT_CONFIG, ...overrides.output }
      : { ...DEFAULT_CONVERTER_OUTPUT_CONFIG },
    architecture: Object.prototype.hasOwnProperty.call(overrides, 'architecture')
      ? (overrides.architecture ?? null)
      : null,
    sourceTensors: Object.prototype.hasOwnProperty.call(overrides, 'sourceTensors')
      ? (overrides.sourceTensors ?? null)
      : null,
    sourceTokenizer: Object.prototype.hasOwnProperty.call(overrides, 'sourceTokenizer')
      ? (overrides.sourceTokenizer ?? null)
      : null,
    sourceRotaryFrequencies: Object.prototype.hasOwnProperty.call(overrides, 'sourceRotaryFrequencies')
      ? (overrides.sourceRotaryFrequencies ?? null)
      : null,
    moeConfig: Object.prototype.hasOwnProperty.call(overrides, 'moeConfig')
      ? (overrides.moeConfig ?? null)
      : null,
  };
  // V1 conversion configs place execution, session, and modelType at the top level.
  // Pass them through so isV1Config() can detect the v1 format and resolveConversionPlanV1
  // can read modelType.
  if (Object.prototype.hasOwnProperty.call(overrides, 'execution')) {
    config.execution = overrides.execution;
  }
  if (Object.prototype.hasOwnProperty.call(overrides, 'session')) {
    config.session = overrides.session;
  }
  if (typeof overrides.modelType === 'string') {
    config.modelType = overrides.modelType;
  }
  return config;
}
