import type { ConverterConfigSchema } from '../config/schema/converter.schema.js';

export type ToolingCommand = 'convert' | 'refresh-integrity' | 'release' | 'debug' | 'bench' | 'verify' | 'lora' | 'distill' | 'diagnose';
export type ToolingSurface = 'browser' | 'node';
export type ToolingWorkload = 'kernels' | 'inference' | 'embedding' | 'rerank' | 'training' | 'diffusion' | 'energy';
export type ToolingIntent = 'verify' | 'investigate' | 'calibrate' | null;
export type ToolingTrainingStage = 'stage1_joint' | 'stage2_base' | 'stage_a' | 'stage_b';
export type ToolingDistillAction = 'run' | 'stage-a' | 'stage-b' | 'eval' | 'watch' | 'compare' | 'quality-gate' | 'subsets';
export type ToolingLoraAction = 'run' | 'eval' | 'watch' | 'export' | 'compare' | 'quality-gate' | 'activate';

export interface ToolingConvertExecutionPayload {
  workers?: number | null;
  workerCountPolicy?: 'cap' | 'error' | null;
  maxInFlightJobs?: number | null;
  rowChunkRows?: number | null;
  rowChunkMinTensorBytes?: number | null;
  useGpuCast?: boolean | null;
  gpuCastMinTensorBytes?: number | null;
  retainedSourceFiles?: 'link' | 'copy' | null;
  [key: string]: unknown;
}

export interface ToolingConvertPayload {
  converterConfig: Partial<ConverterConfigSchema>;
  configPath?: string | null;
  execution?: ToolingConvertExecutionPayload | null;
  [key: string]: unknown;
}

export interface ToolingInferenceImageInput {
  url?: string | null;
  width?: number | null;
  height?: number | null;
  pixels?: number[] | ArrayBufferView | null;
  pixelDataBase64?: string | null;
}

export interface ToolingNormalizedInferenceImageInput {
  url: string | null;
  width: number | null;
  height: number | null;
  pixels: number[] | null;
  pixelDataBase64: string | null;
}

export interface ToolingInferenceInput {
  prompt?: string | Record<string, unknown> | unknown[] | null;
  image?: ToolingInferenceImageInput | null;
  maxTokens?: number | null;
  softTokenBudget?: number | null;
  /** Exact biological sequence input; it cannot be combined with prompt or image input. */
  sequence?: string | null;
  sequenceAlphabet?: 'amino_acid' | 'nucleotide' | null;
  includeTokenEmbeddings?: boolean | null;
  includeLogits?: boolean | null;
  probePositions?: number[] | null;
  /** Qualification-only cancellation probe; not part of ordinary model input. */
  sequenceQualificationAbort?: 'before_execution' | 'after_start' | null;
  /** Qualification-only late-result probe; not part of ordinary model input. */
  sequenceQualificationStaleAfterStart?: boolean | null;
}

export interface ToolingNormalizedInferenceInput {
  prompt: string | Record<string, unknown> | unknown[] | null;
  image: ToolingNormalizedInferenceImageInput | null;
  maxTokens: number | null;
  softTokenBudget: number | null;
  sequence?: string | null;
  sequenceAlphabet?: 'amino_acid' | 'nucleotide' | null;
  includeTokenEmbeddings?: boolean | null;
  includeLogits?: boolean | null;
  probePositions?: number[] | null;
  sequenceQualificationAbort?: 'before_execution' | 'after_start' | null;
  sequenceQualificationStaleAfterStart?: boolean | null;
}

export interface ToolingCommandRequestInput {
  command: ToolingCommand;
  action?: ToolingDistillAction | ToolingLoraAction | 'qualify' | 'decide';
  workload?: ToolingWorkload;
  inferenceInput?: ToolingInferenceInput | null;
  modelId?: string;
  trainingTests?: string[];
  trainingStage?: ToolingTrainingStage;
  trainingConfig?: Record<string, unknown>;
  stage1Artifact?: string;
  stage1ArtifactHash?: string;
  ulArtifactDir?: string;
  stageAArtifact?: string;
  stageAArtifactHash?: string;
  distillArtifactDir?: string;
  teacherModelId?: string;
  studentModelId?: string;
  distillDatasetId?: string;
  distillDatasetPath?: string;
  distillLanguagePair?: string;
  distillSourceLangs?: string[];
  distillTargetLangs?: string[];
  distillPairAllowlist?: string[];
  strictPairContract?: boolean;
  distillShardIndex?: number;
  distillShardCount?: number;
  resumeFrom?: string;
  forceResume?: boolean;
  forceResumeReason?: string;
  forceResumeSource?: string;
  checkpointOperator?: string;
  trainingSchemaVersion?: number;
  trainingBenchSteps?: number;
  checkpointEvery?: number;
  workloadType?: string;
  modelUrl?: string;
  cacheMode?: 'cold' | 'warm';
  loadMode?: 'opfs' | 'http' | 'memory';
  configChain?: string[] | null;
  runtimeProfile?: string;
  runtimeConfigUrl?: string;
  runtimeConfig?: Record<string, unknown>;
  inputDir?: string;
  outputDir?: string;
  modelDir?: string;
  manifestPath?: string;
  blockSize?: number;
  dryRun?: boolean;
  skipShardCheck?: boolean;
  convertPayload?: ToolingConvertPayload;
  workloadPath?: string;
  runRoot?: string;
  checkpointPath?: string;
  checkpointId?: string;
  checkpointStep?: number;
  stageId?: string;
  stageArtifact?: string;
  subsetManifest?: string;
  evalDatasetId?: string;
  pollIntervalMs?: number;
  stopWhenIdle?: boolean;
  captureOutput?: boolean;
  keepPipeline?: boolean;
  report?: Record<string, unknown> | null;
  timestamp?: string | Date | null;
  searchParams?: URLSearchParams | null;
  baselineProvider?: string | null;
  observedProvider?: string | null;
  programBundle?: Record<string, unknown> | null;
  programBundlePath?: string | null;
  parityProviders?: string[] | null;
  programBundleParityMode?: 'contract' | 'execute' | null;
  outputDirectory?: string;
  repoRoot?: string;
  forgeConfigPath?: string;
  targetId?: string;
  deviceIdentityPath?: string;
  fleetReceiptPaths?: string[];
  capsuleTrustedSignersPath?: string;
  fleetTrustedSignersPath?: string;
  signingPrivateKeyPath?: string;
  signingPublicKeyPath?: string;
  signingAuthority?: string;
}

export interface ToolingCommandRequest {
  command: ToolingCommand;
  workload: ToolingWorkload | null;
  intent: ToolingIntent;
  action: ToolingDistillAction | ToolingLoraAction | 'qualify' | 'decide' | null;
  inferenceInput: ToolingNormalizedInferenceInput | null;
  modelId: string | null;
  trainingTests: string[] | null;
  trainingStage: ToolingTrainingStage | null;
  trainingConfig: Record<string, unknown> | null;
  stage1Artifact: string | null;
  stage1ArtifactHash: string | null;
  ulArtifactDir: string | null;
  stageAArtifact: string | null;
  stageAArtifactHash: string | null;
  distillArtifactDir: string | null;
  teacherModelId: string | null;
  studentModelId: string | null;
  distillDatasetId: string | null;
  distillDatasetPath: string | null;
  distillLanguagePair: string | null;
  distillSourceLangs: string[] | null;
  distillTargetLangs: string[] | null;
  distillPairAllowlist: string[] | null;
  strictPairContract: boolean | null;
  distillShardIndex: number | null;
  distillShardCount: number | null;
  resumeFrom: string | null;
  forceResume: boolean | null;
  forceResumeReason: string | null;
  forceResumeSource: string | null;
  checkpointOperator: string | null;
  trainingSchemaVersion: number | null;
  trainingBenchSteps: number | null;
  checkpointEvery: number | null;
  workloadType: string | null;
  modelUrl: string | null;
  cacheMode: 'cold' | 'warm' | null;
  loadMode: 'opfs' | 'http' | 'memory' | null;
  configChain: string[] | null;
  runtimeProfile: string | null;
  runtimeConfigUrl: string | null;
  runtimeConfig: Record<string, unknown> | null;
  inputDir: string | null;
  outputDir: string | null;
  modelDir: string | null;
  manifestPath: string | null;
  blockSize: number | null;
  dryRun: boolean | null;
  skipShardCheck: boolean | null;
  convertPayload: ToolingConvertPayload | null;
  workloadPath: string | null;
  runRoot: string | null;
  checkpointPath: string | null;
  checkpointId: string | null;
  checkpointStep: number | null;
  stageId: string | null;
  stageArtifact: string | null;
  subsetManifest: string | null;
  evalDatasetId: string | null;
  pollIntervalMs: number | null;
  stopWhenIdle: boolean | null;
  captureOutput: boolean;
  keepPipeline: boolean;
  report: Record<string, unknown> | null;
  timestamp: string | Date | null;
  searchParams: URLSearchParams | null;
  baselineProvider: string | null;
  observedProvider: string | null;
  programBundle: Record<string, unknown> | null;
  programBundlePath: string | null;
  parityProviders: string[] | null;
  programBundleParityMode: 'contract' | 'execute' | null;
  outputDirectory?: string | null;
  repoRoot?: string | null;
  forgeConfigPath?: string | null;
  targetId?: string | null;
  deviceIdentityPath?: string | null;
  fleetReceiptPaths?: string[];
  capsuleTrustedSignersPath?: string | null;
  fleetTrustedSignersPath?: string | null;
  signingPrivateKeyPath?: string | null;
  signingPublicKeyPath?: string | null;
  signingAuthority?: string | null;
}

export declare const TOOLING_COMMANDS: readonly ToolingCommand[];
export declare const TOOLING_SURFACES: readonly ToolingSurface[];
export declare const TOOLING_WORKLOADS: readonly ToolingWorkload[];
export declare const TOOLING_VERIFY_WORKLOADS: readonly ToolingWorkload[];
export declare const TOOLING_TRAINING_COMMAND_SCHEMA_VERSION: number;

export declare function normalizeToolingCommandRequest(
  input: ToolingCommandRequestInput
): ToolingCommandRequest;

export declare function ensureCommandSupportedOnSurface(
  commandRequest: ToolingCommandRequestInput,
  surface: ToolingSurface
): { request: ToolingCommandRequest; surface: ToolingSurface };
