from pathlib import Path
import json,array,base64,math,sys
r=Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');checks=[]
for p in ['code','explanation','arithmetic','long-context']:
 a=json.loads((r/'full-logits-baseline'/('gate-'+p+'-baseline.json')).read_text())['result']['metrics']
 b=json.loads((r/'full-logits-candidate'/('gate-'+p+'-candidate.json')).read_text())['result']['metrics']
 row={'prompt':p,'promptMatch':a['referenceTranscript']['prompt']['ids']==b['referenceTranscript']['prompt']['ids'],'tokenMatch':a['referenceTranscript']['tokens']['ids']==b['referenceTranscript']['tokens']['ids'],'rows':[]}
 aa={x['position']:x for x in a['batchLogitGate']['rows']};bb={x['position']:x for x in b['batchLogitGate']['rows']}
 assert set(aa)==set(bb)=={0,1,2,4,8,16,32,63}
 for pos in sorted(aa):
  av=array.array('f');av.frombytes(base64.b64decode(aa[pos]['base64']));bv=array.array('f');bv.frombytes(base64.b64decode(bb[pos]['base64']))
  assert len(av)==len(bv)==248320
  diffs=[abs(x-y) if math.isfinite(x) and math.isfinite(y) else math.inf for x,y in zip(av,bv)]
  worst=max(diffs);row['rows'].append({'position':pos,'elements':len(av),'maxAbs':worst,'aboveTolerance':sum(x>0.001 for x in diffs)})
 row['pass']=row['promptMatch'] and row['tokenMatch'] and all(x['aboveTolerance']==0 for x in row['rows']);checks.append(row)
 print(p,row['pass'],'tokens',row['tokenMatch'],'maxAbs',max(x['maxAbs'] for x in row['rows']))
out={'schema':'doppler.full-batched-logit-check.v1','scope':'Separate untimed copied logits from the actual GPU-batched route plus prefill. Exact weights and 64-token teachers. No timing claim.','absoluteTolerance':0.001,'relativeTolerance':0,'checks':checks,'pass':all(x['pass'] for x in checks)}
(r/'full-logit-checks.json').write_text(json.dumps(out,indent=2)+'\n')
sys.exit(0 if out['pass'] else 1)
