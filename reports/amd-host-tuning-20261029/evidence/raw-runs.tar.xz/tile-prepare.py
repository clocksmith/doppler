import pathlib,json
r=pathlib.Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');cases=[]
for m,n in [(2,128),(4,128),(4,64),(2,256),(8,128),(1,128)]:
 d=json.loads((r/'register-long-context.json').read_text());patch=json.loads((r/'runtime-sliced-prefill/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text())['runtime']['inference']['executionPatch']
 patch['addKernels'].append({'key':'prefill_tile','kernel':{'kernel':'fused_matmul_q4_widetile_direct.wgsl','entry':'main','digest':'sha256:915e20bda5a0c6c65697e9df8942dc3fe75f8dec9c2310ec0a39d1677f88598b','constants':{'TILE_M':m,'TILE_N':n}}})
 for op in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:
  patch['set'].append({'section':'prefill','op':op,'kernelKey':'prefill_tile'})
 d['request']['runtimeConfig']['inference']['executionPatch']=patch
 tag=f'tile-{m}x{n}';(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'runtime-sliced-prefill','output':'screen30','cases':cases,'scope':'Remaining long-prefill wall: tune existing direct Q4_K register tile geometry, preserving F32 accumulation and all other candidate settings','sourceDelta':'source16','noDroppedAttempts':True};(r/'plan30.json').write_text(json.dumps(plan,indent=2))
