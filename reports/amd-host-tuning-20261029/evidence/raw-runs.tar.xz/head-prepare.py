import pathlib,json,hashlib
r=pathlib.Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');cases=[]
for lanes in [4,8,16]:
 d=json.loads((r/'partition-code.json').read_text());patch=d['request']['runtimeConfig']['inference']['executionPatch']
 shader='fused_matmul_q4_subgroup.wgsl'
 patch['addKernels'].append({'key':'head_subgroup','kernel':{'kernel':shader,'entry':'main','digest':'sha256:'+hashlib.sha256((r/'runtime-partition-attention/src/gpu/kernels'/shader).read_bytes()).hexdigest(),'constants':{'WORKGROUP_SIZE':256,'COLS_PER_WG':256//lanes,'THREADS_PER_COL_GEMV':lanes,'USE_FULL_BLOCK_FAST_PATH':True}}})
 for op in ['lm_head','lm_head_prefill']:patch['set'].append({'section':'postLayer','op':op,'kernelKey':'head_subgroup'})
 tag='head-direct-'+str(lanes);(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'runtime-partition-attention','output':'screen33','cases':cases,'scope':'Apply the independently checked direct-storage subgroup Q4_K kernel to the materialized vocabulary head; otherwise identical composed candidate; 64 tokens','sourceDelta':'source18','noDroppedAttempts':True};(r/'plan33.json').write_text(json.dumps(plan,indent=2))
