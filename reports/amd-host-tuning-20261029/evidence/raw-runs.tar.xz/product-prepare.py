from pathlib import Path
import json
r=Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');old=Path('$HOME/deco/hatch/pooled-doppler-components-20261029')
suite=json.loads((old/'suite.json').read_text());suite['shared']['pairsPerPrompt']=1
suite['shared']['prompts']=[{'id':'code','text':'Write a detailed Python implementation of two sum, followed by tests and an explanation.'},{'id':'explanation','text':'Explain how a hash map handles collisions and resizing. Include a concrete example and discuss complexity.'},{'id':'arithmetic','text':'Calculate 37 times 24, then explain a second way to check the answer step by step.'},{'id':'long-context','text':('The cache serves repeated reads with occasional scans, a fixed memory budget, and changing popularity. Measure miss ratio and update overhead.\n'*24)+'Explain the tradeoffs between LRU and LFU caching using the supplied repeated workload notes.'}]
suite['scope']='Fresh four-prompt product-format screen. Different reconstructed weights: not equal-weight engine attribution or quality equivalence. 64 tokens, physical Vulkan, same browser and prompt IDs. One pair per prompt; no statistical winner.'
(r/'product-suite-screen.json').write_text(json.dumps(suite,indent=2))
(r/'pooled-hook.js').write_bytes((old/'pooled-hook.js').read_bytes())
s=(old/'run.js').read_text()
s=s.replace("path.join(root,'suite.json')", "path.join(root,'product-suite-screen.json')")
s=s.replace("const pooledRoot=path.join(root,'_work/pooled-runtime'),dopplerRoot=await fs.realpath(path.join(root,'_work/doppler-runtime'));", "const pooledRoot='$HOME/deco/hatch/pooled-doppler-components-20261029/_work/pooled-runtime',dopplerRoot=path.join(root,'runtime-direct');")
s=s.replace("const evidence=path.join(root,'_work/evidence');", "const evidence=path.join(root,'product-screen');await fs.mkdir(evidence);")
s=s.replace("path.join(root,'_work/pooled-weight-cache')", "'$HOME/deco/hatch/pooled-doppler-components-20261029/_work/pooled-weight-cache'")
s=s.replace("path.join(root,'_work/paired-pooled-profile')", "path.join(root,'warm-pooled')")
s=s.replace("path.join(root,'_work/doppler-probe.json')", "path.join(root,'workspace.json')")
s=s.replace("path.join(root,'_work/paired-doppler-profile')", "path.join(root,'warm-candidate')").replace('port:19842','port:19932')
(r/'product-screen.js').write_text(s)
