import json,pathlib
r=pathlib.Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');cases=[]
for prompt in ['code','long-context']:
 d=json.loads((r/('prefill-'+prompt+'-async.json')).read_text())
 d['request']['runtimeConfig']['inference']['session']['useLinearAttentionRegisterPrefill']=True
 tag='register-'+prompt;(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'runtime-prefill','output':'screen22','cases':cases,'scope':'Fixed-width F32 recurrent prefill retaining state rows locally; same order, CPU-reference gate passed; async submit; 64-token screen','sourceDelta':'source11','noDroppedAttempts':True};(r/'plan22.json').write_text(json.dumps(plan,indent=2))
