from pathlib import Path
import json,sys,hashlib
r=Path(sys.argv[1]);src=r/'src/gpu/kernels/gated_delta_fused_decode.wgsl';s=src.read_text()
start=s.index('      // Reuse each decayed and updated scalar');end=s.index('\n    }\n  }\n\n  if (RECURRENT_STATE_COMPONENTS',start)
lines=['      // Fixed K=128 diagnostic: keep each decayed scalar through its update.']
for g in range(32):
 vals=', '.join(f'recurrent_state[recurrent_head_base + {g*4+j}u * head_v_dim + lane]' for j in range(4))
 lines.append(f'      var state{g} = vec4<f32>({vals}) * g_exp;')
 for j,c in enumerate('xyzw'):
  kd=g*4+j
  lines.append(f'      kv_mem = fma(state{g}.{c}, multiply_ordered(shared_k[{kd}u], k_norm_scale), kv_mem);')
lines.append('      let delta = multiply_ordered(v_val - kv_mem, beta);')
for g in range(32):
 vals=', '.join(f'multiply_ordered(shared_k[{g*4+j}u], k_norm_scale)' for j in range(4))
 lines.append(f'      state{g} = fma(vec4<f32>({vals}), vec4<f32>(delta), state{g});')
 for j,c in enumerate('xyzw'):
  kd=g*4+j
  lines.append(f'      recurrent_state[recurrent_head_base + {kd}u * head_v_dim + lane] = state{g}.{c};')
  lines.append(f'      out_value = fma(state{g}.{c}, fma(shared_q[{kd}u], q_norm_scale, 0.0), out_value);')
s=s[:start]+'\n'.join(lines)+s[end:]
s=s.replace('head >= params.num_v_heads || params.num_tokens != 1u || params.q_rep != 1u','head >= params.num_v_heads || params.num_tokens != 1u || params.q_rep != 1u || params.head_k_dim != 128u')
target=r/'src/gpu/kernels/gated_delta_fused_decode_register.wgsl';target.write_text(s)
p=r/'src/config/kernels/registry.json';reg=json.loads(p.read_text());variant=reg['operations']['gated_delta_fused_decode']['variants']['default'];print('old variant',variant)
variant['shader']='gated_delta_fused_decode_register.wgsl' if 'shader' in variant else variant.get('shader')
if variant.get('shader') is None:variant.pop('shader',None)
for key in ['shaderFile','file']:
 if key in variant:variant[key]=target.name
p.unlink();p.write_text(json.dumps(reg,indent=2)+'\n')
print('prototype sha256',hashlib.sha256(target.read_bytes()).hexdigest())
