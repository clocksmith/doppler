from pathlib import Path
import json,subprocess
r=Path('$HOME/.local/state/doppler/amd-host-tuning-20261029')
for lane,source in [('baseline','runtime'),('candidate','runtime-partition-attention')]:
 dest=r/('gate-'+lane);subprocess.run(['cp','-al',str(r/source),str(dest)],check=True)
 p=dest/'src/inference/pipelines/text/generator-steps.js';s=p.read_text();anchor='        logitsBuffer = logits.logitsBuffer;';assert s.count(anchor)==1
 hook='''
        // Diagnostic clone only: retain full vocabulary rows from the actual
        // batched route. Copies split passes; none of these timings are speed evidence.
        if (globalThis.__batchGateActive) {
          globalThis.__batchGateBase ??= state.currentSeqLen;
          const position = state.currentSeqLen + i - globalThis.__batchGateBase + 1;
          if ([1, 2, 4, 8, 16, 32, 63].includes(position)) {
            const copy = device.createBuffer({ size: vocabSize * 4,
              usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC });
            try { recorder.getEncoder().copyBufferToBuffer(logitsBuffer, 0, copy, 0, vocabSize * 4); }
            catch (error) { copy.destroy(); throw error; }
            globalThis.__batchGateCopies.push({ position, elements: vocabSize, buffer: copy });
          }
        }
'''
 s=s.replace(anchor,anchor+hook);p.unlink();p.write_text(s)
 p=dest/'src/inference/browser-harness/benchmark-execution.js';s=p.read_text();s="import { readBuffer as readGateBuffer } from '../../memory/buffer-pool.js';\n"+s
 anchor='    let lastGpuUniformCache = null;\n    for (let i = 0; i < warmupRuns + timedRuns; i++) {';assert s.count(anchor)==1
 s=s.replace(anchor,anchor+'''
      globalThis.__batchGateActive = i >= warmupRuns;
      globalThis.__batchGateBase = null;
      globalThis.__batchGateCopies = [];
''')
 anchor='  const loadTimings = resolvePipelineLoadTimings(harness.pipeline);';assert s.count(anchor)==1
 hook='''
  globalThis.__batchGateActive = false;
  const rows = [];
  const serialize = (position, values) => {
    const bytes = new Uint8Array(values.buffer, values.byteOffset, values.byteLength);
    let encoded = '';
    for (let i = 0; i < bytes.length; i += 16384) encoded += String.fromCharCode(...bytes.subarray(i, i + 16384));
    rows.push({ position, elements: values.length, base64: btoa(encoded) });
  };
  for (const copy of globalThis.__batchGateCopies ?? []) {
    try { serialize(copy.position, new Float32Array(await readGateBuffer(copy.buffer, copy.elements * 4))); }
    finally { copy.buffer.destroy(); }
  }
  const gatePipeline = harness.pipeline.generator;
  const gateOptions = gatePipeline._resolveStepOptions({ temperature: 0, topK: 1, topP: 1,
    repetitionPenalty: 1, useChatTemplate: false, benchmark: false });
  harness.pipeline.reset();
  serialize(0, await gatePipeline._prefillInputIdsToLogits(metrics.referenceTranscript.prompt.ids, gateOptions));
  metrics.batchLogitGate = { rows, scope: 'Untimed actual batched materialized-head logits plus prefill; copied before scratch reuse; no timing claim' };
'''
 s=s.replace(anchor,hook+'\n'+anchor);p.unlink();p.write_text(s)
# Freeze exact configs before any diagnostic execution.
cases=[]
for prompt in ['code','explanation','arithmetic','long-context']:
 for lane in ['baseline','candidate']:
  source=r/('four-'+prompt+'-control.json') if lane=='baseline' else r/('partition-'+prompt+'.json')
  d=json.loads(source.read_text());inf=d['request']['runtimeConfig']['inference'];inf['session']['useGreedyLmHeadArgmaxFusion']=False
  tag='gate-'+prompt+'-'+lane;(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
for lane in ['baseline','candidate']:
 plan={'runtime':'gate-'+lane,'output':'full-logits-'+lane,'cases':[x for x in cases if x.endswith('-'+lane)],'scope':'UNTIMED numerical gate, copied batched-route logits at positions 1,2,4,8,16,32,63 plus prefill0. Exact token IDs and absolute full-logit tolerance .001. No speed evidence.','noDroppedAttempts':True}
 (r/('plan-gate-'+lane+'.json')).write_text(json.dumps(plan,indent=2))
