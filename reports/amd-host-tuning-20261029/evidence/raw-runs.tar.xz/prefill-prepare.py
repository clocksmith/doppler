import json,pathlib
r=pathlib.Path('$HOME/.local/state/doppler/amd-host-tuning-20261029');cases=[]
for prompt in ['code','long-context']:
 for kind in ['async','direct4','direct8','subgroup8']:
  d=json.loads((r/'product-screen'/(prompt+'-pair0-doppler-config.json')).read_text())
  inf=d['request']['runtimeConfig']['inference'];inf['session']['prefillChunkSubmitMode']='async'
  if kind in ['direct4','direct8']:
   direct={'key':'q4_prefill_direct','kernel':{'kernel':'fused_matmul_q4_widetile_direct.wgsl','entry':'main','digest':'sha256:915e20bda5a0c6c65697e9df8942dc3fe75f8dec9c2310ec0a39d1677f88598b','constants':{'TILE_M':int(kind[-1]),'TILE_N':256}}}
  elif kind=='subgroup8':
   profile=json.loads((r/'runtime-direct/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text());direct=profile['runtime']['inference']['executionPatch']['addKernels'][1];direct={**direct,'key':'q4_prefill_direct'}
  if kind!='async':
   patch=json.loads((r/'runtime-direct/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text())['runtime']['inference']['executionPatch']
   patch['addKernels'].append(direct)
   for op in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:
    patch['set'].append({'section':'prefill','op':op,'kernelKey':'q4_prefill_direct'})
   inf['executionPatch']=patch
  tag=f'prefill-{prompt}-{kind}';(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'runtime-direct','output':'screen21','cases':cases,'scope':'Prefill boundary: async chunk submission and existing direct or new subgroup kernel on short and 655-token prompts; 64 generated tokens; no other delta','noDroppedAttempts':True,'sourceDelta':'source10'}
(r/'plan21.json').write_text(json.dumps(plan,indent=2))
