/**
 * Layer pipeline plan compiler.
 *
 * Converts JSON-configured step lists into normalized, validated plans
 * for execution inside processLayer.
 *
 * @module inference/pipelines/text/layer-plan
 */

import type {
  LayerPipelineSchema,
  LayerPipelineOp,
  LayerPipelinePhase,
  LayerPipelineNormWeight,
  LayerPipelineDtype,
  ProbeStage,
} from '../../../config/schema/index.js';

export interface CompiledLayerPipelineStep {
  op: LayerPipelineOp;
  phase: LayerPipelinePhase;
  src: string;
  dst: string;
  name?: string;
  weight?: LayerPipelineNormWeight;
  residual?: string | null;
  a?: string;
  b?: string;
  variant?: 'auto' | 'dense' | 'moe';
  skipInputNorm?: boolean;
  fromDtype?: LayerPipelineDtype | null;
  toDtype?: LayerPipelineDtype;
  inputDtype?: LayerPipelineDtype;
  outputDtype?: LayerPipelineDtype;
  kvDtype?: LayerPipelineDtype;
  probeStage?: ProbeStage;
}

export interface LayerPipelineOverride {
  layers: number[];
  steps: CompiledLayerPipelineStep[];
}

export interface CompiledLayerPipeline {
  steps: ReadonlyArray<CompiledLayerPipelineStep>;
  overrides: ReadonlyArray<{
    layers: ReadonlyArray<number>;
    steps: ReadonlyArray<CompiledLayerPipelineStep>;
  }>;
  stepsByLayer: ReadonlyArray<{
    prefill: ReadonlyArray<CompiledLayerPipelineStep>;
    decode: ReadonlyArray<CompiledLayerPipelineStep>;
  }>;
  source: 'model' | 'runtime';
}

export function resolveLayerPipeline(
  modelPlan: LayerPipelineSchema | null | undefined,
  runtimePlan: LayerPipelineSchema | null | undefined,
  numLayers: number
): CompiledLayerPipeline | null;

export function getLayerPlanSteps(
  plan: CompiledLayerPipeline,
  layerIdx: number
): ReadonlyArray<CompiledLayerPipelineStep> | {
  prefill: ReadonlyArray<CompiledLayerPipelineStep>;
  decode: ReadonlyArray<CompiledLayerPipelineStep>;
};

export function filterLayerPlanStepsByPhase(
  steps: ReadonlyArray<CompiledLayerPipelineStep> | {
    prefill: ReadonlyArray<CompiledLayerPipelineStep>;
    decode: ReadonlyArray<CompiledLayerPipelineStep>;
  },
  isPrefill: boolean
): ReadonlyArray<CompiledLayerPipelineStep>;
