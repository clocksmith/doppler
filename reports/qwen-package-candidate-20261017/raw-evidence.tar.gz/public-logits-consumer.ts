type PackageExport0 = typeof import("doppler-gpu/run");
type PackageExport1 = typeof import("doppler-gpu");
type PackageExport2 = typeof import("doppler-gpu/runtime");
type PackageExport3 = typeof import("doppler-gpu/generation-contract");
type PackageExport4 = typeof import("doppler-gpu/choice-scoring-contract");
type PackageExport5 = typeof import("doppler-gpu/host");
type PackageExport6 = typeof import("doppler-gpu/serve");
type PackageExport7 = typeof import("doppler-gpu/capsule");
type PackageExport8 = typeof import("doppler-gpu/compat");
type PackageExport9 = typeof import("doppler-gpu/provider");
type PackageExport10 = typeof import("doppler-gpu/tooling");
type PackageExport11 = typeof import("doppler-gpu/tooling/storage");
type PackageExport12 = typeof import("doppler-gpu/tooling/device");
type PackageExport13 = typeof import("doppler-gpu/tooling/manifest");
type PackageExport14 = typeof import("doppler-gpu/tooling/runtime");
type PackageExport15 = typeof import("doppler-gpu/tooling/evidence");
type PackageExport16 = typeof import("doppler-gpu/structured");
type PackageExport17 = typeof import("doppler-gpu/client/model-manager");
type PackageExport18 = typeof import("doppler-gpu/electron");
type PackageExport19 = typeof import("doppler-gpu/models/qwen3");
type PackageExport20 = typeof import("doppler-gpu/models/gemma3");
type PackageExport21 = typeof import("doppler-gpu/models/gemma4");
type PackageExport22 = typeof import("doppler-gpu/models/diffusiongemma");
type PackageExport23 = typeof import("doppler-gpu/models/embeddinggemma");
type PackageExport24 = typeof import("doppler-gpu/tooling-experimental");
type PackageExport25 = typeof import("doppler-gpu/loaders");
type PackageExport26 = typeof import("doppler-gpu/orchestration");
type PackageExport27 = typeof import("doppler-gpu/generation");
type PackageExport28 = typeof import("doppler-gpu/training");
type PackageExport29 = typeof import("doppler-gpu/diffusion");
type PackageExport30 = typeof import("doppler-gpu/energy");
type PackageExport31 = typeof import("doppler-gpu/partitions");
// @ts-expect-error internal partition helpers must not leak through the minimal runtime
import { createLayerPartitionPlan } from 'doppler-gpu';
// @ts-expect-error runtime alias must expose the same declared minimal contract
import { serializeActivationFrame } from 'doppler-gpu/runtime';
// @ts-expect-error Run must keep the same public boundary
import { serializeActivationFrame as leakedRunHelper } from 'doppler-gpu/run';
import { createDopplerRun, RUN_CORE_VERSION, resolveEmbeddingBatchSemantics } from 'doppler-gpu/run';
import type { RunPorts, DopplerRun, DopplerRunSession, EmbeddingBatchSemantics } from 'doppler-gpu/run';
declare const embeddingManifest: Record<string, unknown>;
const embeddingBatchSemantics: EmbeddingBatchSemantics = resolveEmbeddingBatchSemantics(embeddingManifest);
// @ts-expect-error Embedding semantics cannot authorize generation subdivision.
embeddingBatchSemantics.operation.name = 'generate';
import type { ResidentPartitionSession, ResidentPartitionDescriptor, ResidentPartitionARequest,
  ResidentPartitionAResult, ResidentPartitionBRequest, ResidentPartitionBResult,
  ResidentPartitionTokenizationRequest, ResidentPartitionTokenizationResult,
  ResidentPartitionMetrics, PartitionTiming, ResidentRecoveryCapabilities } from 'doppler-gpu/partitions';
declare const resident: ResidentPartitionSession;
declare const aRequest: ResidentPartitionARequest;
declare const bRequest: ResidentPartitionBRequest;
declare const tokenizationRequest: ResidentPartitionTokenizationRequest;
const descriptor: ResidentPartitionDescriptor = resident.getDescriptor();
const generationDigest: string = descriptor.generationDigest;
const recovery: ResidentRecoveryCapabilities = resident.getRecoveryCapabilities();
// @ts-expect-error Capability reports cannot be changed to enable recovery.
recovery.checkpointImport = true;
// @ts-expect-error Readiness requires runtime admission, not a type assertion.
const assumedReady: true = descriptor.ready;
const aResult: Promise<ResidentPartitionAResult> = resident.executeGroup0(aRequest);
const bResult: Promise<ResidentPartitionBResult> = resident.executeGroup1(bRequest);
const tokenization: Promise<ResidentPartitionTokenizationResult> = resident.tokenize(tokenizationRequest);
bResult.then(result => { const metrics: ResidentPartitionMetrics = result.metrics;
  const timing: PartitionTiming = metrics; return timing; });
import type { DopplerGenerationResult, DopplerScopedModelSession } from 'doppler-gpu/compat';
import type { GenerationCompletion } from 'doppler-gpu/generation-contract';
declare const scopedSession: DopplerScopedModelSession;
scopedSession.generate('prompt').then((result: DopplerGenerationResult) => {
  const completion: GenerationCompletion | null = result.completion; return completion;
});
async function readScopedCompletion() {
  for await (const event of scopedSession.stream('prompt')) {
    if (event.type === 'complete') {
      const completion: GenerationCompletion | null = event.completion; return completion;
    }
  }
}
import { createKernelRegistry, createRuleRegistry } from 'doppler-gpu/tooling/runtime';
const mutableRequires: Array<'shader-f16' | 'subgroups'> = [];
const mutableWorkgroup: [number, number, number] = [256, 1, 1];
const kernels = createKernelRegistry({ extensions: { gelu: { variants: {
  consumer: { wgsl: 'gelu.wgsl', entryPoint: 'main', workgroup: mutableWorkgroup, requires: mutableRequires },
} } } });
mutableRequires.push('shader-f16');
mutableWorkgroup[0] = 128;
const config = kernels.getKernelConfig('gelu', 'consumer');
// @ts-expect-error Resolved kernel properties are frozen.
config.shaderFile = 'replacement.wgsl';
// @ts-expect-error Resolved workgroup tuples are frozen.
config.workgroupSize[0] = 1;
// @ts-expect-error Resolved requirements are frozen.
config.requires.push('probe');
// @ts-expect-error Resolved binding entries are frozen.
config.bindings[0].index = 99;
// @ts-expect-error Registry maps are frozen.
kernels.configs.gelu = {};
if (config.uniforms) {
  // @ts-expect-error Nested resolved uniform fields are frozen.
  config.uniforms.fields[0].offset = 99;
}
const mutableRules = [{ match: {}, value: { nested: ['a'] } }];
const rules = createRuleRegistry({ extensions: [{ domain: 'consumer', group: 'test', rules: { choice: mutableRules } }] });
mutableRules[0].value.nested.push('b');
const resolvedRules = rules.getRuleSet('consumer', 'test', 'choice');
// @ts-expect-error Resolved rule arrays are frozen.
resolvedRules.push(mutableRules[0]);
// @ts-expect-error Resolved rule entries are frozen.
resolvedRules[0].match = {};
// @ts-expect-error Nested resolved rule matches are frozen.
resolvedRules[0].match.feature = 'changed';
// @ts-expect-error Rule registry maps are frozen.
rules.ruleSets.consumer.test = {};
declare const runPorts: RunPorts;
const run: DopplerRun = createDopplerRun(runPorts);
const coreVersion: string = RUN_CORE_VERSION;
const runSession: Promise<DopplerRunSession> = run.openCapsule('model');
const legacyRunSession: Promise<DopplerRuntimeSession> = runSession;
import { createDocumentSearchRenderer, createDocumentSearchHostRenderer } from './renderer.js';
import { openCapsule } from 'doppler-gpu/host';
import type { DopplerCapsuleOpenOptions } from 'doppler-gpu/host';
import type { CapsuleRetainedLocalUse, CapsuleReleasePolicy } from 'doppler-gpu/capsule';
declare const retainedDecision: CapsuleRetainedLocalUse;
declare const releasePolicy: CapsuleReleasePolicy;
const retainedHostSession = openCapsule('/retained/capsule.json', {
  ...trustOptions, releasePolicy: { ...releasePolicy, retainedLocalUse: retainedDecision },
});
retainedHostSession.then(value => value.verification.lifecycle?.authorization.mode);
import { registerDocumentSearchReleaseMain } from './main.js';
import { createDocumentSearchReleaseStore, createDocumentSearchCheckpointStore, prepareDocumentSearchReleaseOptions } from './release-storage.js';
import type { RuntimePorts, CapsuleRerankRequest, CapsuleEmbeddingRequest, CapsuleEmbeddingResult, DopplerRuntimeSession } from 'doppler-gpu';
import type { ElectronReleaseStateCoordinator } from 'doppler-gpu/electron';
import { createCapsuleServeHandler } from 'doppler-gpu/serve';
import type { CapsuleServePolicy } from 'doppler-gpu/serve';
declare const servingPolicy: CapsuleServePolicy;
declare const ports: RuntimePorts;
declare const releaseState: ElectronReleaseStateCoordinator;
declare const request: CapsuleRerankRequest;
declare const trustOptions: DopplerCapsuleOpenOptions;
const hostRenderer = createDocumentSearchHostRenderer(releaseState, trustOptions);
hostRenderer.rerank(request).then(receipt => receipt.capsule.semanticRoot);
const hostSession: Promise<DopplerRuntimeSession> = openCapsule('https://application.example/capsule.json', trustOptions);
const renderer = createDocumentSearchRenderer(releaseState, ports);
renderer.rerank(request).then(receipt => receipt.capsule.semanticRoot);
const session: Promise<DopplerRuntimeSession> = renderer.openCurrent();
session.then(value => {
  const handler = createCapsuleServeHandler({ session: value, policy: servingPolicy, token: 'application-secret' });
  const drained: Promise<void> = handler.close();
  // @ts-expect-error Serving requires explicit authentication.
  createCapsuleServeHandler({ session: value, policy: servingPolicy });
});
declare const embeddingRequest: CapsuleEmbeddingRequest;
const embedding: Promise<CapsuleEmbeddingResult> = session.then(value => value.embed(embeddingRequest));
session.then(value => {
  // @ts-expect-error Capsule embedding requires an application-bound request.
  value.embed('document');
  // @ts-expect-error Pooling overrides cannot change signed semantics.
  value.embed({ ...embeddingRequest, options: { embeddingMode: 'mean' } });
});
// @ts-expect-error Positional reranking cannot omit the application binding.
renderer.rerank('query', ['document']);
// @ts-expect-error Host ports must be explicit.
createDocumentSearchRenderer(releaseState);
type MainOptions = Parameters<typeof registerDocumentSearchReleaseMain>[0];
const stateStore: MainOptions['stateStore'] = createDocumentSearchReleaseStore('/private/application/releases.json');
const checkpointStore = createDocumentSearchCheckpointStore('/private/application/checkpoint.json');
declare const releaseOptions: Parameters<typeof prepareDocumentSearchReleaseOptions>[0];
prepareDocumentSearchReleaseOptions({ ...releaseOptions, checkpointStore }).then(options => {
  openCapsule('https://application.example/capsule.json', { ...trustOptions, ...options });
});

// Public logits remain available through the installed model handle types.
async function logitsContract(model: Awaited<ReturnType<typeof import('doppler-gpu/compat').load>>) {
  const prefill = await model.advanced.prefillWithLogits([{role: 'user', content: 'test'}], {useChatTemplate: false});
  const logits: Float32Array = prefill.logits;
  const decoded = await model.advanced.decodeStepLogits([7], {useChatTemplate: false});
  const next: Float32Array = decoded.logits;
  return [logits, next];
}
