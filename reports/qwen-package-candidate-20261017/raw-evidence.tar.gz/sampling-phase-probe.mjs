import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root=resolve(process.argv[2]);
const imp=path=>import(pathToFileURL(resolve(root,path)).href);
const {probeNodeGPU}=await imp('tests/helpers/gpu-probe.js');
const {getDevice,destroyDevice}=await imp('src/gpu/device.js');
const {releaseNodeWebGPU}=await imp('src/tooling/node-webgpu.js');
const {readBuffer}=await imp('src/memory/buffer-pool.js');
const probe=await probeNodeGPU();if(!probe.ready)throw Error(probe.reason);
const device=getDevice(), buffers=[];
const make=(size,usage)=>{const b=device.createBuffer({size,usage});buffers.push(b);return b;};
try {
 const uniform=make(32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
 const values=new Float32Array(512).fill(-100);values.set([3,2,1,0]);
 const logits=make(values.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);device.queue.writeBuffer(logits,0,values);
 const output=make(4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC);
 const indices=make(48,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC);
 const scores=make(48,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC);
 const bytes=new ArrayBuffer(32),v=new DataView(bytes);
 v.setUint32(0,512,true);v.setUint32(4,4,true);v.setFloat32(8,1,true);v.setFloat32(12,0.75,true);v.setUint32(16,510,true);v.setFloat32(20,0,true);v.setUint32(24,0,true);v.setFloat32(28,1,true);device.queue.writeBuffer(uniform,0,bytes);
 const layout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:'read-only-storage'}},...[2,3,4].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:'storage'}}))]});
 const group=device.createBindGroup({layout,entries:[uniform,logits,output,indices,scores].map((buffer,binding)=>({binding,resource:{buffer}}))});
 const source=await readFile(process.argv[3] ?? resolve(root,'src/gpu/kernels/sample.wgsl'),'utf8');const module=device.createShaderModule({code:source});
 for(const [entry,count] of [['find_topk_phase1',2],['find_topk_phase2',1],['softmax_and_sample',1]]) {
  const pipeline=await device.createComputePipelineAsync({layout:device.createPipelineLayout({bindGroupLayouts:[layout]}),compute:{module,entryPoint:entry}});
  const enc=device.createCommandEncoder(),pass=enc.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,group);pass.dispatchWorkgroups(count);pass.end();device.queue.submit([enc.finish()]);
  console.log(JSON.stringify({entry,indices:Array.from(new Uint32Array(await readBuffer(indices))),scores:Array.from(new Float32Array(await readBuffer(scores))),output:Array.from(new Uint32Array(await readBuffer(output)))}));
 }
} finally {for(const b of buffers)b.destroy();destroyDevice();releaseNodeWebGPU();}
