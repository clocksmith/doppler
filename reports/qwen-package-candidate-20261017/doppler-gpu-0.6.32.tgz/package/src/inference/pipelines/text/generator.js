import '../../../gpu/device.js'; // Preserve declared device initialization side effects.
import { prefillWithToken, decodeStepWithToken } from './generator/capsule-generation.js';
import { releaseBuffer } from '../../../memory/buffer-pool.js';

// Pipeline sub-modules
import { sample, applyRepetitionPenalty, applyPresencePenalty } from './sampling.js';
import { isStopToken } from './init.js';
import { decodeStepLogits } from './generator-steps.js';
import { buildLayerContext, debugCheckBuffer as debugCheckBufferHelper } from './generator/session-context.js';
import { getLogitsConfig, getLogitsWeights } from './generator/logits-config.js';
import { releaseSharedAttentionState } from './generator/attention-lifecycle.js';
import { resetSequenceState } from './sequence-state.js';
import {
  assertTokenIdsInRange,
  assertTokenIdInRange,
  resolveStepOptions,
  getFinalNormWeights,
  extractEmbeddingFromHidden,
  extractTokenEmbeddingsFromHidden,
} from './generator-runtime.js';

import { samplingSeedForToken } from '../../token-sampling.js';
import { createGenerationOutputDecoder, decodeGenerationStream } from '../../generation-output.js';
import { matchesStopSequence } from './stopping.js';
import { resolveDeferredRoundingWindowTokens } from './finiteness-policy.js';
import { resetActiveExecutionPlan, resolveActiveExecutionPlan } from './execution-plan.js';
import { resetLinearAttentionSequence } from './linear-attention.js';

// Extracted standalone helpers
import { resolvePromptInput } from './generator/prompt-input.js';
import { resolvePrefillTokenChunkSize } from './generator/prefill-policy.js';
import { usesReplayPrefillDecode } from './generator-decode-policy.js';
import {
  _createDiffusionGemmaSelfConditioningEmbeddings as _createDiffusionGemmaSelfConditioningEmbeddingsImpl,
  _createDiffusionGemmaSelfConditioningSoftEmbeddingState as _createDiffusionGemmaSelfConditioningSoftEmbeddingStateImpl,
  computeDiffusionGemmaCanvasLogits as computeDiffusionGemmaCanvasLogitsImpl,
  computeDiffusionGemmaCanvasStep as computeDiffusionGemmaCanvasStepImpl,
} from './generator/diffusion.js';
import {
  _replayPrefillDecodeLogits as _replayPrefillDecodeLogitsImpl,
  _shouldUseFinitenessFallback as _shouldUseFinitenessFallbackImpl,
  _recreateKVCacheForExecutionPlan as _recreateKVCacheForExecutionPlanImpl,
  _openFinitenessFallbackWindow as _openFinitenessFallbackWindowImpl,
  _closeFinitenessFallbackWindow as _closeFinitenessFallbackWindowImpl,
  _consumeFinitenessFallbackToken as _consumeFinitenessFallbackTokenImpl,
  _beginFinitenessFallback as _beginFinitenessFallbackImpl,
  _endFinitenessFallback as _endFinitenessFallbackImpl,
  _retryWithFinitenessFallback as _retryWithFinitenessFallbackImpl,
  _retryWithPersistentFinitenessFallback as _retryWithPersistentFinitenessFallbackImpl,
  _retryDecodeStepWithFinitenessWindow as _retryDecodeStepWithFinitenessWindowImpl,
} from './generator/recovery.js';
import {
  prefillKVOnly as prefillKVOnlyImpl,
  prefillForLoRATraining as prefillForLoRATrainingImpl,
  prefillWithEmbedding as prefillWithEmbeddingImpl,
  prefillWithLogits as prefillWithLogitsImpl,
  prefillWithTokenLogits as prefillWithTokenLogitsImpl,
  prefillWithTokenLogitsFromKV as prefillWithTokenLogitsFromKVImpl,
  generateWithPrefixKV as generateWithPrefixKVImpl,
} from './generator/training.js';
import {
  _generateTokensInternal as _generateTokensInternalImpl,
  generateTokenIds as generateTokenIdsImpl,
  _runDecodeLoop as _runDecodeLoopImpl,
  _decodeStep as _decodeStepImpl,
  decodeStepLogits as decodeStepLogitsImpl,
  advanceWithToken as advanceWithTokenImpl,
  advanceWithTokenAndEmbedding as advanceWithTokenAndEmbeddingImpl,
  _generateNTokensGPU as _generateNTokensGPUImpl,
} from './generator/decode-runtime.js';
import {
  _commitPrefillHiddenChunk as _commitPrefillHiddenChunkImpl,
  _prefillInputIdsToLogits as _prefillInputIdsToLogitsImpl,
  _prefillPromptToLogits as _prefillPromptToLogitsImpl,
  _prefillToHidden as _prefillToHiddenImpl,
  _prefill as _prefillImpl,
} from './generator/prefill-runtime.js';
export { resolvePrefillChunkSubmitMode } from './generator/text.js';

export class PipelineGenerator {

  _state;
  _finitenessFallbackWindow;

  _assertTokenIdsInRange(tokenIds, context = 'encode') {
    assertTokenIdsInRange(this._state, tokenIds, context);
  }

  _assertTokenIdInRange(tokenId, context = 'token') {
    assertTokenIdInRange(this._state, tokenId, context);
  }

  constructor(state) {
    this._state = state;
    this._finitenessFallbackWindow = null;
  }

  _resolveDeferredRoundingWindowTokens() {
    const activePlan = resolveActiveExecutionPlan(this._state);
    return activePlan?.deferredRoundingWindowTokens
      ?? resolveDeferredRoundingWindowTokens(this._state.runtimeConfig?.inference?.compute);
  }

  _getEffectiveActivationDtype() {
    return resolveActiveExecutionPlan(this._state).activationDtype;
  }

  _hasFinitenessFallbackWindow() {
    return this._finitenessFallbackWindow !== null;
  }

  _resetReplayPrefillRuntimeState() {
    this._state.kvCache?.clear?.();
    this._state.linearAttentionRuntime = resetLinearAttentionSequence(this._state.linearAttentionRuntime);
    this._state.currentSeqLen = 0;
  }

  resetGenerationState() {
    if (this._state.isGenerating) {
      throw new Error('InferencePipeline.resetGenerationState: cannot reset while generation is in progress');
    }
    this._resetReplayPrefillRuntimeState();
    this._resetDecodeRuntimeState();
  }

  async _replayPrefillDecodeLogits(currentIds, opts) {
    return _replayPrefillDecodeLogitsImpl.apply(this, arguments);
  }

  _shouldUseFinitenessFallback(error, contextLabel) {
    return _shouldUseFinitenessFallbackImpl.apply(this, arguments);
  }

  _recreateKVCacheForExecutionPlan(plan, reasonLabel) {
    return _recreateKVCacheForExecutionPlanImpl.apply(this, arguments);
  }

  _openFinitenessFallbackWindow(opts, reasonLabel, tokenCount, rollbackSeqLen = undefined) {
    return _openFinitenessFallbackWindowImpl.apply(this, arguments);
  }

  _closeFinitenessFallbackWindow(opts) {
    return _closeFinitenessFallbackWindowImpl.apply(this, arguments);
  }

  _consumeFinitenessFallbackToken(opts) {
    return _consumeFinitenessFallbackTokenImpl.apply(this, arguments);
  }

  _resolveStepOptions(options = {}) {
    return resolveStepOptions(this._state, options);
  }

  _resetDecodeRuntimeState() {
    this._state.stats.prefillProfileSteps = [];
    this._state.stats.decodeMode = null;
    this._state.stats.batchGuardReason = null;
    this._state.stats.decodeProfileSteps = [];
    this._state.stats.ttftMs = 0;
    this._state.stats.decodeTimeMs = 0;
    this._state.stats.prefillRecordMs = 0;
    this._state.stats.prefillRecordOps = 0;
    this._state.stats.prefillRecordPasses = 0;
    this._state.stats.prefillRecordOpLabels = {};
    this._state.stats.prefillSubmitWaitMs = 0;
    this._state.stats.decodeRecordMs = 0;
    this._state.stats.decodeRecordOps = 0;
    this._state.stats.decodeRecordPasses = 0;
    this._state.stats.decodeRecordOpLabels = {};
    this._state.stats.decodeSubmitWaitMs = 0;
    this._state.stats.decodeReadbackWaitMs = 0;
    this._state.stats.decodeReadbackMapWaitMs = 0;
    this._state.stats.decodeReadbackCleanupMs = 0;
    this._state.stats.decodeReadbackCopyMs = 0;
    this._state.decodeStepCount = 0;
    this._state.disableRecordedLogits = false;
    this._state.disableFusedDecode = false;
    this._state.batchingStats = {
      batchedForwardCalls: 0,
      unbatchedForwardCalls: 0,
      totalBatchedTimeMs: 0,
      totalUnbatchedTimeMs: 0,
      gpuSubmissions: 0,
      requestedBatchTokens: 0,
      effectiveBatchTokens: 0,
      executedBatchTokens: 0,
      resolvedBatchTokens: 0,
      maxBatchTokenCap: null,
      batchClampCount: 0,
    };
    resetActiveExecutionPlan(this._state);
    this._state.decodeRing?.reset();
  }

  _getDecodeHelpers(debugCheckBuffer) {
    return {
      buildLayerContext: (recorder, isDecodeMode, debugLayers, executionPlan) =>
        buildLayerContext(this._state, recorder, isDecodeMode, debugLayers, debugCheckBuffer, executionPlan),
      getLogitsWeights: () => getLogitsWeights(this._state),
      getLogitsConfig: () => getLogitsConfig(this._state),
      releaseSharedAttentionState,
      debugCheckBuffer,
    };
  }

  async _getFinalNormWeights() {
    return getFinalNormWeights(this._state);
  }

  _extractEmbeddingFromHidden(hiddenStates, numTokens, hiddenSize, embeddingMode, finalNormWeights, config) {
    return extractEmbeddingFromHidden(
      hiddenStates,
      numTokens,
      hiddenSize,
      embeddingMode,
      finalNormWeights,
      config,
      this._state.embeddingPostprocessor,
      null,
      this._state.weights.get('final_norm_bias') ?? null
    );
  }

  _extractTokenEmbeddingsFromHidden(hiddenStates, numTokens, hiddenSize, finalNormWeights, config) {
    return extractTokenEmbeddingsFromHidden(
      hiddenStates,
      numTokens,
      hiddenSize,
      finalNormWeights,
      config,
      this._state.weights.get('final_norm_bias') ?? null
    );
  }

  _resolvePromptTokenIds(prompt, useChatTemplate, contextLabel) {
    const processedPrompt = resolvePromptInput(this._state, prompt, useChatTemplate, contextLabel);
    const inputIds = this._state.tokenizer.encode(processedPrompt);
    this._assertTokenIdsInRange(inputIds, `${contextLabel}.encode`);
    return inputIds;
  }

  _resolvePromptOrInputIds(prompt, useChatTemplate, contextLabel, explicitInputIds = null) {
    if (Array.isArray(explicitInputIds)) {
      this._assertTokenIdsInRange(explicitInputIds, `${contextLabel}.inputIds`);
      return explicitInputIds;
    }
    return this._resolvePromptTokenIds(prompt, useChatTemplate, contextLabel);
  }

  _sampleNextTokenFromLogits(logits, generatedIds, opts) {
    const sampledLogits = Float32Array.from(logits);
    applyRepetitionPenalty(sampledLogits, generatedIds, opts.repetitionPenalty, opts.repetitionPenaltyWindow);
    if (opts.presencePenalty) {
      applyPresencePenalty(sampledLogits, generatedIds, opts.presencePenalty, opts.repetitionPenaltyWindow);
    }
    // Optional pre-sample logit mask. Callers pass `opts.logitMaskFn` to
    // implement grammar/schema-constrained decoding. The hook receives the
    // mutable logit buffer (after repetition penalty) plus the running token
    // sequence so it can track parse state across decode steps.
    if (typeof opts?.logitMaskFn === "function") {
      if (!Number.isSafeInteger(opts.promptTokenCount) || opts.promptTokenCount < 0 || opts.promptTokenCount > generatedIds.length) {
        throw new Error('[Pipeline] logitMaskFn requires an explicit prompt token boundary.');
      }
      const result = opts.logitMaskFn(sampledLogits, {
        generatedIds: generatedIds.slice(opts.promptTokenCount),
        tokenizer: this._state.tokenizer ?? null,
        vocabSize: this._state.modelConfig?.vocabSize ?? sampledLogits.length,
      });
      if (result && typeof result.then === 'function') {
        Promise.resolve(result).catch(() => {});
        throw new Error('[Pipeline] logitMaskFn must be synchronous.');
      }
    }
    const padTokenId = this._state.tokenizer?.getSpecialTokens?.()?.pad;
    const tokenId = sample(sampledLogits, {
      temperature: opts.temperature,
      topP: opts.topP,
      topK: opts.topK,
      padTokenId,
      seed: opts.temperature === 0 ? opts.seed
        : samplingSeedForToken(opts.seed, generatedIds.length - opts.promptTokenCount),
      suppressTokenIds: opts.suppressTokenIds,
    });
    if (typeof opts.onLogits === 'function') {
      opts.onLogits(sampledLogits, {
        tokenId,
        inputTokenCount: Array.isArray(generatedIds) ? generatedIds.length : null,
      });
    }
    return tokenId;
  }

  _resolvePrefillTokenChunkSize(inputIds) {
    return resolvePrefillTokenChunkSize(this._state, inputIds.length);
  }

  async _commitPrefillHiddenChunk(prefillResult) {
    return _commitPrefillHiddenChunkImpl.apply(this, arguments);
  }

  async _prefillInputIdsToLogits(inputIds, opts) {
    return _prefillInputIdsToLogitsImpl.apply(this, arguments);
  }

  async _prefillPromptToLogits(prompt, opts, contextLabel) {
    return _prefillPromptToLogitsImpl.apply(this, arguments);
  }

  async _decodeStepToLogits(currentIds, opts) {
    if (usesReplayPrefillDecode(this._state)) {
      return this._replayPrefillDecodeLogits(currentIds, opts);
    }
    const debugCheckBuffer = this._state.debug
      ? (buffer, label, numTokens, expectedDim) =>
        debugCheckBufferHelper(this._state, buffer, label, numTokens, expectedDim)
      : undefined;
    return decodeStepLogits(this._state, currentIds, opts, this._getDecodeHelpers(debugCheckBuffer));
  }

  async _decodeNextTokenViaLogits(currentIds, opts) {
    const stepResult = await this._decodeStepToLogits(currentIds, opts);
    try {
      return this._sampleNextTokenFromLogits(stepResult.logits, currentIds, opts);
    } finally {
      if (stepResult.logitsBuffer) releaseBuffer(stepResult.logitsBuffer);
    }
  }

  _matchesStopSequence(generatedIds, stopSequenceStart, stopSequences) {
    if (!Array.isArray(stopSequences) || stopSequences.length === 0) {
      return false;
    }
    return matchesStopSequence(this._state.tokenizer, generatedIds, stopSequenceStart, stopSequences,
      this._state.modelConfig?.reasoningOutput);
  }

  _shouldStopAfterAppendedToken(generatedIds, tokenId, opts, runtime) {
    if (isStopToken(tokenId, runtime.stopTokenIds, runtime.eosToken)) {
      return true;
    }
    return this._matchesStopSequence(generatedIds, runtime.stopSequenceStart, opts.stopSequences);
  }

  _recordStopReason(reason, tokenId = null) {
    this._state.stats.stopReason = reason;
    this._state.stats.stopTokenId = Number.isInteger(tokenId) ? tokenId : null;
  }

  async *_generateTokensInternal(prompt, options = {}, mode = 'text') {
    return yield* _generateTokensInternalImpl.apply(this, arguments);
  }

  _beginFinitenessFallback(opts, reasonLabel, rollbackSeqLen = undefined) {
    return _beginFinitenessFallbackImpl.apply(this, arguments);
  }

  _endFinitenessFallback(opts, original) {
    return _endFinitenessFallbackImpl.apply(this, arguments);
  }

  async _retryWithFinitenessFallback(opts, reasonLabel, retryFn, rollbackSeqLen = undefined) {
    return _retryWithFinitenessFallbackImpl.apply(this, arguments);
  }

  async _retryWithPersistentFinitenessFallback(opts, reasonLabel, tokenBudget, retryFn, rollbackSeqLen = undefined) {
    return _retryWithPersistentFinitenessFallbackImpl.apply(this, arguments);
  }

  async _retryDecodeStepWithFinitenessWindow(generatedIds, opts, reasonLabel) {
    return _retryDecodeStepWithFinitenessWindowImpl.apply(this, arguments);
  }

  // ==========================================================================
  // Generation Public API
  // ==========================================================================

  /*
   * Truncate the KV cache back to `seqLen` tokens and set `currentSeqLen` to
   * match. Intended for "prefix-reuse" workflows where a caller wants to run
   * several decodes that share a common prompt prefix: prefill once with the
   * shared prefix, decode the first tail, then `resetToSeqLen(prefixLen)` to
   * drop the tail's KV entries and reuse the prefix KV for the next tail.
   *
   * Only valid when no decode is in progress.
   */
  resetToSeqLen(seqLen) {
    resetSequenceState(this._state, seqLen);
  }

  async _createDiffusionGemmaSelfConditioningEmbeddings(canvasIds, selfConditioningLogits, opts) {
    return _createDiffusionGemmaSelfConditioningEmbeddingsImpl.apply(this, arguments);
  }

  async _createDiffusionGemmaSelfConditioningSoftEmbeddingState(logitsState, canvasLength, hiddenSize, vocabSize) {
    return _createDiffusionGemmaSelfConditioningSoftEmbeddingStateImpl.apply(this, arguments);
  }

  async computeDiffusionGemmaCanvasLogits(args, options = {}) {
    return computeDiffusionGemmaCanvasLogitsImpl.apply(this, arguments);
  }

  async computeDiffusionGemmaCanvasStep(args, options = {}) {
    return computeDiffusionGemmaCanvasStepImpl.apply(this, arguments);
  }

  async *generate(prompt, options = {}) {
    if (!this._state.isLoaded) throw new Error('Model not loaded');
    if (this._state.isGenerating) throw new Error('Generation already in progress');
    const decoder = createGenerationOutputDecoder(this._state.tokenizer,
      this._state.modelConfig?.reasoningOutput,
      [...this._state.modelConfig.stopTokenIds, this._state.tokenizer.getSpecialTokens?.()?.eos]
        .filter(Number.isSafeInteger));
    try {
      yield* decodeGenerationStream(this._generateTokensInternal(prompt, { ...options, onToken: undefined }, 'token'),
        decoder, { ...options, getStopReason: () => this._state.stats.stopReason });
    } finally {
      const usage = decoder.getUsage?.();
      if (usage?.rawTokens > 0) this._state.stats.outputUsage = usage;
    }
  }

  async *generateTokens(prompt, options = {}) {
    yield* this._generateTokensInternal(prompt, options, 'token');
  }

  async generateTokenIds(prompt, options = {}) {
    return generateTokenIdsImpl.apply(this, arguments);
  }

  async prefillKVOnly(prompt, options = {}) {
    return prefillKVOnlyImpl.apply(this, arguments);
  }

  async prefillForLoRATraining(inputIds, options = {}) {
    return prefillForLoRATrainingImpl.apply(this, arguments);
  }

  async prefillWithEmbedding(prompt, options = {}) {
    return prefillWithEmbeddingImpl.apply(this, arguments);
  }

  async prefillWithLogits(prompt, options = {}) {
    return prefillWithLogitsImpl.apply(this, arguments);
  }

  prefillWithToken(prompt, options, tokenContract) {
    return prefillWithToken.call(this, prompt, options, tokenContract);
  }

  decodeStepWithToken(currentIds, options, tokenContract) {
    return decodeStepWithToken.call(this, currentIds, options, tokenContract);
  }

  async prefillWithTokenLogits(prompt, tokenIds, options = {}) {
    return prefillWithTokenLogitsImpl.apply(this, arguments);
  }

  async prefillWithTokenLogitsFromKV(prefix, prompt, tokenIds, options = {}) {
    return prefillWithTokenLogitsFromKVImpl.apply(this, arguments);
  }

  async *generateWithPrefixKV(prefix, prompt, options = {}) {
    if (!this._state.isLoaded) throw new Error('Model not loaded');
    if (this._state.isGenerating) throw new Error('Generation already in progress');
    const decoder = createGenerationOutputDecoder(this._state.tokenizer,
      this._state.modelConfig?.reasoningOutput,
      [...this._state.modelConfig.stopTokenIds, this._state.tokenizer.getSpecialTokens?.()?.eos]
        .filter(Number.isSafeInteger));
    try {
      yield* decodeGenerationStream(generateWithPrefixKVImpl.call(this, prefix, prompt,
        { ...options, onToken: undefined }, 'token'), decoder,
        { ...options, getStopReason: () => this._state.stats.stopReason });
    } finally {
      const usage = decoder.getUsage?.();
      if (usage?.rawTokens > 0) this._state.stats.outputUsage = usage;
    }
  }

  // ==========================================================================
  // Internal Methods (Prefill, Decode, Helpers)
  // ==========================================================================

  async *_runDecodeLoop(generatedIds, opts, options, runtime) {
    return yield* _runDecodeLoopImpl.apply(this, arguments);
  }

  async _prefillToHidden(inputIds, opts) {
    return _prefillToHiddenImpl.apply(this, arguments);
  }

  async _prefill(inputIds, opts) {
    return _prefillImpl.apply(this, arguments);
  }

  async _decodeStep(currentIds, opts) {
    return _decodeStepImpl.apply(this, arguments);
  }

  async decodeStepLogits(currentIds, options = {}) {
    return decodeStepLogitsImpl.apply(this, arguments);
  }

  async advanceWithToken(tokenId, options = {}) {
    return advanceWithTokenImpl.apply(this, arguments);
  }

  async advanceWithTokenAndEmbedding(tokenId, options = {}) {
    return advanceWithTokenAndEmbeddingImpl.apply(this, arguments);
  }

  async _generateNTokensGPU(startToken, N, currentIds, opts) {
    return _generateNTokensGPUImpl.apply(this, arguments);
  }
}
