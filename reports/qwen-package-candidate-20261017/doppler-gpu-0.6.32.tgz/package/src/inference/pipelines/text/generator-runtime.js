import { readBuffer } from '../../../memory/buffer-pool.js';
import { resolveSamplingConfig } from './sampling-config.js';
import { resolveTextGenerationRequest, resolveChatTemplateSetting } from './generation-request.js';
import { isGpuBufferInstance, isWeightBuffer, isCpuWeightBuffer, getBufferDtype } from '../../../gpu/weight-buffer.js';
import { decodeReadback } from './debug-utils/index.js';
import { resolveExecutionSessionPlan } from './execution-plan.js';
import { selectRuleValue } from '../../../rules/rule-registry.js';
import { assertSpeculativeCapability } from './generator/speculative-runtime.js';

const UNKNOWN_TOKENIZER_VOCAB_SIZE = 'unknown';
const INVALID_DTYPE_SENTINEL = '__invalid_dtype__';

export function settleGenerationStats(stats, startTime, generatedTokenCount, aborted) {
  // Iterator return and callback failures can bypass ordinary decode accounting.
  stats.tokensGenerated = generatedTokenCount;
  stats.decodeTokens = Math.max(0, generatedTokenCount - 1);
  stats.totalTimeMs = performance.now() - startTime;
  if (aborted) {
    stats.stopReason = 'aborted';
    stats.stopTokenId = null;
    stats.decodeTimeMs = stats.decodeTokens > 0 ? Math.max(0, stats.totalTimeMs - stats.ttftMs) : 0;
  }
}

function resolveConfiguredValue(value, defaultValue, context, validate) {
  if (value === undefined) {
    return defaultValue;
  }
  if (value === null) {
    throw new Error(`[Pipeline] ${context}: null is unsupported; omit the key or pass an explicit value.`);
  }
  if (validate && !validate(value)) {
    throw new Error(`[Pipeline] ${context}: invalid value "${value}".`);
  }
  return value;
}

function resolveExplicitInputIds(inputIds, context) {
  if (inputIds === undefined) {
    return null;
  }
  if (inputIds === null) {
    throw new Error(`[Pipeline] ${context}: null is unsupported; omit the key or pass explicit token IDs.`);
  }
  if (!Array.isArray(inputIds) && !ArrayBuffer.isView(inputIds)) {
    throw new Error(
      `[Pipeline] ${context}: expected an array or typed array of token IDs, got ${typeof inputIds}.`
    );
  }
  return Array.from(inputIds, (value, index) => {
    if (!Number.isFinite(value) || Math.floor(value) !== value || value < 0) {
      throw new Error(
        `[Pipeline] ${context}[${index}]: expected a non-negative integer token ID, got ${value}.`
      );
    }
    return value;
  });
}

function readTokenizerVocabSize(tok) {
  const tokenizerVocabSize = tok?.getVocabSize?.();
  return typeof tokenizerVocabSize === 'number' && Number.isFinite(tokenizerVocabSize)
    ? tokenizerVocabSize
    : null;
}

function readOptionalTokenizerText(tok, tokenId) {
  if (!tok || typeof tok.decode !== 'function') {
    return null;
  }
  try {
    return tok.decode([tokenId], false, false);
  } catch {
    return null;
  }
}

export function assertTokenIdsInRange(state, tokenIds, context = 'encode') {
  const vocabSize = state?.modelConfig?.vocabSize;
  if (!Array.isArray(tokenIds)) {
    throw new Error(`[Tokenizer] ${context}: expected tokenIds array, got ${typeof tokenIds}`);
  }
  if (!Number.isFinite(vocabSize) || vocabSize <= 0) {
    throw new Error(`[Tokenizer] ${context}: invalid model vocabSize=${vocabSize}`);
  }

  let firstBadIdx = -1;
  let firstBadId = -1;
  let maxId = -1;
  let badCount = 0;
  for (let i = 0; i < tokenIds.length; i++) {
    const id = tokenIds[i];
    if (!Number.isFinite(id) || id < 0 || id >= vocabSize) {
      badCount++;
      if (firstBadIdx < 0) {
        firstBadIdx = i;
        firstBadId = id;
      }
    }
    if (Number.isFinite(id) && id > maxId) maxId = id;
  }
  if (badCount === 0) return;

  const tok = state?.tokenizer;
  const tokenizerVocabSize = readTokenizerVocabSize(tok);
  const badText = readOptionalTokenizerText(tok, firstBadId);
  const safeTokenizerVocabSize = tokenizerVocabSize === null
    ? UNKNOWN_TOKENIZER_VOCAB_SIZE
    : tokenizerVocabSize;

  throw new Error(
    `[Tokenizer] ${context}: token id out of range for model vocab. ` +
    `modelVocabSize=${vocabSize}, tokenizerVocabSize=${safeTokenizerVocabSize}, ` +
    `badCount=${badCount}/${tokenIds.length}, firstBadIdx=${firstBadIdx}, firstBadId=${firstBadId}` +
    (badText === null ? '' : ` ("${badText}")`) +
    `, maxId=${maxId}. ` +
    'This will poison GPU embedding gather (NaNs). Fix by re-converting the model or aligning tokenizer.json IDs to embedding/LM-head shapes.'
  );
}

export function assertTokenIdInRange(state, tokenId, context = 'token') {
  const vocabSize = state?.modelConfig?.vocabSize;
  if (!Number.isFinite(vocabSize) || vocabSize <= 0) {
    throw new Error(`[Tokenizer] ${context}: invalid model vocabSize=${vocabSize}`);
  }
  if (!Number.isFinite(tokenId) || tokenId < 0 || tokenId >= vocabSize) {
    const tok = state?.tokenizer;
    const tokenizerVocabSize = readTokenizerVocabSize(tok);
    const safeTokenizerVocabSize = tokenizerVocabSize === null
      ? UNKNOWN_TOKENIZER_VOCAB_SIZE
      : tokenizerVocabSize;
    throw new Error(
      `[Tokenizer] ${context}: tokenId=${tokenId} out of range (modelVocabSize=${vocabSize}, tokenizerVocabSize=${safeTokenizerVocabSize}).`
    );
  }
}

function resolveChatTemplateEnabled(state, options) {
  return resolveChatTemplateSetting(options, state.runtimeConfig, state.modelConfig);
}

export function resolveStepOptions(state, options = {}) {
  const runtimeDefaults = state.runtimeConfig.inference;
  const executionPlan = resolveExecutionSessionPlan(state, options);

  return {
    logitMaskFn: resolveLogitMask(options),
    promptTokenCount: 0,
    seed: resolveConfiguredValue(
      options.seed,
      undefined,
      'options.seed',
      (value) => Number.isFinite(value) && value >= 0
    ),
    ...resolveSamplingConfig(options, state.runtimeConfig),
    debug: resolveConfiguredValue(options.debug, state.debug, 'options.debug', (value) => typeof value === 'boolean'),
    debugLayers: options.debugLayers,
    profile: resolveConfiguredValue(options.profile, runtimeDefaults.generation.profile, 'options.profile'),
    disableCommandBatching: executionPlan.disableCommandBatching,
    disableMultiTokenDecode: executionPlan.disableMultiTokenDecode,
    batchSize: executionPlan.batchSize,
    stopCheckMode: executionPlan.stopCheckMode,
    executionPlan,
    inputIds: resolveExplicitInputIds(options.inputIds, 'options.inputIds'),
    embeddingOverrides: options.embeddingOverrides ?? null,
    embeddingInputSpan: options.__internalEmbeddingInputSpan ?? null,
    multimodalBidirectionalSpan: options.__internalMultimodalBidirectionalSpan ?? null,
  };
}

export function resolveGenerateOptions(state, options = {}) {
  options = resolveTextGenerationRequest(options, state.runtimeConfig, state.modelConfig);
  const runtimeDefaults = state.runtimeConfig.inference;
  const generationDefaults = runtimeDefaults.generation;
  const executionPlan = resolveExecutionSessionPlan(state, options);
  const logitMaskFn = resolveLogitMask(options);
  const speculation = options.speculation;
  if (speculation?.mode === 'lookup') assertSpeculativeCapability(state, options);
  if (speculation?.mode === 'lookup' && options.temperature !== 0) {
    throw new Error('[Pipeline] lookup speculation currently requires greedy target sampling.');
  }
  if (logitMaskFn && (speculation || (options.useSpeculative ?? generationDefaults.useSpeculative))) {
    throw new Error('[Pipeline] logitMaskFn is incompatible with speculative decoding.');
  }

  return {
    logitMaskFn,
    seed: resolveConfiguredValue(
      options.seed,
      undefined,
      'options.seed',
      (value) => Number.isFinite(value) && value >= 0
    ),
    maxTokens: executionPlan.maxTokens,
    ...options,
    stopSequences: options.stopSequences,
    useSpeculative: resolveConfiguredValue(
      options.useSpeculative,
      generationDefaults.useSpeculative,
      'options.useSpeculative',
      (value) => typeof value === 'boolean'
    ),
    useChatTemplate: resolveChatTemplateEnabled(state, options),
    debug: resolveConfiguredValue(options.debug, state.debug, 'options.debug', (value) => typeof value === 'boolean'),
    debugLayers: options.debugLayers,
    profile: resolveConfiguredValue(options.profile, generationDefaults.profile, 'options.profile'),
    benchmark: resolveConfiguredValue(options.benchmark, generationDefaults.benchmark, 'options.benchmark'),
    disableCommandBatching: executionPlan.disableCommandBatching,
    disableMultiTokenDecode: executionPlan.disableMultiTokenDecode,
    batchSize: executionPlan.batchSize,
    stopCheckMode: executionPlan.stopCheckMode,
    executionPlan,
    images: options.images ?? null,
    speculation,
    inputIds: resolveExplicitInputIds(options.inputIds, 'options.inputIds'),
    embeddingOverrides: options.embeddingOverrides ?? null,
    embeddingInputSpan: options.__internalEmbeddingInputSpan ?? null,
    multimodalBidirectionalSpan: options.__internalMultimodalBidirectionalSpan ?? null,
  };
}

function resolveLogitMask(options) {
  if (options.logitMaskFn == null) return null;
  if (typeof options.logitMaskFn !== 'function') throw new Error('[Pipeline] logitMaskFn must be a synchronous function or null.');
  return options.logitMaskFn;
}

export function resolvePrefillOptions(state, options = {}) {
  const generationDefaults = state.runtimeConfig.inference.generation;
  const executionPlan = resolveExecutionSessionPlan(state, options);
  return {
    useChatTemplate: resolveChatTemplateEnabled(state, options),
    debug: resolveConfiguredValue(options.debug, state.debug, 'options.debug', (value) => typeof value === 'boolean'),
    debugLayers: options.debugLayers,
    profile: resolveConfiguredValue(options.profile, generationDefaults.profile, 'options.profile'),
    benchmark: resolveConfiguredValue(options.benchmark, generationDefaults.benchmark, 'options.benchmark'),
    disableCommandBatching: executionPlan.disableCommandBatching,
    disableMultiTokenDecode: executionPlan.disableMultiTokenDecode,
    executionPlan,
    images: options.images ?? null,
    inputIds: resolveExplicitInputIds(options.inputIds, 'options.inputIds'),
    embeddingOverrides: options.embeddingOverrides ?? null,
    embeddingInputSpan: options.__internalEmbeddingInputSpan ?? null,
    multimodalBidirectionalSpan: options.__internalMultimodalBidirectionalSpan ?? null,
  };
}

export function resolvePrefillEmbeddingOptions(state, options = {}) {
  const postprocessor = state.modelConfig?.embeddingPostprocessor ?? null;
  const requestedEmbeddingMode = resolveConfiguredValue(
    options.embeddingMode,
    undefined,
    'options.embeddingMode',
    (value) => value === 'last' || value === 'mean'
  );
  if (postprocessor) {
    if (requestedEmbeddingMode !== undefined && requestedEmbeddingMode !== postprocessor.poolingMode) {
      throw new Error(
        `[Pipeline] options.embeddingMode="${requestedEmbeddingMode}" conflicts with ` +
        `manifest output.embeddingPostprocessor.poolingMode="${postprocessor.poolingMode}".`
      );
    }
    return {
      ...resolvePrefillOptions(state, options),
      embeddingMode: postprocessor.poolingMode,
    };
  }
  const modelType = typeof state.manifest?.modelType === 'string'
    ? state.manifest.modelType.toLowerCase()
    : '';
  const generationDefaults = state.runtimeConfig.inference.generation;
  // Models that expose embedding extraction default to 'mean' pooling. This covers
  // dedicated embedding models (modelType="embedding") and text-generation models
  // that opt in via inference.supportsEmbedding=true. Conversion configs can still
  // override via generation.embeddingMode in their runtime profile.
  const supportsEmbeddingExtraction = modelType === 'embedding'
    || state.manifest?.inference?.supportsEmbedding === true;
  const defaultEmbeddingMode = supportsEmbeddingExtraction
    ? 'mean'
    : generationDefaults.embeddingMode;
  return {
    ...resolvePrefillOptions(state, options),
    embeddingMode: requestedEmbeddingMode ?? defaultEmbeddingMode,
  };
}

export function resolveAdvanceEmbeddingMode(state, options = {}) {
  if (state.modelConfig?.embeddingPostprocessor) {
    throw new Error(
      '[Pipeline] advanceWithTokenAndEmbedding is unsupported when manifest output.embeddingPostprocessor is enabled.'
    );
  }
  const modelType = typeof state.manifest?.modelType === 'string'
    ? state.manifest.modelType.toLowerCase()
    : '';
  // See resolvePrefillEmbeddingOptions for embedding-model pooling rationale.
  const configuredMode = state.runtimeConfig.inference.generation.embeddingMode;
  return resolveConfiguredValue(
    options.embeddingMode,
    modelType === 'embedding' ? 'mean' : configuredMode,
    'options.embeddingMode',
    (value) => value === 'last' || value === 'mean'
  );
}

function resolveFloatDtypeFromAlias(dtype) {
  const normalized = typeof dtype === 'string' ? dtype.trim().toLowerCase() : '';
  if (!normalized) {
    throw new Error('[Pipeline] float weight dtype is required.');
  }
  const resolved = selectRuleValue('inference', 'dtype', 'dtypeFromAlias', {
    dtype: normalized,
    fallback: INVALID_DTYPE_SENTINEL,
  });
  if (resolved === INVALID_DTYPE_SENTINEL) {
    throw new Error(`[Pipeline] Unsupported float weight dtype "${dtype}".`);
  }
  return resolved;
}

export function resolveFloatDtypeFromByteSize(totalBytes, expectedLength) {
  if (!Number.isFinite(totalBytes) || totalBytes <= 0 || !Number.isFinite(expectedLength) || expectedLength <= 0) {
    throw new Error(
      `[Pipeline] Cannot infer float dtype from invalid size metadata (totalBytes=${totalBytes}, expectedLength=${expectedLength}).`
    );
  }
  const bytesPerElement = totalBytes / expectedLength;
  if (bytesPerElement !== 2 && bytesPerElement !== 4) {
    throw new Error(
      `[Pipeline] Cannot infer float dtype from bytesPerElement=${bytesPerElement}; expected 2 or 4.`
    );
  }
  return selectRuleValue('inference', 'dtype', 'f16OrF32FromBytes', { bytesPerElement });
}

export function resolveFloatDtypeFromBufferMetadata(buffer, expectedLength) {
  const taggedDtype = getBufferDtype(buffer);
  return taggedDtype
    ? resolveFloatDtypeFromAlias(taggedDtype)
    : resolveFloatDtypeFromByteSize(buffer?.size, expectedLength);
}

function decodeFloatWeights(data, dtype, expectedLength, label) {
  const decodeDtype = resolveFloatDtypeFromAlias(dtype);
  const decoded = decodeReadback(data, decodeDtype);
  if (decoded.length !== expectedLength) {
    throw new Error(
      `[Pipeline] ${label} length mismatch: expected=${expectedLength}, got=${decoded.length}`
    );
  }
  return decoded;
}

export async function getFinalNormWeights(state) {
  const hiddenSize = state.modelConfig.hiddenSize;
  const finalNorm = state.weights.get('final_norm');
  if (!finalNorm) {
    throw new Error('[Pipeline] final_norm weight is missing; cannot extract embedding.');
  }

  let weights;

  if (finalNorm instanceof Float32Array) {
    weights = finalNorm;
  } else if (isCpuWeightBuffer(finalNorm)) {
    const dtype = resolveFloatDtypeFromAlias(finalNorm.dtype);
    const data = finalNorm.data;
    if (!(data instanceof Float32Array) && !ArrayBuffer.isView(data)) {
      throw new Error('[Pipeline] final_norm CPU weight buffer has unsupported data type.');
    }
    const bytes = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
    weights = decodeFloatWeights(bytes, dtype, hiddenSize, 'final_norm');
  } else if (isWeightBuffer(finalNorm)) {
    const dtypeValue = typeof finalNorm.dtype === 'string' ? finalNorm.dtype.trim().toLowerCase() : '';
    const dtype = selectRuleValue('inference', 'dtype', 'f16OrF32FromDtypeAlias', {
      dtype: dtypeValue === '' ? undefined : dtypeValue,
      fallback: INVALID_DTYPE_SENTINEL,
    });
    if (dtype === INVALID_DTYPE_SENTINEL) {
      throw new Error(`[Pipeline] Unsupported final_norm dtype "${finalNorm.dtype}".`);
    }
    const bytesPerElement = selectRuleValue('shared', 'dtype', 'bytesFromDtype', { dtype });
    const readSize = hiddenSize * bytesPerElement;
    const data = await readBuffer(finalNorm.buffer, readSize);
    if (data.byteLength === 0) {
      throw new Error('[Pipeline] final_norm readback returned empty buffer.');
    }
    weights = decodeFloatWeights(data, dtype, hiddenSize, 'final_norm');
  } else if (isGpuBufferInstance(finalNorm)) {
    const dtype = resolveFloatDtypeFromBufferMetadata(finalNorm, hiddenSize);
    const bytesPerElement = selectRuleValue('shared', 'dtype', 'bytesFromDtype', { dtype });
    const readSize = hiddenSize * bytesPerElement;
    const data = await readBuffer(finalNorm, readSize);
    if (data.byteLength === 0) {
      throw new Error('[Pipeline] final_norm readback returned empty buffer.');
    }
    weights = decodeFloatWeights(data, dtype, hiddenSize, 'final_norm');
  } else if (ArrayBuffer.isView(finalNorm)) {
    const view = finalNorm;
    const dtype = resolveFloatDtypeFromByteSize(view.byteLength, hiddenSize);
    const bytes = view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength);
    weights = decodeFloatWeights(bytes, dtype, hiddenSize, 'final_norm');
  } else {
    throw new Error('[Pipeline] final_norm weight has unsupported type.');
  }
  if (!(weights instanceof Float32Array) || weights.length !== hiddenSize) {
    const reportedLength = weights === undefined || weights === null ? UNKNOWN_TOKENIZER_VOCAB_SIZE : weights.length;
    throw new Error(
      `[Pipeline] final_norm length mismatch: expected=${hiddenSize}, got=${reportedLength}`
    );
  }
  return weights;
}

export function extractTokenEmbeddingsFromHidden(
  hiddenStates,
  numTokens,
  hiddenSize,
  finalNormWeights,
  config,
  finalNormBias = null
) {
  throw new Error(
    'CPU embedding extraction is a quarantined reference; use extractEmbeddingFromHiddenGPU.'
  );
}

export function extractEmbeddingFromHidden(
  hiddenStates,
  numTokens,
  hiddenSize,
  embeddingMode,
  finalNormWeights,
  config,
  embeddingPostprocessor = null,
  normalizedTokenEmbeddings = null,
  finalNormBias = null
) {
  throw new Error(
    'CPU embedding extraction is a quarantined reference; use extractEmbeddingFromHiddenGPU.'
  );
}
