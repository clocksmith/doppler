import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { PreparedDecodeWorkspace } from '../../src/gpu/prepared-decode-workspace.js';

// Real wrapper, injected allocation failures. No claim of GPU numerical parity.
const target = new URL('../../src/gpu/kernels/linear-attention-core.js', import.meta.url).href;
globalThis.GPUBuffer = class { size = 8; };
globalThis.GPUShaderStage = { COMPUTE: 4 };
const active = new Set();
let failure;
let fused;
globalThis.linearAllocationProbe = {
  device: { createComputePipeline: () => ({}) },
  acquire(_size, _usage, label) {
    if (failure === 'convolution' && label.includes('linear_conv_out')) throw Error('allocation rejected');
    const buffer = new GPUBuffer(); active.add(buffer); return buffer;
  },
  release(buffer) { assert(active.delete(buffer), 'release exactly once'); },
  uniform() { throw Error('allocation rejected'); },
  config: () => ({ inference: { session: { useLinearAttentionFusedDecodeCore: fused, useLinearAttentionRegisterPrefill: false, useLinearAttentionRegisterDecode: false } } }),
};
const modules = {
  '../device.js': 'export const getDevice = () => linearAllocationProbe.device;',
  './shader-source-scope.js': 'export const getShaderScopeCacheKey = () => 0;',
  '../../memory/buffer-pool.js': `export const acquireBuffer = (...args) => linearAllocationProbe.acquire(...args);
    export const releaseBuffer = buffer => linearAllocationProbe.release(buffer);`,
  '../../config/runtime.js': 'export const getRuntimeConfig = () => linearAllocationProbe.config();',
  './uniform-utils.js': 'export const createUniformBufferFromData = () => linearAllocationProbe.uniform();',
  './shader-cache.js': 'export const getShaderModule = async () => ({});',
  './pipeline-cache.js': 'export const getOrCreateBindGroupLayout = () => ({}); export const getOrCreatePipelineLayout = () => ({});',
};
const hooks = registerHooks({ resolve(specifier, context, next) {
  if (context.parentURL === target && modules[specifier]) {
    return { url: `data:text/javascript,${encodeURIComponent(modules[specifier])}`, shortCircuit: true };
  }
  return next(specifier, context);
} });
try {
  const { runLinearAttentionCoreGPU } = await import(target);
  const tensor = { buffer: new GPUBuffer(), dtype: 'f32' };
  const state = { headVDim: 1, headKDim: 1, normMode: 'shared', convDim: 3,
    valueDim: 1, convKernelSize: 1, numVHeads: 1, numKHeads: 1,
    qSize: 1, kSize: 1, vSize: 1, qRep: 1 };
  for (const key of ['convWeightGPU', 'dtBiasGPU', 'aLogGPU', 'normWeightGPU', 'convStateGPU', 'recurrentStateGPU']) {
    state[key] = new GPUBuffer();
  }
  for (const invalid of [NaN, Infinity, 0, -1, 0.1, 0.5]) {
    const invalidState = { ...state, numVHeads: invalid, recurrentStatePrecision: 'two-f32', recurrentStateComponents: 2 };
    await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, invalidState,
      { numTokens: 1, normGateActivation: 'silu' }), /storage layout/);
    assert.equal(active.size, 0, 'invalid geometry cannot allocate output');
  }
  // The norm-gate activation comes from the resolved model config; absence or an
  // unknown spelling fails before any allocation.
  for (const normGateActivation of [undefined, null, 'swish']) {
    const gateState = { ...state, recurrentStatePrecision: 'f32', recurrentStateComponents: 1 };
    await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, gateState,
      { numTokens: 1, normGateActivation, outputDtype: 'f32' }), /norm-gate activation/);
    assert.equal(active.size, 0, 'missing norm-gate activation cannot allocate output');
  }
  for (const normGateActivation of ['silu', 'sigmoid'])
  for (const precision of ['f32', 'two-f32']) {
  state.recurrentStatePrecision = precision;
  state.recurrentStateComponents = precision === 'f32' ? 1 : 2;
  for (fused of [false, true]) {
    for (const recorded of [false, true]) {
      for (failure of fused ? ['uniform'] : ['convolution', 'uniform']) {
        const recorder = recorded ? { getEncoder() {}, trackTemporaryBuffer() {} } : null;
        await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
          { numTokens: fused ? 1 : 2, abPacked: true, bProjOffsetElements: 1, outputDtype: 'f32', recorder, normGateActivation }),
        /allocation rejected/);
        assert.equal(active.size, 0, `${failure}, fused=${fused}, recorded=${recorded}: no retained output`);
      }
    }
  }
  }
  state.recurrentStatePrecision = 'f32';
  state.recurrentStateComponents = 1;
  await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
    { numTokens: 2, normGateActivation: 'silu', outputDtype: 'f32',
      runtimeSession: { useLinearAttentionRegisterPrefill: true } }), /registered head width/);
  await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
    { numTokens: 2, normGateActivation: 'silu', outputDtype: 'f32', runtimeSession: {} }), /requires boolean/);
  await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
    { numTokens: 1, normGateActivation: 'silu', runtimeSession: {
      useLinearAttentionRegisterDecode: true, useLinearAttentionFusedDecodeCore: true,
    } }), /Register decode requires/);
  await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
    { numTokens: 1, normGateActivation: 'silu', runtimeSession: {} }), /requires boolean/);
  // A recorded failure must not return session-owned storage to the pool.
  globalThis.GPUBufferUsage = { STORAGE: 1, COPY_SRC: 2, COPY_DST: 4 };
  let destroyed = 0;
  const owner = new PreparedDecodeWorkspace({
    createBuffer({ size }) { const buffer = new GPUBuffer(); buffer.size = size; buffer.destroy = () => destroyed++; return buffer; },
  });
  fused = true;
  state.recurrentStatePrecision = 'f32';
  state.recurrentStateComponents = 1;
  const recorder = { getEncoder() {}, trackTemporaryBuffer() {}, decodeWorkspace: owner };
  await assert.rejects(() => runLinearAttentionCoreGPU(tensor, tensor, tensor, tensor, state,
    { numTokens: 1, layerIdx: 0, abPacked: true, bProjOffsetElements: 1, outputDtype: 'f32', recorder, normGateActivation: 'silu' }),
  /allocation rejected/);
  assert.equal(active.size, 0);
  assert.equal(owner.getStats().buffers, 1);
  assert.equal(destroyed, 0, 'recorder failure cannot destroy borrowed session storage');
  owner.release();
  assert.equal(destroyed, 1, 'session release destroys it exactly once');
} finally { hooks.deregister(); delete globalThis.linearAllocationProbe; }
console.log('linear-attention-allocation-cleanup: passed');
