import pathlib,json
r=pathlib.Path('/home/x/.local/state/doppler/jupiter-tuning-20261029');cases=[]
for p in ['code','long-context']:
 for mode,flag in [('flash','useFlashPrefillAttention'),('ort','useOrtFlashPrefillAttention')]:
  d=json.loads((r/('register-'+p+'.json')).read_text());d['request']['runtimeConfig']['inference']['session'][flag]=True
  name='register-'+p+'-'+mode;(r/(name+'.json')).write_text(json.dumps(d,indent=2));cases.append(name)
plan={'runtime':'runtime-coeff-prefill','output':'screen27','cases':cases,'scope':'Existing optional flash-prefill attention implementations on the composed register-prefill candidate; no other delta; 64 tokens','sourceDelta':'source15','noDroppedAttempts':True};(r/'plan27.json').write_text(json.dumps(plan,indent=2))
