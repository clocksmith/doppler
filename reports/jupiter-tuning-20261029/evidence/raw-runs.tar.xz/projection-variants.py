import pathlib,json,hashlib
r=pathlib.Path('/home/x/.local/state/doppler/jupiter-tuning-20261029');profile=json.loads((r/'gate-refined-ffn/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text());cases=[]
for lanes in [4,16]:
 d=json.loads((r/'gate-code-candidate.json').read_text());patch=json.loads(json.dumps(profile['runtime']['inference']['executionPatch']));shader='fused_matmul_q4_subgroup.wgsl'
 patch['addKernels'].append({'key':'projection_test','kernel':{'kernel':shader,'entry':'main','digest':'sha256:'+hashlib.sha256((r/'gate-refined-ffn/src/gpu/kernels'/shader).read_bytes()).hexdigest(),'constants':{'WORKGROUP_SIZE':256,'COLS_PER_WG':256//lanes,'THREADS_PER_COL_GEMV':lanes,'USE_FULL_BLOCK_FAST_PATH':True}}})
 for op in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:patch['set'].append({'section':'decode','op':op,'kernelKey':'projection_test'})
 d['request']['runtimeConfig']['inference']['executionPatch']=patch;tag='gate-code-projection-'+str(lanes);(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'gate-refined-ffn','output':'full-logits-projection-variants','cases':cases,'scope':'UNTIMED: isolate projection partition geometry with refined FFN held fixed. Compare all batched-route vocabulary rows at the unchanged .001 tolerance.','noDroppedAttempts':True};(r/'plan-projection-variants.json').write_text(json.dumps(plan,indent=2))
