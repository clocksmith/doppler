import pathlib,json
r=pathlib.Path('/home/x/.local/state/doppler/jupiter-tuning-20261029');cases=[]
profile=json.loads((r/'gate-candidate/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text())
for kind in ['head','decode','prefill']:
 d=json.loads((r/'gate-code-candidate.json').read_text());inf=d['request']['runtimeConfig']['inference'];patch=json.loads(json.dumps(profile['runtime']['inference']['executionPatch']))
 old={'key':'control_decode','kernel':{'kernel':'fused_matmul_q4.wgsl','entry':'main_gemv','digest':'sha256:02029c2254c8ddb4c2051c4322e6b11ddbcf555e27d233e7fe73277edfa0f3f7','constants':{'COLS_PER_WG':64,'THREADS_PER_COL_GEMV':4}}};patch['addKernels'].append(old)
 if kind=='head':patch['set'].append({'section':'postLayer','op':'lm_head','kernelKey':'control_decode'})
 if kind=='decode':
  for op in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:patch['set'].append({'section':'decode','op':op,'kernelKey':'control_decode'})
  inf['session']['fusedFfnQ4K']=None
 if kind=='prefill':
  inf['session']['useLinearAttentionRegisterPrefill']=False
  patch['addKernels'].append({'key':'control_prefill_attention','kernel':{'kernel':'attention_head256_f16kv.wgsl','entry':'main','digest':'sha256:4e1eafa0a5e407c99714d04f0e75f3834e1156bcb25579892f248d95aae197da','precision':{'kvDtype':'f16'}}})
  patch['set'].append({'section':'prefill','op':'attention','kernelKey':'control_prefill_attention'})
 inf['executionPatch']=patch;tag='ablate-code-'+kind;(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'gate-candidate','output':'full-logits-ablation','cases':cases,'scope':'UNTIMED diagnosis: preserve failing code prompt and first inspect raw actual-route logit vectors; isolate head, decode projections/FFN, or prefill as the source of p63 drift above .001. No gate changes.','noDroppedAttempts':True};(r/'plan-ablation.json').write_text(json.dumps(plan,indent=2))
