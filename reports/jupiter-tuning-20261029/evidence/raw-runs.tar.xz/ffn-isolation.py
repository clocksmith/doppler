import pathlib,json
r=pathlib.Path('/home/x/.local/state/doppler/jupiter-tuning-20261029')
d=json.loads((r/'gate-code-candidate.json').read_text());d['request']['runtimeConfig']['inference']['session']['fusedFfnQ4K']={'decode':{'variant':None,'pipelineConstants':{'WORKGROUP_SIZE':256,'COLS_PER_WG':64,'THREADS_PER_COL':4,'USE_FULL_BLOCK_FAST_PATH':False}}}
(r/'gate-code-ffn-old.json').write_text(json.dumps(d,indent=2))
plan={'runtime':'gate-candidate','output':'full-logits-ffn-isolation','cases':['gate-code-ffn-old'],'scope':'UNTIMED: isolate fused FFN while retaining new decode projections. Explicit fused geometry now reaches its actual decision owner; no tolerance changes.','noDroppedAttempts':True};(r/'plan-ffn-isolation.json').write_text(json.dumps(plan,indent=2))
