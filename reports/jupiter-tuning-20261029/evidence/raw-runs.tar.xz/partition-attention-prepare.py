import pathlib,json,hashlib
r=pathlib.Path('/home/x/.local/state/doppler/jupiter-tuning-20261029');cases=[]
for p in ['code','explanation','arithmetic','long-context']:
 d=json.loads((r/'product-screen'/(p+'-pair0-doppler-config.json')).read_text())
 inf=d['request']['runtimeConfig']['inference'];inf['session'].update({'usePreparedDecodeWorkspace':True,'useLinearAttentionRegisterPrefill':True,'prefillChunkSubmitMode':'async'})
 patch=json.loads((r/'runtime-partition-attention/src/config/runtime/profiles/qwen-3-5-0-8b-vulkan-subgroup8.json').read_text())['runtime']['inference']['executionPatch']
 shader='attention_prefill_partitioned_head256_f16kv.wgsl'
 patch['addKernels'].append({'key':'partition_prefill_attention','kernel':{'kernel':shader,'entry':'main','digest':'sha256:'+hashlib.sha256((r/'runtime-partition-attention/src/gpu/kernels'/shader).read_bytes()).hexdigest(),'precision':{'kvDtype':'f16'}}})
 patch['set'].append({'section':'prefill','op':'attention','kernelKey':'partition_prefill_attention'});inf['executionPatch']=patch
 tag='partition-'+p;(r/(tag+'.json')).write_text(json.dumps(d,indent=2));cases.append(tag)
plan={'runtime':'runtime-partition-attention','output':'screen32','cases':cases,'scope':'New head-256 prefill attention partitioned across 16 subgroup lanes per query; independently CPU-checked compensated dot products; four 64-token prompts','sourceDelta':'source18','noDroppedAttempts':True};(r/'plan32.json').write_text(json.dumps(plan,indent=2))
