import { getKernelBindGroupLayout, createKernelBindingEntries } from './kernel-bindings.js';


import { getDevice, getKernelCapabilities } from '../device.js';
import { acquireBuffer, readBufferSlice, releaseBuffer } from '../../memory/buffer-pool.js';
import { WORKGROUP_SIZES } from './constants.js';
import {
  createPipeline,
} from './pipeline-cache.js';
import { getKernelConfig } from './kernel-configs.js';
import { createKernelUniformBuffer } from './uniform-utils.js';
import { allowReadback } from '../perf-guards.js';
import { selectRuleValue as selectKernelRuleValue } from './rule-registry.js';
import { selectRuleValue as selectSharedRuleValue } from '../../rules/rule-registry.js';
import { getKernelThresholdSnapshot } from '../../config/schema/index.js';
import { recordDispatch } from './dispatch.js';
import { validateGenerationField } from '../../config/generation-contract.js';
import { isGreedySampling } from '../../rules/greedy-sampling.js';


function getSampleBindGroupLayout(device, variant) {
  return getKernelBindGroupLayout(getKernelConfig('sample', variant), device);
}

function sampleBindingEntries(variant, uniformBuffer, logits, output, indices, scores) {
  return createKernelBindingEntries(getKernelConfig('sample', variant), {
    uniforms: { buffer: uniformBuffer },
    logits: { buffer: logits },
    output: { buffer: output },
    topk_indices: { buffer: indices },
    topk_logits: { buffer: scores },
  });
}


async function createSamplePipeline(device, entryPoint) {
  return createPipeline('sample', entryPoint, getSampleBindGroupLayout(device, entryPoint));
}

function resolveSampleVariants(logitsDtype) {
  const caps = getKernelCapabilities();
  const useF16 = logitsDtype === 'f16';
  if (useF16 && !caps.hasF16) {
    throw new Error('[Sample] F16 logits requested but shader-f16 is unavailable.');
  }
  const suffix = selectKernelRuleValue('sample', 'suffix', { useF16 });
  return {
    argmax: `argmax${suffix}`,
    argmaxReduce: `argmax_reduce${suffix}`,
    phase1: `find_topk_phase1${suffix}`,
    phase2: `find_topk_phase2${suffix}`,
    phase3: `softmax_and_sample${suffix}`,
    singlePass: `single_pass${suffix}`,
  };
}


function resolveLogitsDtype(logitsDtype) {
  return selectSharedRuleValue('shared', 'dtype', 'logitsDtype', { logitsDtype });
}

function assertArgmaxOptions(options, recordMode = false) {
  const suffix = recordMode ? ' (record)' : '';
  if (options.logitsDtype == null) {
    throw new Error(`[Sample] logitsDtype is required for argmax${suffix}.`);
  }
  if (options.outputIndex == null) {
    throw new Error(`[Sample] outputIndex is required for argmax${suffix}.`);
  }
  if (options.logitSoftcap === undefined) {
    throw new Error(`[Sample] logitSoftcap is required for argmax${suffix}.`);
  }
  if (options.padTokenId === undefined) {
    throw new Error(`[Sample] padTokenId is required for argmax${suffix}.`);
  }
}

function assertSampleOptions(options, recordMode = false) {
  const suffix = recordMode ? ' (record)' : '';
  for (const key of ['temperature', 'topK', 'topP']) validateGenerationField(key, options[key]);
  if (options.temperature == null) {
    throw new Error(`[Sample] temperature is required for sampling${suffix}.`);
  }
  if (options.topK == null) {
    throw new Error(`[Sample] topK is required for sampling${suffix}.`);
  }
  if (options.logitsDtype == null) {
    throw new Error(`[Sample] logitsDtype is required for sampling${suffix}.`);
  }
  if (options.outputIndex == null) {
    throw new Error(`[Sample] outputIndex is required for sampling${suffix}.`);
  }
  if (options.logitSoftcap === undefined) {
    throw new Error(`[Sample] logitSoftcap is required for sampling${suffix}.`);
  }
  if (options.padTokenId === undefined) {
    throw new Error(`[Sample] padTokenId is required for sampling${suffix}.`);
  }
  if (options.greedyThreshold == null) {
    throw new Error(`[Sample] greedyThreshold is required for sampling${suffix}.`);
  }
}

async function resolveArgmaxPipelines(device, vocabSize, variants) {
  const argmaxPipeline = await createSamplePipeline(device, variants.argmax);
  const reduceWorkgroups = Math.min(WORKGROUP_SIZES.DEFAULT, Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT));
  const { argmaxReduceVocabThreshold } = getKernelThresholdSnapshot().sample;
  const useSinglePassArgmax = vocabSize <= argmaxReduceVocabThreshold;
  const numWorkgroups = useSinglePassArgmax ? 1 : reduceWorkgroups;
  const reducePipeline = useSinglePassArgmax
    ? null
    : await createSamplePipeline(device, variants.argmaxReduce);
  const singlePassPipeline = useSinglePassArgmax
    ? await createSamplePipeline(device, variants.singlePass)
    : null;

  return {
    argmaxPipeline,
    reducePipeline,
    singlePassPipeline,
    numWorkgroups,
    useSinglePassArgmax,
  };
}

function createArgmaxUniformBuffer(device, recorder, variant, vocabSize, options) {
  return createKernelUniformBuffer(
    'argmax_uniforms',
    getKernelConfig('sample', variant),
    {
      vocab_size: vocabSize,
      top_k: 1,
      temperature: 1.0,
      random_value: 0.0,
      pad_token_id: options.padTokenId === null ? 0xFFFFFFFF : options.padTokenId,
      logit_softcap: options.logitSoftcap === null ? 0 : options.logitSoftcap,
      output_index: options.outputIndex,
      top_p: 0.0, // Argmax does not sample a probability distribution.
    },
    recorder,
    device
  );
}

function createSampleUniformBuffer(device, recorder, variant, vocabSize, topK, temperature, randomValue, padTokenId, logitSoftcap, outputIndex, topP) {
  return createKernelUniformBuffer(
    'sample_uniforms',
    getKernelConfig('sample', variant),
    {
      vocab_size: vocabSize,
      top_k: topK,
      temperature,
      random_value: randomValue,
      pad_token_id: padTokenId === null ? 0xFFFFFFFF : padTokenId,
      logit_softcap: logitSoftcap === null ? 0 : logitSoftcap,
      output_index: outputIndex,
      top_p: topP,
    },
    recorder,
    device
  );
}

function ensureOutputBufferSize(outputBuffer, minBytes, label) {
  if (outputBuffer.size < minBytes) {
    throw new Error(`[Sample] outputBuffer too small for ${label}.`);
  }
}

async function readTokenFromOutput(outputBuffer, outputIndex) {
  const token = new Uint32Array(await readBufferSlice(outputBuffer, outputIndex * 4, 4))[0];
  if (token === 0xFFFFFFFF) throw new Error('[Sampling] No finite candidate logits.');
  return token;
}

function resolveSampleGeometry(vocabSize, requestedTopK) {
  if (!Number.isSafeInteger(vocabSize) || vocabSize < 1) throw new Error('[Sample] Positive vocabSize required.');
  const topK = requestedTopK === 0 ? vocabSize : Math.min(requestedTopK, vocabSize);
  const numWorkgroups = Math.max(1, Math.min(WORKGROUP_SIZES.DEFAULT,
    Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT), Math.floor(vocabSize / topK)));
  return { topK, numWorkgroups, scratchBytes: (numWorkgroups + 1) * topK * Uint32Array.BYTES_PER_ELEMENT };
}

function cleanupRunResources(uniformBuffer, ownedBuffers) {
  if (uniformBuffer) {
    uniformBuffer.destroy();
  }
  for (const buffer of ownedBuffers) {
    if (buffer) {
      releaseBuffer(buffer);
    }
  }
}

async function executeArgmax(recorder, logits, vocabSize, options) {
  if (!recorder && !allowReadback('sample.runArgmax')) {
    throw new Error('[Sample] GPU readback disabled for argmax');
  }

  const device = recorder ? recorder.device : getDevice();
  if (!device) throw new Error('GPU device not initialized');

  assertArgmaxOptions(options, Boolean(recorder));

  const logitsDtype = resolveLogitsDtype(options.logitsDtype);
  const variants = resolveSampleVariants(logitsDtype);
  const {
    argmaxPipeline,
    reducePipeline,
    singlePassPipeline,
    numWorkgroups,
    useSinglePassArgmax,
  } = await resolveArgmaxPipelines(device, vocabSize, variants);

  let tempLogits = null;
  let tempIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let uniformBuffer = null;
  let completed = false;
  try {
    tempLogits = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_logits');
    tempIndices = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_indices');
    const outputIndex = options.outputIndex;
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = options.outputBuffer ?? acquireBuffer(minOutputBytes, undefined, 'argmax_output');
    ownsOutputBuffer = !options.outputBuffer;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'argmax outputIndex');

    uniformBuffer = createArgmaxUniformBuffer(device, recorder, variants.argmax, vocabSize, options);

    const bindGroupLayout = getSampleBindGroupLayout(device, variants.argmax);
    const entries = sampleBindingEntries(variants.argmax, uniformBuffer, logits, outputBuffer, tempIndices, tempLogits);
    const argmaxBindGroup = device.createBindGroup({
      label: 'argmax_bind_group',
      layout: bindGroupLayout,
      entries,
    });

    if (recorder) {
      recordDispatch(
        recorder,
        singlePassPipeline ?? argmaxPipeline,
        argmaxBindGroup,
        useSinglePassArgmax ? 1 : numWorkgroups,
        'argmax_phase1'
      );
      if (reducePipeline) {
        const reduceBindGroup = device.createBindGroup({
          label: 'argmax_reduce_bind_group',
          layout: bindGroupLayout,
          entries,
        });
        recordDispatch(recorder, reducePipeline, reduceBindGroup, 1, 'argmax_phase2');
      }
      recorder.trackTemporaryBuffer(tempLogits);
      recorder.trackTemporaryBuffer(tempIndices);
      completed = true;
      return outputBuffer;
    }
    const encoder = device.createCommandEncoder({ label: 'argmax_encoder' });

    const pass1 = encoder.beginComputePass({ label: 'argmax_pass1' });
    pass1.setPipeline(singlePassPipeline ?? argmaxPipeline);
    pass1.setBindGroup(0, argmaxBindGroup);
    pass1.dispatchWorkgroups(useSinglePassArgmax ? 1 : numWorkgroups);
    pass1.end();

    if (reducePipeline) {
      const reduceBindGroup = device.createBindGroup({
        label: 'argmax_reduce_bind_group',
        layout: bindGroupLayout,
        entries,
      });

      const pass2 = encoder.beginComputePass({ label: 'argmax_pass2' });
      pass2.setPipeline(reducePipeline);
      pass2.setBindGroup(0, reduceBindGroup);
      pass2.dispatchWorkgroups(1);
      pass2.end();
    }

    device.queue.submit([encoder.finish()]);

    return await readTokenFromOutput(outputBuffer, outputIndex);
  } finally {
    if (!recorder || !completed) {
      cleanupRunResources(
        recorder ? null : uniformBuffer,
        [tempLogits, tempIndices, ownsOutputBuffer ? outputBuffer : null]
      );
    }
  }
}

export async function runArgmax(
  logits,
  vocabSize,
  options = {}
) {
  return executeArgmax(null, logits, vocabSize, options);
}


async function executeGPUSample(
  recorder,
  logits,
  vocabSize,
  options = {}
) {
  if (!recorder && !allowReadback('sample.runGPUSample')) {
    throw new Error('[Sample] GPU readback disabled for sampling');
  }

  assertSampleOptions(options, Boolean(recorder));

  const {
    temperature,
    topK: requestedTopK,
    topP,
    randomSeed,
    padTokenId,
    logitSoftcap,
    greedyThreshold,
    outputBuffer: outputBufferOverride,
    outputIndex,
  } = options;
  const logitsDtype = resolveLogitsDtype(options.logitsDtype);

  const { topK, numWorkgroups, scratchBytes } = resolveSampleGeometry(vocabSize, requestedTopK);
  if (isGreedySampling(temperature, topK, greedyThreshold)) {
    return executeArgmax(recorder, logits, vocabSize, {
      padTokenId,
      logitSoftcap,
      logitsDtype,
      outputBuffer: outputBufferOverride,
      outputIndex,
    });
  }

  const device = recorder ? recorder.device : getDevice();
  if (!device) throw new Error('GPU device not initialized');

  const randomValue = randomSeed !== undefined
    ? seededRandom(randomSeed)
    : unseededRandom();

  const variants = resolveSampleVariants(logitsDtype);
  const phase1Pipeline = await createSamplePipeline(device, variants.phase1);
  const phase2Pipeline = await createSamplePipeline(device, variants.phase2);
  const phase3Pipeline = await createSamplePipeline(device, variants.phase3);

  let topkLogits = null;
  let topkIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let uniformBuffer = null;
  let completed = false;
  try {
    topkLogits = acquireBuffer(scratchBytes, undefined, 'topk_logits');
    topkIndices = acquireBuffer(scratchBytes, undefined, 'topk_indices');
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = outputBufferOverride ?? acquireBuffer(minOutputBytes, undefined, 'sample_output');
    ownsOutputBuffer = !outputBufferOverride;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'sample outputIndex');

    uniformBuffer = createSampleUniformBuffer(
      device,
      recorder,
      variants.phase1,
      vocabSize,
      topK,
      temperature,
      randomValue,
      padTokenId,
      logitSoftcap,
      outputIndex,
      topP
    );

    const bindGroupLayout = getSampleBindGroupLayout(device, variants.phase1);
    const bindGroup = device.createBindGroup({
      label: 'sample_bind_group',
      layout: bindGroupLayout,
      entries: sampleBindingEntries(variants.phase1, uniformBuffer, logits, outputBuffer, topkIndices, topkLogits),
    });

    if (recorder) {
      recordDispatch(recorder, phase1Pipeline, bindGroup, numWorkgroups, 'sample_phase1');
      recordDispatch(recorder, phase2Pipeline, bindGroup, 1, 'sample_phase2');
      recordDispatch(recorder, phase3Pipeline, bindGroup, 1, 'sample_phase3');
      recorder.trackTemporaryBuffer(topkLogits);
      recorder.trackTemporaryBuffer(topkIndices);
      completed = true;
      return outputBuffer;
    }
    const encoder = device.createCommandEncoder({ label: 'sample_encoder' });

    const pass1 = encoder.beginComputePass({ label: 'sample_phase1' });
    pass1.setPipeline(phase1Pipeline);
    pass1.setBindGroup(0, bindGroup);
    pass1.dispatchWorkgroups(numWorkgroups);
    pass1.end();

    const pass2 = encoder.beginComputePass({ label: 'sample_phase2' });
    pass2.setPipeline(phase2Pipeline);
    pass2.setBindGroup(0, bindGroup);
    pass2.dispatchWorkgroups(1);
    pass2.end();

    const pass3 = encoder.beginComputePass({ label: 'sample_phase3' });
    pass3.setPipeline(phase3Pipeline);
    pass3.setBindGroup(0, bindGroup);
    pass3.dispatchWorkgroups(1);
    pass3.end();

    device.queue.submit([encoder.finish()]);

    return await readTokenFromOutput(outputBuffer, outputIndex);
  } finally {
    if (!recorder || !completed) {
      cleanupRunResources(
        recorder ? null : uniformBuffer,
        [topkLogits, topkIndices, ownsOutputBuffer ? outputBuffer : null]
      );
    }
  }
}

export async function runGPUSample(
  logits,
  vocabSize,
  options = {}
) {
  return executeGPUSample(null, logits, vocabSize, options);
}


export async function recordArgmax(
  recorder,
  logits,
  vocabSize,
  options = {}
) {
  return executeArgmax(recorder, logits, vocabSize, options);
}


export async function recordGPUSample(
  recorder,
  logits,
  vocabSize,
  options = {}
) {
  return executeGPUSample(recorder, logits, vocabSize, options);
}


function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

const UNSEEDED_RANDOM_DEFAULT_STATE = 0x6d2b79f5;
let fallbackRandomState = UNSEEDED_RANDOM_DEFAULT_STATE;

function unseededRandom() {
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] / 4294967296;
  }
  fallbackRandomState = (fallbackRandomState + 0x6d2b79f5) >>> 0;
  return fallbackRandomState / 4294967296;
}


export function isGPUSamplingAvailable() {
  return getDevice() !== null;
}
