#!/usr/bin/env node

import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import { openCapsule } from '../src/index.js';
import { destroyDevice } from '../src/gpu/device.js';
import { releaseNodeWebGPU } from '../src/tooling/node-webgpu.js';
import { CAPSULE_V0_TRUSTED_SIGNERS } from '../src/config/capsule-v0-trusted-signers.js';

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function parseArgs(argv) {
  const options = { capsule: null, reference: null, out: null };
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!['--capsule', '--reference', '--out'].includes(token)) throw new Error(`Unknown argument "${token}".`);
    const value = argv[index + 1];
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${token}.`);
    options[token.slice(2)] = value;
    index += 1;
  }
  for (const key of ['capsule', 'reference', 'out']) {
    if (!options[key]) throw new Error(`--${key} is required.`);
  }
  return options;
}

export function isSoftwareAdapter(profile) {
  const adapter = profile?.adapter ?? {};
  const identity = [adapter.vendor, adapter.architecture, adapter.device, adapter.description]
    .map((value) => String(value ?? '').toLowerCase()).join(' ');
  return ['swiftshader', 'llvmpipe', 'software rasterizer'].some((marker) => identity.includes(marker));
}

export function createCapsuleNodeQualificationReceipt({
  capsule,
  session,
  generatedTokenIds,
  expectedTokenIds,
  targetPlanDigestBefore,
  capturedAtUtc,
}) {
  const firstMismatch = generatedTokenIds.findIndex((tokenId, index) => tokenId !== expectedTokenIds[index]);
  const declaredIdentity = session.selectedPlan?.initialExecutionIdentity ?? null;
  const observedIdentity = session.observedInitialExecutionIdentity ?? null;
  if (!declaredIdentity?.digest || !observedIdentity?.digest) {
    throw new Error('Node Capsule qualification requires declared and observed initial execution identities.');
  }
  if (declaredIdentity.digest !== observedIdentity.digest) {
    throw new Error(
      `Node Capsule initial execution identity mismatch: declared ${declaredIdentity.digest}, ` +
      `observed ${observedIdentity.digest}.`
    );
  }
  const digestAfter = session.selectedTargetPlanDigest;
  return {
    schema: 'doppler.capsule-node-qualification/v2',
    passed: generatedTokenIds.length === expectedTokenIds.length
      && firstMismatch === -1
      && targetPlanDigestBefore === digestAfter,
    generatedTokens: generatedTokenIds.length,
    expectedTokens: expectedTokenIds.length,
    firstMismatch,
    capsuleId: session.capsuleId,
    semanticRoot: session.semanticRoot,
    signature: {
      authority: capsule.signature?.authority ?? null,
      algorithm: capsule.signature?.algorithm ?? null,
      publicKeyDigest: capsule.signature?.publicKeyDigest ?? null,
      disposition: 'explicitly-trusted-for-qualification',
    },
    closure: {
      artifacts: capsule.artifacts.length,
      verifiedArtifacts: session.verification?.artifactReceipts?.length ?? 0,
      wgslModules: capsule.wgslModules.length,
      qualifiedEntryPoints: [...(capsule.modelIR?.supportScope?.qualifiedEntryPoints ?? [])],
    },
    targetId: session.selectedTargetId,
    targetPlanDigestBefore,
    targetPlanDigestAfter: digestAfter,
    targetPlanImmutable: targetPlanDigestBefore === digestAfter,
    initialExecutionIdentity: {
      schema: observedIdentity.schema ?? null,
      declaredDigest: declaredIdentity.digest,
      observedDigest: observedIdentity.digest,
      boundBeforePrefill: true,
      executionGraphHash: observedIdentity.executionGraphHash,
      kernelClosureHash: observedIdentity.kernelClosureHash,
      runtimeEngineDigest: observedIdentity.runtimeEngineDigest,
      programLoadPolicyHash: observedIdentity.programLoadPolicyHash ?? null,
    },
    adapter: session.deviceProfile.adapter,
    surface: session.deviceProfile.surface,
    softwareAdapter: false,
    capturedAtUtc,
  };
}

export async function withNodeCapsuleQualificationLifecycle(openSession, runSession, lifecycle = {}) {
  const destroy = lifecycle.destroyDevice ?? destroyDevice;
  const release = lifecycle.releaseNodeWebGPU ?? releaseNodeWebGPU;
  let session = null;
  try {
    session = await openSession();
    return await runSession(session);
  } finally {
    try {
      await session?.close?.();
    } finally {
      try {
        destroy();
      } finally {
        await release();
      }
    }
  }
}

export async function qualifyCapsuleV0Node(options = parseArgs(process.argv.slice(2))) {
  const capsulePath = path.resolve(REPO_ROOT, options.capsule);
  const capsule = JSON.parse(await fs.readFile(capsulePath, 'utf8'));
  const reference = JSON.parse(await fs.readFile(path.resolve(REPO_ROOT, options.reference), 'utf8'));
  const expected = reference.metrics.referenceTranscript.tokens.ids;
  const generationConfig = reference.metrics.referenceTranscript.generationConfig;
  return withNodeCapsuleQualificationLifecycle(
    () => openCapsule(capsulePath, { trustedSigners: CAPSULE_V0_TRUSTED_SIGNERS }),
    async (session) => {
      const digestBefore = session.selectedTargetPlanDigest;
      if (session.deviceProfile.surface !== 'node-webgpu') {
        throw new Error(`Node qualification selected unexpected surface "${session.deviceProfile.surface}".`);
      }
      if (isSoftwareAdapter(session.deviceProfile)) {
        throw new Error(`Node qualification selected a software adapter: ${JSON.stringify(session.deviceProfile.adapter)}`);
      }
      const generated = await session.generateText({
        ...generationConfig,
        prompt: reference.metrics.prompt,
        maxSeqLen: 4096,
        stopSequences: [],
      });
      const receipt = createCapsuleNodeQualificationReceipt({
        capsule,
        session,
        generatedTokenIds: generated.tokenIds,
        expectedTokenIds: expected,
        targetPlanDigestBefore: digestBefore,
        capturedAtUtc: new Date().toISOString(),
      });
      if (!receipt.passed) throw new Error(`Node Capsule parity failed at token ${receipt.firstMismatch}.`);
      const outputPath = path.resolve(REPO_ROOT, options.out);
      await fs.mkdir(path.dirname(outputPath), { recursive: true });
      await fs.writeFile(outputPath, `${JSON.stringify(receipt, null, 2)}\n`, 'utf8');
      console.log(JSON.stringify({ ...receipt, outputPath: path.relative(REPO_ROOT, outputPath) }, null, 2));
      return receipt;
    }
  );
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  qualifyCapsuleV0Node().catch((error) => {
    console.error(error?.stack || error?.message || String(error));
    process.exitCode = 1;
  });
}
