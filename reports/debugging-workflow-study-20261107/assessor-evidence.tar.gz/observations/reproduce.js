import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { probeNodeGPU } from '../tests/helpers/gpu-probe.js';
import { getDevice, destroyDevice } from '../src/gpu/device.js';
import { releaseNodeWebGPU } from '../src/tooling/node-webgpu.js';
import { float32ToFloat16 } from '../tests/kernels/reference/dequant.js';
const probe=await probeNodeGPU();assert(probe.ready,probe.reason);
const device=getDevice(),owned=[],errors=[];
device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
const alloc=(size,usage,data)=>{const buffer=device.createBuffer({size:Math.max(16,size),usage});owned.push(buffer);if(data)device.queue.writeBuffer(buffer,0,data);return buffer;};
const M=4,N=4,K=1;
const input=new Float32Array([1,2,3,4]),weightValues=[5,6,7,8],weights=Uint16Array.from(weightValues,float32ToFloat16);
const data=new ArrayBuffer(32),view=new DataView(data);
[M,N,K].forEach((n,i)=>view.setUint32(i*4,n,true));view.setFloat32(12,1,true);view.setUint32(16,1,true);
const uniform=alloc(32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST,data),a=alloc(input.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,input),b=alloc(weights.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,weights),c=alloc(M*N*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC),staging=alloc(M*N*4,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
const expected=[];
for(let m=0;m<M;m++)for(let n=0;n<N;n++){let sum=0;for(let k=0;k<K;k++)sum+=input[m*K+k]*weightValues[n*K+k];expected.push(sum);}
const receipt={schema:'pilot-minimal-matmul-reproduction/v1',shape:{M,N,K},input:Array.from(input),weightValues,expected,oracle:'Independent Float64 dot products over exactly represented f32 activations and f16 weights; these integer outputs are exact.',rows:[]};
try{
for(const [label,path] of [['original','observations/original.wgsl'],['fixed','src/gpu/kernels/matmul_f16w_f32a_tiled.wgsl']]){
const code=await fs.readFile(path,'utf8'),module=device.createShaderModule({code});
const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'main'}});
const group=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[uniform,a,b,c].map((buffer,binding)=>({binding,resource:{buffer}}))});
const encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,group);pass.dispatchWorkgroups(1);pass.end();encoder.copyBufferToBuffer(c,0,staging,0,M*N*4);device.queue.submit([encoder.finish()]);await staging.mapAsync(GPUMapMode.READ);
const actual=Array.from(new Float32Array(staging.getMappedRange().slice(0)));staging.unmap();
const mismatches=actual.reduce((count,value,i)=>count+Number(value!==expected[i]),0);
receipt.rows.push({label,path,actual,mismatches,maxAbsError:Math.max(...actual.map((v,i)=>Math.abs(v-expected[i])))});
}
receipt.errors=errors;receipt.passed=receipt.rows[0].mismatches>0&&receipt.rows[1].mismatches===0&&errors.length===0;
await fs.writeFile('observations/reproduction.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt,null,2));assert(receipt.passed);
}finally{await device.queue.onSubmittedWorkDone();for(const buffer of owned)buffer.destroy();destroyDevice();releaseNodeWebGPU();}
