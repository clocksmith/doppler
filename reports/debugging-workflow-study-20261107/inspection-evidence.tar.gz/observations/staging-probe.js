import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { probeNodeGPU } from '../tests/helpers/gpu-probe.js';
import { getDevice, destroyDevice } from '../src/gpu/device.js';
import { releaseNodeWebGPU } from '../src/tooling/node-webgpu.js';
import { float32ToFloat16 } from '../tests/kernels/reference/dequant.js';
const probe=await probeNodeGPU(); assert(probe.ready,probe.reason);
const device=getDevice(), buffers=[], errors=[];
device.addEventListener('uncapturederror', e=>errors.push(e.error.message));
const alloc=(size,usage,data)=>{const b=device.createBuffer({size:Math.max(16,size),usage});buffers.push(b);if(data)device.queue.writeBuffer(b,0,data);return b;};
const M=4,N=4,K=1,input=new Float32Array([1,2,3,4]),weights=new Uint16Array([5,6,7,8].map(float32ToFloat16));
const raw=new ArrayBuffer(32),v=new DataView(raw);[M,N,K].forEach((n,i)=>v.setUint32(i*4,n,true));v.setFloat32(12,1,true);v.setUint32(16,1,true);
const u=alloc(32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST,raw),a=alloc(input.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,input),b=alloc(weights.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,weights),c=alloc(8192,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC),s=alloc(8192,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
const receipt={schema:'pilot-staging-probe/v1',scope:'Capture shared tiles immediately after first workgroup barrier, before accumulation; A=[1,2,3,4], B=[5,6,7,8], M=N=4 K=1.',rows:[]};
try {
for (const name of ['original','candidate']) {
const src=await fs.readFile('observations/'+name+'.wgsl','utf8'),end=src.indexOf('        workgroupBarrier();')+'        workgroupBarrier();'.length;
const code=src.slice(0,end)+`
        for (var i=0u;i<4u;i=i+1u) {
            C[tid*4u+i] = tileA[tid][i];
            C[1024u+tid*4u+i] = tileB[tid][i];
        }
    }
}
`;
await fs.writeFile('observations/staging-'+name+'.wgsl',code);
const module=device.createShaderModule({code});
const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'main'}});
const group=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[u,a,b,c].map((buffer,binding)=>({binding,resource:{buffer}}))});
const encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,group);pass.dispatchWorkgroups(1);pass.end();encoder.copyBufferToBuffer(c,0,s,0,8192);device.queue.submit([encoder.finish()]);await s.mapAsync(GPUMapMode.READ);const actual=new Float32Array(s.getMappedRange().slice(0));s.unmap();
let failures=0;const examples=[];
for(let slot=0;slot<256;slot++) for(let component=0;component<4;component++){
const k=Math.floor(slot/16),row=(slot%16)*4+component;
for(const [offset,expected] of [[0,k===0&&row<4?row+1:0],[1024,k===0&&row<4?row+5:0]]) {
const got=actual[offset+slot*4+component];
if(got!==expected){failures++;if(examples.length<16)examples.push({tile:offset?'B':'A',slot,component,expected,actual:got});}
}}
receipt.rows.push({name,failures,firstA:Array.from(actual.slice(0,4)),firstB:Array.from(actual.slice(1024,1028)),examples});
}
receipt.errors=errors;receipt.passed=receipt.rows[0].failures>0 && receipt.rows[1].failures===0 && errors.length===0;
await fs.writeFile('observations/staging-probe.json',JSON.stringify(receipt,null,2));
console.log(JSON.stringify(receipt,null,2));assert(receipt.passed);
}finally{await device.queue.onSubmittedWorkDone();for(const b of buffers)b.destroy();destroyDevice();releaseNodeWebGPU();}
