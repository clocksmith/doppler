// Register-Tiled Matrix Multiplication Kernel - f16 weights, f32 activations
//
// High-throughput prefill matmul: f32 activations (A), f16 weights (B), f32 output (C).
// Each thread computes a 4x4 tile of C (16 outputs), vs 1 output in matmul_f16w_f32a.
// Workgroup tile: 64x64 with 16x16 = 256 threads.
// This yields 16x more outputs per workgroup than the base f16w_f32a kernel.
//
// C[M,N] = A[M,K] * B^T[N,K]  (transpose_b=1, RDRR row-major layout)
//
// Design:
// - f32 A storage (activations), f16 B storage (weights)
// - f32 shared tiles for broader Vulkan/Dawn compatibility
// - f32 accumulators for numerical stability
// - B loaded from f16 global into f32 shared tile on staging

enable f16;

// Tile dimensions
const TILE_M: u32 = 64u;   // Rows of C per workgroup
const TILE_N: u32 = 64u;   // Cols of C per workgroup
const TILE_K: u32 = 16u;   // K-dimension tile step

// Thread tile: each thread computes a 4x4 block of C
const THREAD_M: u32 = 4u;
const THREAD_N: u32 = 4u;

// Workgroup dimensions: 16x16 = 256 threads
const WG_M: u32 = 16u;
const WG_N: u32 = 16u;

// Shared memory, k-major: tileA[k * WG_M + tx] holds rows tx*4..tx*4+3 of column k,
// tileB[k * WG_N + ty] holds weight rows ty*4..ty*4+3 of column k. Each inner-loop
// step reads one vec4 per operand: A is broadcast across ty, and B is contiguous
// across ty, so neither read bank-conflicts. 64*16 f32 per tile → 8192 bytes total.
var<workgroup> tileA: array<vec4<f32>, 256>;  // TILE_K * WG_M
var<workgroup> tileB: array<vec4<f32>, 256>;  // TILE_K * WG_N

struct Uniforms {
    M: u32,
    N: u32,
    K: u32,
    alpha: f32,
    transpose_b: u32,
    _pad0: u32,
    _pad1: u32,
    _pad2: u32,
}

@group(0) @binding(0) var<uniform> u: Uniforms;
@group(0) @binding(1) var<storage, read> A: array<f32>;
@group(0) @binding(2) var<storage, read> B: array<f16>;
@group(0) @binding(3) var<storage, read_write> C: array<f32>;

@compute @workgroup_size(WG_M, WG_N, 1)
fn main(
    @builtin(local_invocation_id) local_id: vec3<u32>,
    @builtin(workgroup_id) wg_id: vec3<u32>
) {
    let tx = local_id.x;  // 0..15, maps to M dimension
    let ty = local_id.y;  // 0..15, maps to N dimension
    let tid = tx * WG_N + ty;  // Linear thread index 0..255

    // Global row/col base for this thread's 4x4 output tile
    let row_base = wg_id.x * TILE_M + tx * THREAD_M;
    let col_base = wg_id.y * TILE_N + ty * THREAD_N;

    // f32 accumulators: 4x4 = 16 per thread
    var acc00: f32 = 0.0; var acc01: f32 = 0.0; var acc02: f32 = 0.0; var acc03: f32 = 0.0;
    var acc10: f32 = 0.0; var acc11: f32 = 0.0; var acc12: f32 = 0.0; var acc13: f32 = 0.0;
    var acc20: f32 = 0.0; var acc21: f32 = 0.0; var acc22: f32 = 0.0; var acc23: f32 = 0.0;
    var acc30: f32 = 0.0; var acc31: f32 = 0.0; var acc32: f32 = 0.0; var acc33: f32 = 0.0;

    let num_tiles = (u.K + TILE_K - 1u) / TILE_K;

    for (var t: u32 = 0u; t < num_tiles; t = t + 1u) {
        let k_offset = t * TILE_K;

        // Load A tile (f32): 64 rows x 16 cols = 1024 elements, 256 threads → 4 each
        {
            let load_base = tid * 4u;
            for (var i: u32 = 0u; i < 4u; i = i + 1u) {
                let elem_idx = load_base + i;
                let load_row = elem_idx / TILE_K;
                let load_col = elem_idx % TILE_K;
                let global_row = wg_id.x * TILE_M + load_row;
                let global_col = k_offset + load_col;
                let slot = load_col * WG_M + load_row / THREAD_M;
                if (global_row < u.M && global_col < u.K) {
                    tileA[slot][load_row % THREAD_M] = A[global_row * u.K + global_col];
                } else {
                    tileA[slot][load_row % THREAD_M] = 0.0;
                }
            }
        }

        // Load B tile (f16 → f32): B is [N, K] (row-major/transposed)
        {
            let load_base = tid * 4u;
            for (var i: u32 = 0u; i < 4u; i = i + 1u) {
                let elem_idx = load_base + i;
                let load_row = elem_idx / TILE_K;  // N-dimension local offset
                let load_col = elem_idx % TILE_K;  // K-dimension local offset
                let global_n = wg_id.y * TILE_N + load_row;
                let global_k = k_offset + load_col;
                let slot = load_col * WG_N + load_row / THREAD_N;
                if (global_n < u.N && global_k < u.K) {
                    tileB[slot][load_row % THREAD_N] = f32(B[global_n * u.K + global_k]);
                } else {
                    tileB[slot][load_row % THREAD_N] = 0.0;
                }
            }
        }

        workgroupBarrier();
        for (var i=0u;i<4u;i=i+1u) {
            C[tid*4u+i] = tileA[tid][i];
            C[1024u+tid*4u+i] = tileB[tid][i];
        }
    }
}
