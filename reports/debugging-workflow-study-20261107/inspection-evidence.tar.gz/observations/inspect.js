import fs from 'node:fs/promises';
import { load } from '../src/index.js';
import { destroyDevice } from '../src/gpu/device.js';
import { releaseNodeWebGPU } from '../src/tooling/node-webgpu.js';
const workload = JSON.parse(await fs.readFile('case/workload.json'));
const reference = JSON.parse(await fs.readFile('case/reference.json'));
let model;
try {
 model = await load({url:new URL('../model/',import.meta.url).href},{isolatedLoader:true});
 const result = await model.inspect.generate(workload.prompt,{policyId:'demo/guided-quality',generation:workload.generation,topKSize:10,inputTokenIds:reference.inputTokenIds});
 await fs.writeFile('observations/inspection-before.json',JSON.stringify(result,null,2));
 console.log(JSON.stringify({input:result.inputTokenIds,output:result.outputText,tokens:result.tokens.slice(0,2),fingerprint:result.fingerprint}));
} finally {await model?.unload();destroyDevice();releaseNodeWebGPU();}
