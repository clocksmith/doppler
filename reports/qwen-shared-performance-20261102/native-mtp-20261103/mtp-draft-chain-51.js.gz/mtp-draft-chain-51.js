import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/home/x/deco/doppler/tests/helpers/gpu-probe.js';
import {createPipeline} from '/home/x/deco/doppler/src/inference/pipelines/text.js';
import {createNodeFileArtifactStorageContext} from '/home/x/deco/doppler/src/storage/artifact-storage-context.js';
import {getDevice,destroyDevice,getKernelCapabilities} from '/home/x/deco/doppler/src/gpu/device.js';
import {releaseNodeWebGPU} from '/home/x/deco/doppler/src/tooling/node-webgpu.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/home/x/deco/doppler/src/memory/buffer-pool.js';
import {createTensor} from '/home/x/deco/doppler/src/gpu/tensor.js';
import {createWeightBuffer} from '/home/x/deco/doppler/src/gpu/weight-buffer.js';
import {recordRMSNorm} from '/home/x/deco/doppler/src/gpu/kernels/rmsnorm.js';
import {recordQ40Matmul} from '/home/x/deco/doppler/src/gpu/kernels/q4_0.js';
import {createCommandRecorder} from '/home/x/deco/doppler/src/gpu/command-recorder.js';
import {runPipelineOperation} from '/home/x/deco/doppler/src/inference/pipelines/shader-scoped-pipeline.js';
import {buildLayerContext} from '/home/x/deco/doppler/src/inference/pipelines/text/generator/session-context.js';
import {resolveActiveExecutionPlan} from '/home/x/deco/doppler/src/inference/pipelines/text/execution-plan.js';
import {processLayerGPU} from '/home/x/deco/doppler/src/inference/pipelines/text/layer.js';
import {embed} from '/home/x/deco/doppler/src/inference/pipelines/text/embed.js';
import {getWeightDtype,getWeightMetadata,isWeightBuffer} from '/home/x/deco/doppler/src/gpu/weight-buffer.js';
import {selectRuleValue} from '/home/x/deco/doppler/src/rules/rule-registry.js';
import {recordLogitsGPU} from '/home/x/deco/doppler/src/inference/pipelines/text/logits/index.js';
import {getLogitsWeights,getLogitsConfig} from '/home/x/deco/doppler/src/inference/pipelines/text/generator/logits-config.js';
import {recordArgmax} from '/home/x/deco/doppler/src/gpu/kernels/sample.js';
const root='/run/media/x/deco-backup/doppler-shared-platform-20261102',dir=root+'/mtp-aux-native-43',fixture=root+'/mtp-conditioning-fixture-45',raw=root+'/mtp-source-raw-34';
let pipeline;const owned=[],errors=[],receipt={scope:'Three actual learned MTP auxiliary drafts chained on GPU, controlled initial hidden input, not target-verified generation',qualified:false};
const upload=async file=>{const data=await fs.readFile(file),buffer=acquireBuffer(data.byteLength);owned.push(buffer);uploadData(buffer,data);return buffer;};
const alloc=size=>{const b=acquireBuffer(size);owned.push(b);return b;};
try {
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
 const manifest=JSON.parse(await fs.readFile(dir+'/manifest.json','utf8')),policy=JSON.parse(await fs.readFile(fixture+'/policy.json','utf8'));
 pipeline=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(dir).href,manifest),runtimeConfig:{shared:{kernelWarmup:{warmGeneration:null}},inference:{moe:{routing:{activeExpertSelection:'topk-route',normalizeWeights:true}},session:{kvcache:{maxSeqLen:64,kvDtype:'f16'}}}}});
 const H=policy.hiddenSize,normE=await upload(raw+'/blk.40.nextn.enorm.weight.bin'),normH=await upload(raw+'/blk.40.nextn.hnorm.weight.bin');
 const proj=createWeightBuffer(await upload(raw+'/blk.40.nextn.eh_proj.weight.bin'),'q8_0','row',[H,2*H]);
 let previous=await upload(fixture+'/hidden.bin');const draftIDs=alloc(12),seedIDs=alloc(4);uploadData(seedIDs,new Uint32Array([1058]));
 await runPipelineOperation(pipeline,async state=>{
   const recorder=createCommandRecorder('mtp_three_gpu_drafts');let submitted=false;const recordedHeads=[];
   try {
     for(let step=0;step<3;step++) {
       const config=state.modelConfig,weight=state.weights.get('embed'),metadata=getWeightMetadata(weight);
       const E=await embed(step===0?seedIDs:draftIDs,isWeightBuffer(weight)?weight.buffer:weight,{
         hiddenSize:H,vocabSize:config.vocabSize,scaleEmbeddings:config.scaleEmbeddings,embeddingScale:config.embeddingScale,embeddingNormalization:config.embeddingNormalization,
         recorder,numTokens:1,indexOffset:Math.max(0,step-1),transpose:state.embeddingTranspose,activationDtype:'f32',intermediatePrecision:'f32',
         embeddingDtype:selectRuleValue('inference','dtype','embeddingDtype',{dtype:getWeightDtype(weight)}),embeddingStorageEncoding:metadata?.storageEncoding??null,
         debugProbes:state.runtimeConfig.shared.debug.probes,executionPolicies:state.executionV1State?.policies??null});
       recorder.trackTemporaryBuffer(E.buffer);
       const outputs=Array.from({length:4},(_,index)=>{const b=alloc((index===2?2*H:H)*4);return b;});
       await recordRMSNorm(recorder,E,normE,policy.rmsNormEps,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:outputs[0]});
       await recordRMSNorm(recorder,createTensor(previous,'f32',[1,H]),normH,policy.rmsNormEps,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:outputs[1]});
       const encoder=recorder.getEncoder();encoder.copyBufferToBuffer(outputs[0],0,outputs[2],0,H*4);encoder.copyBufferToBuffer(outputs[1],0,outputs[2],H*4,H*4);
       await recordQ40Matmul(recorder,createTensor(outputs[2],'f32',[1,2*H]),proj,1,H,2*H,{variant:'q8_0_gemv',outputDtype:'f32',outputBuffer:outputs[3]});
       const execution=resolveActiveExecutionPlan(state),context=buildLayerContext(state,recorder,true,null,async()=>{},execution);context.currentSeqLen=step;
       previous=await processLayerGPU(0,outputs[3],1,false,H*4,context);recorder.trackTemporaryBuffer(previous);state.currentSeqLen=step+1;
       const head=await recordLogitsGPU(recorder,previous,1,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});
       assert.equal(head.logitsDtype,'f32');owned.push(head.logitsBuffer);recordedHeads.push(head);
       await recordArgmax(recorder,head.logitsBuffer,head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:head.logitsDtype,outputBuffer:draftIDs,outputIndex:step});
     }
     recorder.submit({cleanup:'deferred'});submitted=true;await device.queue.onSubmittedWorkDone();
     const tokens=Array.from(new Uint32Array(await readBuffer(draftIDs,12)));receipt.drafts=tokens;
     receipt.diagnosticArgmax=[];
     for(let j=0;j<3;j++) {
       // Test-only observation after execution: no readback tensor feeds the draft chain.
       const logits=new Float32Array(await readBuffer(recordedHeads[j].logitsBuffer,recordedHeads[j].vocabSize*4));
       let best=0;for(let i=1;i<logits.length;i++)if(logits[i]>logits[best])best=i;
       assert.equal(tokens[j],best);assert.ok(logits.every(Number.isFinite));receipt.diagnosticArgmax.push({step:j,gpu:tokens[j],cpu:best,finite:true});
     }
     receipt.recorder=recorder.getStats();assert.equal(receipt.recorder.submissionCount,1);receipt.adapter=getKernelCapabilities().adapterInfo;
   }finally{if(submitted)await recorder.completeDeferredCleanup();else await recorder.abort();}
 });
 receipt.errors=errors;assert.deepEqual(errors,[]);console.log('THREE_GPU_MTP_DRAFTS',JSON.stringify(receipt.drafts));
}catch(error){receipt.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();for(const buffer of owned)releaseBuffer(buffer);await pipeline?.unload();destroyDevice();await releaseNodeWebGPU();await fs.writeFile(root+'/mtp-draft-chain-51.json',JSON.stringify(receipt,null,2)+'\n');}
