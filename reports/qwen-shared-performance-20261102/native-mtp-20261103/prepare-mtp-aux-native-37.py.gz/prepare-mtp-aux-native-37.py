from pathlib import Path
import json,copy,hashlib,os,shutil,errno
r=Path('/run/media/x/deco-backup/doppler-shared-platform-20261102');raw=r/'mtp-source-raw-34';desc=json.loads((raw/'descriptor.json').read_text());base=Path('/run/media/x/models/deco-evidence/doppler-35b-native/rdrr-q4_0-e12da725');m=json.loads((base/'manifest.json').read_text());out=r/'mtp-aux-native-37';assert not out.exists();tmp=out.with_name(out.name+'.preparing-'+str(os.getpid()));tmp.mkdir()
def reuse(source,target):
 try:os.link(source,target);return 'hardlink'
 except OSError as error:
  if error.errno!=errno.EXDEV:raise
  shutil.copyfile(source,target);return 'byte-copy-cross-filesystem'
original=m['tensors'];tensors={k:copy.deepcopy(original[k]) for k in ['token_embd.weight','output.weight']};used=sorted({x['shardIndex'] for t in tensors.values() for x in t['spans']});assert used==list(range(11));shards=[];transport=[]
for i in used:
 shard=copy.deepcopy(m['shards'][i]);filename='base_'+shard['filename'];mode=reuse(base/shard['filename'],tmp/filename);shard['filename']=filename;shards.append(shard);transport.append({'filename':filename,'mode':mode})
limit=64<<20;index=len(shards);offset=0;stream=None;digest=None;global_offset=sum(s['size'] for s in shards);mapping={};copied=0

def open_shard():
 global stream,digest,offset
 stream=(tmp/f'mtp_{index:05d}.bin').open('wb');digest=hashlib.sha256();offset=0

def finish_shard():
 global stream,index,global_offset
 if stream is None:return
 stream.flush();os.fsync(stream.fileno());stream.close();shards.append({'index':index,'filename':f'mtp_{index:05d}.bin','size':offset,'hash':digest.hexdigest(),'offset':global_offset});global_offset+=offset;index+=1;stream=None

def append(data,spans):
 global offset,copied
 v=memoryview(data)
 while v:
  if stream is None:open_shard()
  n=min(len(v),limit-offset);stream.write(v[:n]);digest.update(v[:n]);spans.append({'shardIndex':index,'offset':offset,'size':n});offset+=n;copied+=n;v=v[n:]
  if offset==limit:finish_shard()

for source_name,info in desc['tensors'].items():
 if source_name.endswith('nextn.shared_head_norm.weight'):name='output_norm.weight'
 elif '.nextn.' in source_name:name='mtp.'+source_name.split('.nextn.',1)[1]
 else:name=source_name.replace('blk.40.','blk.0.',1)
 assert name not in tensors
 spans=[];source_digest=hashlib.sha256();dtype={0:'F32',8:'Q8_0',30:'BF16'}[info['ggmlType']];size=0
 with (raw/info['filename']).open('rb') as f:
  while data:=f.read(8<<20):source_digest.update(data);append(data,spans);size+=len(data)
 assert source_digest.hexdigest()==info['sha256']
 merged=[]
 for span in spans:
  if merged and merged[-1]['shardIndex']==span['shardIndex'] and merged[-1]['offset']+merged[-1]['size']==span['offset']:merged[-1]['size']+=span['size']
  else:merged.append(span.copy())
 norm='norm' in name;router='gate_inp' in name;t={'size':size,'shape':list(reversed(info['ggufDimensions'])),'dtype':dtype,'role':'norm' if norm else 'router' if router else 'other','group':'other'}
 if len(merged)==1:t.update(shard=merged[0]['shardIndex'],offset=merged[0]['offset'])
 else:t['spans']=merged
 if dtype=='Q8_0':t['storage']={'packing':'q8_0','blockShape':[32],'blockBytes':34}
 tensors[name]=t;mapping[name]={'sourceTensor':source_name,'sourceSHA256':info['sha256'],'transform':'byte-preserving storage; explicit auxiliary source layer40 maps to component layer0'}
finish_shard()
for name in ['tokenizer.json','tokenizer_config.json']:
 if (base/name).exists():reuse(base/name,tmp/name)
m.update(modelId='qwen-3-6-35b-source-nextn-layer40-native-component',tensors=tensors,shards=shards,totalSize=sum(s['size'] for s in shards),quantization='Q8_0');m['quantizationInfo'].update(weights='q8_0',experts='q8_0',variantTag='nextn-q8_0-hq6k-af32-component');m['architecture']['numLayers']=1;m['inference']['layerPattern']['layerTypes']=['full_attention'];e=m['inference']['execution']
for phase in ['decode','prefill']:
 mat='q8_0_decode' if phase=='decode' else 'q8_0_prefill';attn='attn_decode' if phase=='decode' else 'attn_head256'
 e[phase]=[['input_norm','rmsnorm'],['q_proj',mat,'layer.{L}.self_attn.q_proj'],['k_proj',mat,'layer.{L}.self_attn.k_proj'],['v_proj',mat,'layer.{L}.self_attn.v_proj'],['rope_q','rope'],['rope_k','rope'],['attention',attn],['o_proj',mat,'layer.{L}.self_attn.o_proj'],['attn_residual','residual'],['post_attn_norm','rmsnorm'],['gate_proj',mat,'layer.{L}.mlp.gate_proj'],['up_proj',mat,'layer.{L}.mlp.up_proj'],['activation','silu'],['down_proj',mat,'layer.{L}.mlp.down_proj'],['ffn_residual','residual']]
e['mechanismKernels']=[]
recipe={'purpose':'Internal MTP auxiliary numerical component; not a standalone language model or implemented MTP sampler','source':desc['source'],'sourceAuxiliaryLayer':40,'localExecutionLayer':0,'mapping':mapping,'sharedBaseTensors':['token_embd.weight','output.weight'],'sourceTensorStoragePreserved':True,'transport':transport,'qualified':False}
(tmp/'preparation.json').write_text(json.dumps(recipe,indent=2)+'\n');m['metadata']={'auxiliaryRole':'qwen-nextn-layer-component','standaloneGenerationQualified':False,'mtpRuntimeImplemented':False,'sourceTensorMap':mapping,'baseModelDirectory':str(base),'sourceModelSHA256':desc['source']['sha256']};m.pop('artifactIdentity',None);m.pop('integrityExtensions',None);(tmp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');os.rename(tmp,out);print('AUX_NATIVE_COMPONENT_PREPARED',len(tensors),'tensors',len(shards),'shards',copied,'new source bytes',flush=True)
