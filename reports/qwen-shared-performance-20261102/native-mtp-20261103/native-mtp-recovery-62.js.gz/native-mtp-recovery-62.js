import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/tests/helpers/gpu-probe.js';
import {createPipeline} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text.js';
import {createNodeFileArtifactStorageContext} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/storage/artifact-storage-context.js';
import {getDevice,destroyDevice,getKernelCapabilities} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/device.js';
import {releaseNodeWebGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/tooling/node-webgpu.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/memory/buffer-pool.js';
import {createTensor} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/tensor.js';
import {createWeightBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/weight-buffer.js';
import {recordRMSNorm} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/rmsnorm.js';
import {recordQ40Matmul} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/q4_0.js';
import {createCommandRecorder} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/command-recorder.js';
import {runPipelineOperation} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/shader-scoped-pipeline.js';
import {buildLayerContext} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/generator/session-context.js';
import {resolveActiveExecutionPlan} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/execution-plan.js';
import {processLayerGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/layer.js';
import {embed} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/embed.js';
import {getWeightDtype,getWeightMetadata,isWeightBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/weight-buffer.js';
import {selectRuleValue} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/rules/rule-registry.js';
import {recordLogitsGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/logits/index.js';
import {getLogitsWeights,getLogitsConfig} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/generator/logits-config.js';
import {recordArgmax} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/sample.js';
import {loadRuntimeProfile} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/tooling/browser-harness/runtime-config.js';
import {mergeRuntimeValues} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/config/runtime-merge.js';
import {createLinearAttentionRecovery} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/linear-attention-recovery.js';
import {recordSpeculativeAcceptance} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/speculative-accept.js';
import {checkpointLinearAttentionRuntime} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/linear-attention/state-checkpoint.js';
const root='/run/media/x/deco-backup/doppler-shared-platform-20261102',src=root+'/source-native-mtp-57',raw=root+'/mtp-source-raw-34';
const baseDir='/run/media/x/models/deco-evidence/doppler-35b-native/rdrr-q4_0-e12da725',auxDir=root+'/mtp-aux-native-43';
let base,aux,initial;const owned=[],errors=[],receipt={scope:'Native MoE MTP rejection, complete-state and continuation diagnostic',qualified:false};
const alloc=size=>{const b=acquireBuffer(size);owned.push(b);return b;};
const upload=async file=>{const data=await fs.readFile(file),b=alloc(data.byteLength);uploadData(b,data);return b;};
const tensor=(buffer,n,h)=>createTensor(buffer,'f32',[n,h]);
const embedInto=async(state,recorder,tokens,n,indexOffset=0)=>{
 const c=state.modelConfig,w=state.weights.get('embed'),metadata=getWeightMetadata(w);
 const E=await embed(tokens,isWeightBuffer(w)?w.buffer:w,{hiddenSize:c.hiddenSize,vocabSize:c.vocabSize,scaleEmbeddings:c.scaleEmbeddings,
 embeddingScale:c.embeddingScale,embeddingNormalization:c.embeddingNormalization,recorder,numTokens:n,indexOffset,transpose:state.embeddingTranspose,
 activationDtype:'f32',intermediatePrecision:'f32',embeddingDtype:selectRuleValue('inference','dtype','embeddingDtype',{dtype:getWeightDtype(w)}),
 embeddingStorageEncoding:metadata?.storageEncoding??null,debugProbes:state.runtimeConfig.shared.debug.probes,executionPolicies:state.executionV1State?.policies??null});
 recorder.trackTemporaryBuffer(E.buffer);return E;
};
const recordTarget=async(recorder,tokens,n,pos)=>runPipelineOperation(base,async state=>{
 const H=state.modelConfig.hiddenSize,E=await embedInto(state,recorder,tokens,n),context=buildLayerContext(state,recorder,false,null,undefined,resolveActiveExecutionPlan(state));context.currentSeqLen=pos;
 let hidden=E.buffer;
 for(let l=0;l<state.modelConfig.numLayers;l++){const previous=hidden;hidden=await processLayerGPU(l,hidden,n,true,n*H*4,context);recorder.trackTemporaryBuffer(previous);}
 recorder.trackTemporaryBuffer(hidden);state.currentSeqLen=pos+n;
 const head=await recordLogitsGPU(recorder,hidden,n,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});owned.push(head.logitsBuffer);
 assert.equal(head.logitsDtype,'f32');return {hidden,head};
});
const recordIDs=async(recorder,head,n,out)=>{
 const scratch=alloc(head.vocabSize*4);
 for(let j=0;j<n;j++){recorder.getEncoder().copyBufferToBuffer(head.logitsBuffer,j*head.vocabSize*4,scratch,0,head.vocabSize*4);
 await recordArgmax(recorder,scratch,head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:out,outputIndex:j});}
};
let normE,normH,proj;
const recordAux=async(recorder,tokens,offset,previous,pos,wantHead)=>runPipelineOperation(aux,async state=>{
 const H=state.modelConfig.hiddenSize,E=await embedInto(state,recorder,tokens,1,offset),buffers=[alloc(H*4),alloc(H*4),alloc(2*H*4),alloc(H*4)];
 await recordRMSNorm(recorder,E,normE,1e-6,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:buffers[0]});
 await recordRMSNorm(recorder,tensor(previous,1,H),normH,1e-6,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:buffers[1]});
 const enc=recorder.getEncoder();enc.copyBufferToBuffer(buffers[0],0,buffers[2],0,H*4);enc.copyBufferToBuffer(buffers[1],0,buffers[2],H*4,H*4);
 await recordQ40Matmul(recorder,tensor(buffers[2],1,2*H),proj,1,H,2*H,{variant:'q8_0_gemv',outputDtype:'f32',outputBuffer:buffers[3]});
 const context=buildLayerContext(state,recorder,true,null,undefined,resolveActiveExecutionPlan(state));context.currentSeqLen=pos;
 const hidden=await processLayerGPU(0,buffers[3],1,false,H*4,context);recorder.trackTemporaryBuffer(hidden);state.currentSeqLen=pos+1;
 if(!wantHead)return {hidden};
 const head=await recordLogitsGPU(recorder,hidden,1,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});owned.push(head.logitsBuffer);return {hidden,head};
});
const observeState=async(state,pos)=>{
 const out=new Map();
 for(const [layer,l] of state.linearAttentionRuntime.layers)for(const field of ['convStateGPU','recurrentStateGPU'])out.set(`linear.${layer}.${field}`,new Float32Array(await readBuffer(l[field],l[field].size)));
 for(let i=0;i<state.kvCache.layers.length;i++)if(state.modelConfig.layerTypes[i]==='full_attention'){
  const l=state.kvCache.layers[i],bytes=pos*state.kvCache.kvSize*4;
  for(const field of ['keysGPU','valuesGPU'])if(l[field])out.set(`kv.${i}.${field}`,new Float32Array(await readBuffer(l[field],bytes)));
 }
 return out;
};
const compareState=(actual,expected)=>{
 let maxAbs=0,bitDifferences=0,worst=null,values=0;
 assert.deepEqual([...actual.keys()],[...expected.keys()]);
 for(const [name,a] of actual){const e=expected.get(name);assert.equal(a.length,e.length);const aw=new Uint32Array(a.buffer),ew=new Uint32Array(e.buffer);values+=a.length;
  for(let i=0;i<a.length;i++){assert.ok(Number.isFinite(a[i])&&Number.isFinite(e[i]));const d=Math.abs(a[i]-e[i]);if(d>maxAbs){maxAbs=d;worst={name,index:i,actual:a[i],expected:e[i]};}if(aw[i]!==ew[i])bitDifferences++;}}
 return {maxAbs,bitDifferences,values,worst,withinFrozenTolerance:maxAbs<=0.001};
};
try{
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
 const profile=await loadRuntimeProfile('profiles/qwen3-6-35b-a3b-q4_0-candidate',{baseUrl:pathToFileURL(src+'/src/config/runtime').href});
 const runtimeConfig=mergeRuntimeValues(profile.runtime,{shared:{kernelWarmup:{warmGeneration:null}},inference:{session:{kvcache:{maxSeqLen:128,kvDtype:'f32'}}}});
 let manifest=JSON.parse(await fs.readFile(baseDir+'/manifest.json','utf8'));let start=performance.now();
 base=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(baseDir).href,manifest),runtimeConfig});
 const bs=base.generator._state;for(let l=0;l<bs.modelConfig.numLayers;l++)assert.ok(await bs.dopplerLoader.loadExpert(l,0));receipt.baseReadyMs=performance.now()-start;console.log('BASE_READY',receipt.baseReadyMs);
 manifest=JSON.parse(await fs.readFile(auxDir+'/manifest.json','utf8'));
 aux=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(auxDir).href,manifest),runtimeConfig:{shared:{kernelWarmup:{warmGeneration:null}},inference:{moe:{routing:{activeExpertSelection:'topk-route',normalizeWeights:true}},session:{kvcache:{maxSeqLen:128,kvDtype:'f16'}}}}});
 normE=await upload(raw+'/blk.40.nextn.enorm.weight.bin');normH=await upload(raw+'/blk.40.nextn.hnorm.weight.bin');proj=createWeightBuffer(await upload(raw+'/blk.40.nextn.eh_proj.weight.bin'),'q8_0','row',[2048,4096]);
 const prompt=bs.tokenizer.encode('1, 2, 3,');assert.ok(Array.isArray(prompt));receipt.promptIDs=prompt;const S=prompt.length,H=bs.modelConfig.hiddenSize;
 const promptIDs=alloc(S*4);uploadData(promptIDs,new Uint32Array(prompt));const seed=alloc(4),previous=alloc(H*4),promptRec=createCommandRecorder('mtp_prompt');
 let promptSubmitted=false;
 try{
  const result=await recordTarget(promptRec,promptIDs,S,0);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(S-1)*H*4,previous,0,H*4);
  const lastHead={...result.head,logitsBuffer:alloc(result.head.vocabSize*4)};promptRec.getEncoder().copyBufferToBuffer(result.head.logitsBuffer,(S-1)*result.head.vocabSize*4,lastHead.logitsBuffer,0,result.head.vocabSize*4);await recordIDs(promptRec,lastHead,1,seed);
  for(let pos=1;pos<S;pos++){const row=alloc(H*4);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(pos-1)*H*4,row,0,H*4);await recordAux(promptRec,promptIDs,pos,row,pos,false);}
  promptRec.submit({cleanup:'deferred'});promptSubmitted=true;await device.queue.onSubmittedWorkDone();
 }finally{if(promptSubmitted)await promptRec.completeDeferredCleanup();else await promptRec.abort();}
 const first=new Uint32Array(await readBuffer(seed,4))[0];receipt.seed=first;
 initial=await checkpointLinearAttentionRuntime(bs.linearAttentionRuntime);
 const reference=[],referenceStates=[await observeState(bs,S)],referenceLogits=[];let next=first;
 for(let j=0;j<5;j++){
  const rec=createCommandRecorder('mtp_reference'),token=alloc(4),out=alloc(4);uploadData(token,new Uint32Array([next]));
  const result=await recordTarget(rec,token,1,S+j);await recordIDs(rec,result.head,1,out);await rec.submitAndWait();next=new Uint32Array(await readBuffer(out,4))[0];reference.push(next);referenceStates.push(await observeState(bs,S+j+1));referenceLogits.push(new Float32Array(await readBuffer(result.head.logitsBuffer,result.head.vocabSize*4)));
 }
 await initial.restore();bs.kvCache.truncate(S);bs.currentSeqLen=S;receipt.reference=reference;
 receipt.cases=[];
 for(const [name,force,limit,rollback] of [['all',null,4,false],['reject0',0,4,false],['reject1',1,4,false],['reject2',2,4,false],['limit1',null,1,false],['limit2',null,2,false],['cancel-after-submit',null,4,true],['callback-failure-after-submit',null,4,true]]){
  await initial.restore();bs.kvCache.truncate(S);bs.currentSeqLen=S;aux.generator._state.kvCache.truncate(S);aux.generator._state.currentSeqLen=S;
  const rec=createCommandRecorder('native_mtp_'+name),recovery=createLinearAttentionRecovery(rec,4),drafts=alloc(12),targets=alloc(16),inputs=alloc(16),compact=alloc(36);let submitted=false;
  try{
   let hidden=previous;
   for(let j=0;j<3;j++){const draft=await recordAux(rec,j===0?seed:drafts,Math.max(0,j-1),hidden,S+j,true);hidden=draft.hidden;await recordArgmax(rec,draft.head.logitsBuffer,draft.head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:drafts,outputIndex:j});}
   if(force!==null){const wrong=alloc(4);uploadData(wrong,new Uint32Array([0]));rec.getEncoder().copyBufferToBuffer(wrong,0,drafts,force*4,4);}
   const enc=rec.getEncoder();enc.copyBufferToBuffer(seed,0,inputs,0,4);enc.copyBufferToBuffer(drafts,0,inputs,4,12);
   const target=await recordTarget(rec,inputs,4,S);await recordIDs(rec,target.head,4,targets);
   const acceptance=await recordSpeculativeAcceptance(rec,drafts,targets,{draftCount:3,outputLimit:limit,vocabSize:bs.modelConfig.vocabSize,outputBuffer:compact});
   await recovery.recordRecover(rec,acceptance);rec.submit({cleanup:'deferred'});submitted=true;await device.queue.onSubmittedWorkDone();
   const summary=Array.from(new Uint32Array(await readBuffer(compact,36))),count=summary[0];
   const row={name,compact:summary,drafts:Array.from(new Uint32Array(await readBuffer(drafts,12))),capturedLayers:recovery.layerCount,submissions:rec.getStats().submissionCount};
   assert.equal(summary[2],0);assert.equal(count,Math.min(force===null?4:force+1,limit));assert.deepEqual(summary.slice(5,5+count),reference.slice(0,count));row.matchingPublishedTokens=true;
   for(const l of bs.linearAttentionRuntime.layers.values()){l.seqLen=S+count;l.warnedSeqMismatch=false;}bs.kvCache.truncate(S+count);bs.currentSeqLen=S+count;
   row.state=compareState(await observeState(bs,S+count),referenceStates[count]);
   const actualLogits=new Float32Array(await readBuffer(target.head.logitsBuffer,target.head.vocabSize*4*4));let maxAbs=0;
   for(let j=0;j<count;j++)for(let i=0;i<target.head.vocabSize;i++)maxAbs=Math.max(maxAbs,Math.abs(actualLogits[j*target.head.vocabSize+i]-referenceLogits[j][i]));row.logits={maxAbs,withinFrozenTolerance:maxAbs<=0.001};
   if(rollback){
    const restore=createCommandRecorder('native_mtp_failure_restore');recovery.recordRestore(restore);await restore.submitAndWait();bs.kvCache.truncate(S);bs.currentSeqLen=S;for(const l of bs.linearAttentionRuntime.layers.values()){l.seqLen=S;l.warnedSeqMismatch=false;}
    row.rollbackState=compareState(await observeState(bs,S),referenceStates[0]);
   }else{
    const continuation=createCommandRecorder('native_mtp_continuation'),token=alloc(4),out=alloc(4);uploadData(token,new Uint32Array([reference[count-1]]));
    const result=await recordTarget(continuation,token,1,S+count);await recordIDs(continuation,result.head,1,out);await continuation.submitAndWait();row.continuation=new Uint32Array(await readBuffer(out,4))[0];assert.equal(row.continuation,reference[count]);
   }
   receipt.cases.push(row);console.log('NATIVE_MTP_CASE',JSON.stringify(row));
  }finally{recovery.close();if(submitted)await rec.completeDeferredCleanup();else await rec.abort();}
 }
 receipt.remaining=['auxiliary cache refill across windows','public generator callback/cancellation integration','request timing against Pooled'];
 receipt.withinFrozenTolerance=receipt.cases.every(x=>x.state.withinFrozenTolerance&&x.logits.withinFrozenTolerance&&(!x.rollbackState||x.rollbackState.maxAbs===0));
 assert.ok(receipt.withinFrozenTolerance,'Complete-state/logit precision gate failed');
 assert.deepEqual(errors,[]);receipt.errors=errors;
}catch(error){receipt.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();initial?.close();for(const b of owned)releaseBuffer(b);await aux?.unload();await base?.unload();destroyDevice();await releaseNodeWebGPU();await fs.writeFile(root+'/native-mtp-recovery-62.json',JSON.stringify(receipt,null,2)+'\n');}
