import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/home/x/deco/doppler/tests/helpers/gpu-probe.js';
import {createPipeline} from '/home/x/deco/doppler/src/inference/pipelines/text.js';
import {createNodeFileArtifactStorageContext} from '/home/x/deco/doppler/src/storage/artifact-storage-context.js';
import {getDevice,destroyDevice,getKernelCapabilities} from '/home/x/deco/doppler/src/gpu/device.js';
import {releaseNodeWebGPU} from '/home/x/deco/doppler/src/tooling/node-webgpu.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/home/x/deco/doppler/src/memory/buffer-pool.js';
import {createTensor} from '/home/x/deco/doppler/src/gpu/tensor.js';
import {createWeightBuffer} from '/home/x/deco/doppler/src/gpu/weight-buffer.js';
import {recordRMSNorm} from '/home/x/deco/doppler/src/gpu/kernels/rmsnorm.js';
import {recordQ40Matmul} from '/home/x/deco/doppler/src/gpu/kernels/q4_0.js';
import {createCommandRecorder} from '/home/x/deco/doppler/src/gpu/command-recorder.js';
import {runPipelineOperation} from '/home/x/deco/doppler/src/inference/pipelines/shader-scoped-pipeline.js';
import {buildLayerContext} from '/home/x/deco/doppler/src/inference/pipelines/text/generator/session-context.js';
import {resolveActiveExecutionPlan} from '/home/x/deco/doppler/src/inference/pipelines/text/execution-plan.js';
import {processLayerGPU} from '/home/x/deco/doppler/src/inference/pipelines/text/layer.js';
const root='/run/media/x/deco-backup/doppler-shared-platform-20261102',dir=root+'/mtp-aux-native-43',fixture=root+'/mtp-conditioning-fixture-45',raw=root+'/mtp-source-raw-34';
let pipeline;const owned=[],errors=[],receipt={scope:'Actual learned MTP conditioning and one auxiliary MoE layer, one controlled input, not an MTP sampler or target verification',qualified:false};
const upload=async file=>{const data=await fs.readFile(file),buffer=acquireBuffer(data.byteLength);owned.push(buffer);uploadData(buffer,data);return buffer;};
try {
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
 const manifest=JSON.parse(await fs.readFile(dir+'/manifest.json','utf8')),policy=JSON.parse(await fs.readFile(fixture+'/policy.json','utf8'));
 const storage=createNodeFileArtifactStorageContext(pathToFileURL(dir).href,manifest);
 pipeline=await createPipeline(manifest,{storage,runtimeConfig:{shared:{kernelWarmup:{warmGeneration:null}},inference:{moe:{routing:{activeExpertSelection:'topk-route',normalizeWeights:true}},session:{kvcache:{maxSeqLen:64,kvDtype:'f16'}}}}});
 const H=policy.hiddenSize;assert.equal(H,pipeline.modelConfig.hiddenSize);
 const E=createTensor(await upload(fixture+'/embedding.bin'),'f32',[1,H]),T=createTensor(await upload(fixture+'/hidden.bin'),'f32',[1,H]);
 const normE=await upload(raw+'/blk.40.nextn.enorm.weight.bin'),normH=await upload(raw+'/blk.40.nextn.hnorm.weight.bin');
 const proj=createWeightBuffer(await upload(raw+'/blk.40.nextn.eh_proj.weight.bin'),'q8_0','row',[H,2*H]);
 const outputs=Array.from({length:4},(_,index)=>{const b=acquireBuffer((index===2?2*H:H)*4);owned.push(b);return b;});
 await runPipelineOperation(pipeline,async state=>{
   const recorder=createCommandRecorder('mtp_conditioning_aux_component');
   let output,submitted=false;
   try {
     await recordRMSNorm(recorder,E,normE,policy.rmsNormEps,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:outputs[0]});
     await recordRMSNorm(recorder,T,normH,policy.rmsNormEps,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:outputs[1]});
     const encoder=recorder.getEncoder();encoder.copyBufferToBuffer(outputs[0],0,outputs[2],0,H*4);encoder.copyBufferToBuffer(outputs[1],0,outputs[2],H*4,H*4);
     await recordQ40Matmul(recorder,createTensor(outputs[2],'f32',[1,2*H]),proj,1,H,2*H,{variant:'q8_0_gemv',outputDtype:'f32',outputBuffer:outputs[3]});
     const execution=resolveActiveExecutionPlan(state.executionPlanState),context=buildLayerContext(state,recorder,true,null,async()=>{},execution);
     output=await processLayerGPU(0,outputs[3],1,false,H*4,context);
     recorder.submit({cleanup:'deferred'});submitted=true;await device.queue.onSubmittedWorkDone();
     const conditioned=await readBuffer(outputs[3],H*4),hidden=await readBuffer(output,H*4);
     await fs.writeFile(fixture+'/gpu-conditioned.bin',new Uint8Array(conditioned));await fs.writeFile(fixture+'/gpu-aux-hidden.bin',new Uint8Array(hidden));
     const expectedBytes=await fs.readFile(fixture+'/expected-conditioning-f64.bin'),expected=new Float64Array(expectedBytes.buffer.slice(expectedBytes.byteOffset,expectedBytes.byteOffset+expectedBytes.byteLength)),actual=new Float32Array(conditioned);let maxAbs=0;
     for(let i=0;i<H;i++)maxAbs=Math.max(maxAbs,Math.abs(expected[i]-actual[i]));
     receipt.conditioning={maxAbs,threshold:policy.maxAbsDiff,passed:maxAbs<=policy.maxAbsDiff};assert.ok(receipt.conditioning.passed,JSON.stringify(receipt.conditioning));
     receipt.auxiliaryForward={completed:true,outputWords:new Float32Array(hidden).length,finite:Array.from(new Float32Array(hidden)).every(Number.isFinite),referenceQualified:false};
     receipt.recorder=recorder.getStats();receipt.adapter=getKernelCapabilities().adapterInfo;
   }finally{
     if(submitted)await recorder.completeDeferredCleanup();else recorder.abort();
     if(output)releaseBuffer(output);
   }
 });
 receipt.errors=errors;assert.deepEqual(errors,[]);console.log('MTP_CONDITIONING_AND_AUX_LAYER_COMPLETED',JSON.stringify(receipt.conditioning));
}catch(error){receipt.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();for(const buffer of owned)releaseBuffer(buffer);await pipeline?.unload();destroyDevice();await releaseNodeWebGPU();await fs.writeFile(root+'/mtp-aux-forward-46.json',JSON.stringify(receipt,null,2)+'\n');}
