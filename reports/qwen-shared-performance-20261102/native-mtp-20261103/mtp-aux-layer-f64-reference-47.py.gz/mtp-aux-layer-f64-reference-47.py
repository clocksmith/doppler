from pathlib import Path
import numpy as np,json
r=Path('/run/media/x/deco-backup/doppler-shared-platform-20261102');raw=r/'mtp-source-raw-34';fixture=r/'mtp-conditioning-fixture-45';desc=json.loads((raw/'descriptor.json').read_text());eps=float(np.float32(1e-6))
def weight(suffix,expert=None):
 name='blk.40.'+suffix;info=desc['tensors'][name];dims=info['ggufDimensions'];shape=tuple(reversed(dims));p=raw/info['filename']
 if info['ggmlType']==0:return np.fromfile(p,dtype='<f4').astype('f8').reshape(shape)
 if info['ggmlType']==30:return (np.fromfile(p,dtype='<u2').astype('<u4')<<16).view('<f4').astype('f8').reshape(shape)
 if expert is not None:
  rows,cols=dims[1],dims[0];n=rows*cols//32*34
  with p.open('rb') as f:f.seek(expert*n);data=f.read(n)
  q=np.frombuffer(data,dtype='u1').reshape(-1,34);shape=(rows,cols)
 else:q=np.fromfile(p,dtype='u1').reshape(-1,34)
 scales=q[:,:2].copy().view('<f2').reshape(-1).astype('f4');values=q[:,2:].copy().view('i1').astype('f4')
 return (scales[:,None]*values).reshape(shape).astype('f8')
def norm(x,w):return x/np.sqrt(np.mean(x*x,axis=-1,keepdims=True)+eps)*w
def sigmoid(x):
 x=np.asarray(x);out=np.empty_like(x);positive=x>=0;out[positive]=1/(1+np.exp(-x[positive]));e=np.exp(x[~positive]);out[~positive]=e/(1+e);return out
x=np.fromfile(fixture/'gpu-conditioned.bin',dtype='<f4').astype('f8');assert len(x)==2048
n=norm(x,weight('attn_norm.weight'));qg=(weight('attn_q.weight')@n).reshape(16,512);gate=qg[:,256:].reshape(-1)
# At position0 there is exactly one KV row. RoPE is identity and softmax is1.
v=(weight('attn_v.weight')@n).astype('f4').astype('f2').astype('f8').reshape(2,256);a=np.repeat(v,8,axis=0).reshape(-1)*sigmoid(gate);residual=x+weight('attn_output.weight')@a
y=norm(residual,weight('post_attention_norm.weight'));router=weight('ffn_gate_inp.weight')@y;order=np.lexsort((np.arange(256),-router));selected=order[:8];mix=np.exp(router[selected]-router[selected].max());mix/=mix.sum()
ffn=np.zeros(2048,dtype='f8')
for e,p in zip(selected,mix):
 gu=weight('ffn_gate_exps.weight',int(e))@y;up=weight('ffn_up_exps.weight',int(e))@y;ffn+=p*(weight('ffn_down_exps.weight',int(e))@(gu*sigmoid(gu)*up))
gu=weight('ffn_gate_shexp.weight')@y;up=weight('ffn_up_shexp.weight')@y;shared=weight('ffn_down_shexp.weight')@(gu*sigmoid(gu)*up);shared_gate=sigmoid(np.array([weight('ffn_gate_inp_shexp.weight')@y]))[0];expected=residual+ffn+shared_gate*shared
expected.astype('<f8').tofile(fixture/'expected-aux-layer-f64.bin');actual=np.fromfile(fixture/'gpu-aux-hidden.bin',dtype='<f4');delta=np.abs(expected-actual)
report={'scope':'Independent auxiliary layer diagnostic on exactly the same conditioning input; not MTP generation or model qualification','input':'gpu-conditioned.bin','position':0,'cacheDtype':'f16','attentionGate':'sigmoid; GGUF interleaved per-head Q/gate halves','routing':'top8 with normalized softmax, explicit source MoE configuration','selectedExperts':selected.tolist(),'eighthNinthRouterMargin':float(router[order[7]]-router[order[8]]),'maxAbs':float(delta.max()),'argmaxAbsIndex':int(delta.argmax()),'referenceAbsMax':float(np.abs(expected).max()),'finite':bool(np.isfinite(expected).all() and np.isfinite(actual).all()),'componentThreshold':0.001,'passed':bool(delta.max()<=0.001),'qualified':False}
(r/'mtp-aux-layer-f64-reference-47.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
