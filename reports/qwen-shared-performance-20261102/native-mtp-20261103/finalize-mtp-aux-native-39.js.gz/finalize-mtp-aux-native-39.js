import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {buildArtifactIdentity} from '/home/x/deco/doppler/src/converter/artifact-identity.js';
import {refreshManifestIntegrity} from '/home/x/deco/doppler/src/tooling/rdrr-integrity-refresh.js';
const r='/run/media/x/deco-backup/doppler-shared-platform-20261102',source=r+'/mtp-aux-native-37',dest=r+'/mtp-aux-native-39';
await fs.mkdir(dest,{recursive:false});
for(const entry of await fs.readdir(source,{withFileTypes:true})) {
 if(!entry.isFile())throw new Error('Unexpected component directory');
 const from=path.join(source,entry.name),to=path.join(dest,entry.name);
 if(entry.name.endsWith('.bin'))await fs.link(from,to);else await fs.copyFile(from,to);
}
const manifest=JSON.parse(await fs.readFile(dest+'/manifest.json','utf8')),recipe=JSON.parse(await fs.readFile(dest+'/preparation.json','utf8'));
// Q8_0 uses the canonical dtype contract, as in existing native source tensors.
for(const tensor of Object.values(manifest.tensors))if(tensor.dtype==='Q8_0')delete tensor.storage;
manifest.artifactIdentity=await buildArtifactIdentity({
 modelId:manifest.modelId,modelType:manifest.modelType,
 explicitArtifactIdentity:{sourceCheckpointId:'file://'+recipe.source.path,sourceFormat:'gguf',materializationProfile:'source-native-nextn-auxiliary-component'},
 conversionConfigPath:dest+'/preparation.json',conversionConfig:recipe,
 hashString:text=>createHash('sha256').update(text).digest('hex'),hashAlgorithm:manifest.hashAlgorithm,
 shards:manifest.shards,tensorLocations:manifest.tensors,quantizationInfo:manifest.quantizationInfo,inference:manifest.inference,
 converterConfig:{sharding:{shardSizeBytes:67108864},output:{textOnly:true}},manifestConfig:{auxiliaryRole:'qwen-nextn-layer-component'},
});
await fs.writeFile(dest+'/manifest.json',JSON.stringify(manifest,null,2)+'\n');
const result=await refreshManifestIntegrity({modelDir:dest});
await fs.writeFile(r+'/mtp-aux-native-39-integrity.json',JSON.stringify({scope:'Canonical artifact identity and integrity only; no auxiliary execution or MTP qualification',manifestHash:createHash('sha256').update(await fs.readFile(dest+'/manifest.json')).digest('hex'),identity:result.manifest.artifactIdentity,integrityExtensionsHash:result.integrityExtensionsHash},null,2)+'\n');
console.log('AUX_IDENTITY_INTEGRITY_READY',result.manifest.modelId,result.manifest.shards.length);
