import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/tests/helpers/gpu-probe.js';
import {createPipeline} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text.js';
import {createNodeFileArtifactStorageContext} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/storage/artifact-storage-context.js';
import {getDevice,destroyDevice,getKernelCapabilities} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/device.js';
import {releaseNodeWebGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/tooling/node-webgpu.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/memory/buffer-pool.js';
import {createTensor} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/tensor.js';
import {createWeightBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/weight-buffer.js';
import {recordRMSNorm} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/rmsnorm.js';
import {recordQ40Matmul} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/q4_0.js';
import {createCommandRecorder} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/command-recorder.js';
import {runPipelineOperation} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/shader-scoped-pipeline.js';
import {buildLayerContext} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/generator/session-context.js';
import {resolveActiveExecutionPlan} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/execution-plan.js';
import {processLayerGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/layer.js';
import {embed} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/embed.js';
import {getWeightDtype,getWeightMetadata,isWeightBuffer} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/weight-buffer.js';
import {selectRuleValue} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/rules/rule-registry.js';
import {recordLogitsGPU} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/logits/index.js';
import {getLogitsWeights,getLogitsConfig} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/generator/logits-config.js';
import {recordArgmax} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/sample.js';
import {loadRuntimeProfile} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/tooling/browser-harness/runtime-config.js';
import {mergeRuntimeValues} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/config/runtime-merge.js';
import {createLinearAttentionRecovery} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/linear-attention-recovery.js';
import {recordSpeculativeAcceptance,recordSpeculativeCarry} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/gpu/kernels/speculative-accept.js';
import {checkpointLinearAttentionRuntime} from '/run/media/x/deco-backup/doppler-shared-platform-20261102/source-native-mtp-57/src/inference/pipelines/text/linear-attention/state-checkpoint.js';
const root='/run/media/x/deco-backup/doppler-shared-platform-20261102',src=root+'/source-native-mtp-57',raw=root+'/mtp-source-raw-34';
const baseDir='/run/media/x/models/deco-evidence/doppler-35b-native/rdrr-q4_0-e12da725',auxDir=root+'/mtp-aux-native-43';
let base,aux,initial;const owned=[],errors=[],receipt={scope:'Consecutive native MoE MTP windows with GPU carry and auxiliary cache refill; not public API qualification',qualified:false};
const alloc=size=>{const b=acquireBuffer(size);owned.push(b);return b;};
const upload=async file=>{const data=await fs.readFile(file),b=alloc(data.byteLength);uploadData(b,data);return b;};
const tensor=(buffer,n,h)=>createTensor(buffer,'f32',[n,h]);
const embedInto=async(state,recorder,tokens,n,indexOffset=0)=>{
 const c=state.modelConfig,w=state.weights.get('embed'),metadata=getWeightMetadata(w);
 const E=await embed(tokens,isWeightBuffer(w)?w.buffer:w,{hiddenSize:c.hiddenSize,vocabSize:c.vocabSize,scaleEmbeddings:c.scaleEmbeddings,
 embeddingScale:c.embeddingScale,embeddingNormalization:c.embeddingNormalization,recorder,numTokens:n,indexOffset,transpose:state.embeddingTranspose,
 activationDtype:'f32',intermediatePrecision:'f32',embeddingDtype:selectRuleValue('inference','dtype','embeddingDtype',{dtype:getWeightDtype(w)}),
 embeddingStorageEncoding:metadata?.storageEncoding??null,debugProbes:state.runtimeConfig.shared.debug.probes,executionPolicies:state.executionV1State?.policies??null});
 recorder.trackTemporaryBuffer(E.buffer);return E;
};
const recordTarget=async(recorder,tokens,n,pos)=>runPipelineOperation(base,async state=>{
 const H=state.modelConfig.hiddenSize,E=await embedInto(state,recorder,tokens,n),context=buildLayerContext(state,recorder,false,null,undefined,resolveActiveExecutionPlan(state));context.currentSeqLen=pos;
 let hidden=E.buffer;
 for(let l=0;l<state.modelConfig.numLayers;l++){const previous=hidden;hidden=await processLayerGPU(l,hidden,n,true,n*H*4,context);recorder.trackTemporaryBuffer(previous);}
 recorder.trackTemporaryBuffer(hidden);state.currentSeqLen=pos+n;
 const head=await recordLogitsGPU(recorder,hidden,n,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});owned.push(head.logitsBuffer);
 assert.equal(head.logitsDtype,'f32');return {hidden,head};
});
const recordIDs=async(recorder,head,n,out)=>{
 const scratch=alloc(head.vocabSize*4);
 for(let j=0;j<n;j++){recorder.getEncoder().copyBufferToBuffer(head.logitsBuffer,j*head.vocabSize*4,scratch,0,head.vocabSize*4);
 await recordArgmax(recorder,scratch,head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:out,outputIndex:j});}
};
let normE,normH,proj;
const recordAux=async(recorder,tokens,offset,previous,pos,wantHead)=>runPipelineOperation(aux,async state=>{
 const H=state.modelConfig.hiddenSize,E=await embedInto(state,recorder,tokens,1,offset),buffers=[alloc(H*4),alloc(H*4),alloc(2*H*4),alloc(H*4)];
 await recordRMSNorm(recorder,E,normE,1e-6,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:buffers[0]});
 await recordRMSNorm(recorder,tensor(previous,1,H),normH,1e-6,{batchSize:1,hiddenSize:H,rmsNormWeightOffset:false,outputBuffer:buffers[1]});
 const enc=recorder.getEncoder();enc.copyBufferToBuffer(buffers[0],0,buffers[2],0,H*4);enc.copyBufferToBuffer(buffers[1],0,buffers[2],H*4,H*4);
 await recordQ40Matmul(recorder,tensor(buffers[2],1,2*H),proj,1,H,2*H,{variant:'q8_0_gemv',outputDtype:'f32',outputBuffer:buffers[3]});
 const context=buildLayerContext(state,recorder,true,null,undefined,resolveActiveExecutionPlan(state));context.currentSeqLen=pos;
 const hidden=await processLayerGPU(0,buffers[3],1,false,H*4,context);recorder.trackTemporaryBuffer(hidden);state.currentSeqLen=pos+1;
 if(!wantHead)return {hidden};
 const head=await recordLogitsGPU(recorder,hidden,1,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});owned.push(head.logitsBuffer);return {hidden,head};
});
try{
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
 const profile=await loadRuntimeProfile('profiles/qwen3-6-35b-a3b-q4_0-candidate',{baseUrl:pathToFileURL(src+'/src/config/runtime').href});
 const runtimeConfig=mergeRuntimeValues(profile.runtime,{shared:{kernelWarmup:{warmGeneration:null}},inference:{session:{kvcache:{maxSeqLen:128,kvDtype:'f32'}}}});
 let manifest=JSON.parse(await fs.readFile(baseDir+'/manifest.json','utf8'));let start=performance.now();
 base=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(baseDir).href,manifest),runtimeConfig});
 const bs=base.generator._state;for(let l=0;l<bs.modelConfig.numLayers;l++)assert.ok(await bs.dopplerLoader.loadExpert(l,0));receipt.baseReadyMs=performance.now()-start;console.log('BASE_READY',receipt.baseReadyMs);
 manifest=JSON.parse(await fs.readFile(auxDir+'/manifest.json','utf8'));
 aux=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(auxDir).href,manifest),runtimeConfig:{shared:{kernelWarmup:{warmGeneration:null}},inference:{moe:{routing:{activeExpertSelection:'topk-route',normalizeWeights:true}},session:{kvcache:{maxSeqLen:128,kvDtype:'f16'}}}}});
 normE=await upload(raw+'/blk.40.nextn.enorm.weight.bin');normH=await upload(raw+'/blk.40.nextn.hnorm.weight.bin');proj=createWeightBuffer(await upload(raw+'/blk.40.nextn.eh_proj.weight.bin'),'q8_0','row',[2048,4096]);
 const prompt=bs.tokenizer.encode('1, 2, 3,');assert.ok(Array.isArray(prompt));receipt.promptIDs=prompt;const S=prompt.length,H=bs.modelConfig.hiddenSize;
 const promptIDs=alloc(S*4);uploadData(promptIDs,new Uint32Array(prompt));const seed=alloc(4),previous=alloc(H*4),promptRec=createCommandRecorder('mtp_prompt');
 let promptSubmitted=false;
 try{
  const result=await recordTarget(promptRec,promptIDs,S,0);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(S-1)*H*4,previous,0,H*4);
  const lastHead={...result.head,logitsBuffer:alloc(result.head.vocabSize*4)};promptRec.getEncoder().copyBufferToBuffer(result.head.logitsBuffer,(S-1)*result.head.vocabSize*4,lastHead.logitsBuffer,0,result.head.vocabSize*4);await recordIDs(promptRec,lastHead,1,seed);
  for(let pos=1;pos<S;pos++){const row=alloc(H*4);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(pos-1)*H*4,row,0,H*4);await recordAux(promptRec,promptIDs,pos,row,pos,false);}
  promptRec.submit({cleanup:'deferred'});promptSubmitted=true;await device.queue.onSubmittedWorkDone();
 }finally{if(promptSubmitted)await promptRec.completeDeferredCleanup();else await promptRec.abort();}
 const first=new Uint32Array(await readBuffer(seed,4))[0];receipt.seed=first;
 initial=await checkpointLinearAttentionRuntime(bs.linearAttentionRuntime);
 const reference=[first];let next=first;
 for(let j=0;j<31;j++){
  const rec=createCommandRecorder('mtp_reference'),token=alloc(4),out=alloc(4);uploadData(token,new Uint32Array([next]));
  const result=await recordTarget(rec,token,1,S+j);await recordIDs(rec,result.head,1,out);await rec.submitAndWait();next=new Uint32Array(await readBuffer(out,4))[0];reference.push(next);
 }
 await initial.restore();bs.kvCache.truncate(S);bs.currentSeqLen=S;receipt.reference=reference;
 const generated=[first];receipt.windows=[];
 while(generated.length<32){
  const pos=bs.currentSeqLen,limit=Math.min(4,32-generated.length),rec=createCommandRecorder('native_mtp_consecutive_window'),recovery=createLinearAttentionRecovery(rec,4),drafts=alloc(12),targets=alloc(16),inputs=alloc(16),compact=alloc(36);
  const staging=rec.createTempBuffer(36,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST,'native_mtp_compact_readback');let submitted=false,mapped=false;
  const windowStart=performance.now();
  try{
   let hidden=previous;
   for(let j=0;j<3;j++){const draft=await recordAux(rec,j===0?seed:drafts,Math.max(0,j-1),hidden,pos+j,true);hidden=draft.hidden;await recordArgmax(rec,draft.head.logitsBuffer,draft.head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:drafts,outputIndex:j});}
   const enc=rec.getEncoder();enc.copyBufferToBuffer(seed,0,inputs,0,4);enc.copyBufferToBuffer(drafts,0,inputs,4,12);
   const target=await recordTarget(rec,inputs,4,pos);await recordIDs(rec,target.head,4,targets);
   const acceptance=await recordSpeculativeAcceptance(rec,drafts,targets,{draftCount:3,outputLimit:limit,vocabSize:bs.modelConfig.vocabSize,outputBuffer:compact});
   await recovery.recordRecover(rec,acceptance);
   // Refill every possible row. Only the accepted prefix is admitted next round;
   // extra rows remain outside the cache cursor and are overwritten before use.
   for(let j=0;j<4;j++){const row=alloc(H*4);rec.getEncoder().copyBufferToBuffer(target.hidden,j*H*4,row,0,H*4);await recordAux(rec,targets,j,row,pos+j+1,false);}
   await recordSpeculativeCarry(rec,acceptance,tensor(target.hidden,4,H),H,previous,seed);
   rec.getEncoder().copyBufferToBuffer(compact,0,staging,0,36);
   const recordMs=performance.now()-windowStart;rec.submit({cleanup:'deferred'});submitted=true;await staging.mapAsync(GPUMapMode.READ);mapped=true;
   const summary=Array.from(new Uint32Array(staging.getMappedRange()));staging.unmap();mapped=false;assert.equal(summary[2],0);const count=summary[0];
   const tokens=summary.slice(5,5+count);assert.deepEqual(tokens,reference.slice(generated.length,generated.length+count));generated.push(...tokens);
   const nextPos=pos+count;for(const layer of bs.linearAttentionRuntime.layers.values()){layer.seqLen=nextPos;layer.warnedSeqMismatch=false;}bs.kvCache.truncate(nextPos);bs.currentSeqLen=nextPos;aux.generator._state.kvCache.truncate(nextPos);aux.generator._state.currentSeqLen=nextPos;
   const row={pos,limit,emitted:count,accepted:summary[1],nextToken:summary[4],tokens,recordMs,windowMs:performance.now()-windowStart,capturedLayers:recovery.layerCount,recorderSubmissions:rec.getStats().submissionCount,feedbackBytes:36};receipt.windows.push(row);console.log('NATIVE_MTP_WINDOW',JSON.stringify(row));
  }finally{if(mapped)staging.unmap();recovery.close();if(submitted)await rec.completeDeferredCleanup();else await rec.abort();}
 }
 assert.deepEqual(generated,reference);receipt.generated=generated;receipt.matchingPublishedTokens=true;receipt.remaining=['public generator integration','bounded resource reuse across long runs','real task-quality evaluation','paired complete-request timings against Pooled'];
 assert.deepEqual(errors,[]);receipt.errors=errors;
}catch(error){receipt.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();initial?.close();for(const b of owned)releaseBuffer(b);await aux?.unload();await base?.unload();destroyDevice();await releaseNodeWebGPU();await fs.writeFile(root+'/native-mtp-consecutive-58.json',JSON.stringify(receipt,null,2)+'\n');}
