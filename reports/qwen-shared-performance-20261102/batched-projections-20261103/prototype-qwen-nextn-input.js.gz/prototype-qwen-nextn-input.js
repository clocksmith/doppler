import { recordRMSNorm } from '../../../../gpu/kernels/rmsnorm.js';
import { recordMatmul } from '../../../../gpu/kernels/matmul.js';
import { recordGather } from '../../../../gpu/kernels/gather.js';
import { createTensor } from '../../../../gpu/tensor.js';
import { isWeightBuffer } from '../../../../gpu/weight-buffer.js';
import { isNativeGpuBuffer } from '../../../../gpu/buffer-identity.js';
import { acquireBuffer, getBufferRequestedSize } from '../../../../memory/buffer-pool.js';
import { padToQ4KBlock } from '../../../../config/schema/index.js';

/** @type {typeof import('./qwen-nextn-input.js').recordQwenNextnInput} */
export async function recordQwenNextnInput(recorder, embedding, hidden, weights, options) {
  if (!options || !recorder || typeof recorder.getEncoder !== 'function'
    || typeof recorder.trackTemporaryBuffer !== 'function') {
    throw new Error('[QwenNextn] A command recorder and execution options are required.');
  }
  const { numTokens, hiddenSize, epsilon, rmsNormWeightOffset, kernelPath, layerIdx, phase, roles, buffers, normSection } = options;
  if (!Number.isSafeInteger(numTokens) || numTokens < 1 || !Number.isSafeInteger(hiddenSize) || hiddenSize < 1
    || !Number.isSafeInteger(numTokens * hiddenSize * 8)) {
    throw new Error('[QwenNextn] Explicit positive token and hidden geometry is required.');
  }
  if (!Number.isFinite(epsilon) || epsilon <= 0 || typeof rmsNormWeightOffset !== 'boolean'
    || !Number.isSafeInteger(layerIdx) || layerIdx < 0 || (phase !== 'prefill' && phase !== 'decode')
    || kernelPath === undefined || buffers === undefined || !roles
    || (kernelPath !== null && (normSection === undefined || !['preLayer', 'layer', 'postLayer'].includes(normSection)))
    || [roles.embeddingNorm, roles.hiddenNorm, roles.projection].some(role => typeof role !== 'string' || !role)) {
    throw new Error('[QwenNextn] Explicit normalization and kernel-path execution options are required.');
  }
  for (const input of [embedding, hidden]) {
    if (input?.dtype !== 'f32' || input.precision || !Array.isArray(input.shape) || input.shape.length !== 2
      || input.shape[0] !== numTokens || input.shape[1] !== hiddenSize
      || !input.buffer || getBufferRequestedSize(input.buffer) < numTokens * hiddenSize * 4) {
      throw new Error('[QwenNextn] Embedding and hidden inputs must be scalar f32 tensors of the declared shape.');
    }
  }
  const projection = weights?.projection;
  for (const norm of [weights?.embeddingNorm, weights?.hiddenNorm]) {
    if (!isWeightBuffer(norm) || !['f32', 'f16'].includes(norm.dtype) || norm.shape.length !== 1
      || norm.shape[0] !== hiddenSize || getBufferRequestedSize(norm.buffer) < hiddenSize * (norm.dtype === 'f32' ? 4 : 2)) {
      throw new Error('[QwenNextn] Norm weights must declare their dtype and hidden geometry.');
    }
  }
  if (!isWeightBuffer(projection)
    || projection.layout !== 'row' || projection.shape.length !== 2
    || projection.shape[0] !== hiddenSize || projection.shape[1] !== 2 * hiddenSize) {
    throw new Error('[QwenNextn] Norm weights and a row-major [hidden, 2*hidden] projection are required.');
  }
  const normBytes = numTokens * padToQ4KBlock(hiddenSize) * 4;
  const joinedBytes = numTokens * hiddenSize * 8, outputBytes = numTokens * hiddenSize * 4;
  if (buffers !== null) {
    if (typeof buffers !== 'object' || Array.isArray(buffers)) {
      throw new Error('[QwenNextn] Supplied buffers must be a buffer set or null.');
    }
    /** @type {Array<[GPUBuffer, number, number]>} */
    const requirements = [
      [buffers.embeddingNorm, normBytes, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC],
      [buffers.hiddenNorm, normBytes, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC],
      [buffers.combined, joinedBytes, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST],
      [buffers.output, outputBytes, GPUBufferUsage.STORAGE],
    ];
    for (const [buffer, size, usage] of requirements) {
      if (!isNativeGpuBuffer(buffer) || getBufferRequestedSize(buffer) < size || (buffer.usage & usage) !== usage) {
        throw new Error('[QwenNextn] Supplied buffers must have the declared sizes and GPU usages.');
      }
    }
    const all = requirements.map(([buffer]) => buffer);
    const inputs = [embedding.buffer, hidden.buffer, weights.embeddingNorm.buffer, weights.hiddenNorm.buffer, projection.buffer];
    if (new Set(all).size !== all.length || all.some(buffer => inputs.includes(buffer))) {
      throw new Error('[QwenNextn] Supplied buffers must not alias each other or inputs.');
    }
  }
  /** @type {GPUBuffer[]} */
  const owned = [];
  try {
    /** @param {GPUBuffer | undefined} supplied @param {number} bytes @param {string} label */
    const buffer = (supplied, bytes, label) => {
      if (supplied) return supplied;
      const acquired = acquireBuffer(bytes, undefined, label);
      owned.push(acquired);
      return acquired;
    };
    const normOptions = { batchSize: numTokens, hiddenSize, rmsNormWeightOffset, kernelPath, layerIdx, phase, section: normSection };
    const embeddingNormOutput = buffer(buffers?.embeddingNorm, normBytes, 'qwen_nextn_embedding_norm');
    const e = await recordRMSNorm(recorder, embedding, weights.embeddingNorm, epsilon,
      { ...normOptions, role: roles.embeddingNorm, outputBuffer: embeddingNormOutput });
    const hiddenNormOutput = buffer(buffers?.hiddenNorm, normBytes, 'qwen_nextn_hidden_norm');
    const h = await recordRMSNorm(recorder, hidden, weights.hiddenNorm, epsilon,
      { ...normOptions, role: roles.hiddenNorm, outputBuffer: hiddenNormOutput });
    const combined = buffer(buffers?.combined, joinedBytes, 'qwen_nextn_input');
    const encoder = recorder.getEncoder(), rowBytes = hiddenSize * 4;
    for (let token = 0; token < numTokens; token++) {
      encoder.copyBufferToBuffer(e.buffer, token * rowBytes, combined, token * rowBytes * 2, rowBytes);
      encoder.copyBufferToBuffer(h.buffer, token * rowBytes, combined, (token * 2 + 1) * rowBytes, rowBytes);
    }
    const output = buffer(buffers?.output, outputBytes, 'qwen_nextn_projection');
    const projected = await recordMatmul(recorder, createTensor(combined, 'f32', [numTokens, hiddenSize * 2]),
      projection, numTokens, hiddenSize, hiddenSize * 2, {
        transposeB: true, outputDtype: 'f32', outputBuffer: output,
        kernelPath, layerIdx, phaseOverride: phase, role: roles.projection,
      });
    if (buffers === null) owned.pop();
    return projected;
  } finally {
    for (const buffer of owned) recorder.trackTemporaryBuffer(buffer);
  }
}

/** @type {typeof import('./qwen-nextn-input.js').recordQwenNextnInputFromTokens} */
export async function recordQwenNextnInputFromTokens(recorder, tokenIds, embeddingTable, hidden, weights, options) {
  if (!options || !recorder) throw new Error('[QwenNextn] A command recorder and execution options are required.');
  const { numTokens, hiddenSize, vocabSize, indexOffset, embeddingOutput, tokenIdsAreValidated } = options;
  if (!Number.isSafeInteger(numTokens) || numTokens < 1 || !Number.isSafeInteger(hiddenSize) || hiddenSize < 1
    || !Number.isSafeInteger(vocabSize) || vocabSize < 1 || !Number.isSafeInteger(indexOffset) || indexOffset < 0
    || !Number.isSafeInteger((indexOffset + numTokens) * 4)
    || !isNativeGpuBuffer(tokenIds) || getBufferRequestedSize(tokenIds) < (indexOffset + numTokens) * 4
    || (tokenIds.usage & GPUBufferUsage.STORAGE) === 0 || tokenIdsAreValidated !== true) {
    throw new Error('[QwenNextn] Validated GPU token indices and explicit embedding geometry are required.');
  }
  if (!isWeightBuffer(embeddingTable) || embeddingTable.dtype !== 'q4_0' || embeddingTable.layout !== 'row'
    || embeddingTable.shape.length !== 2 || embeddingTable.shape[0] !== vocabSize || embeddingTable.shape[1] !== hiddenSize) {
    throw new Error('[QwenNextn] A row-major Q4_0 embedding table of the declared geometry is required.');
  }
  if (embeddingOutput === undefined || (embeddingOutput !== null
    && (!isNativeGpuBuffer(embeddingOutput) || getBufferRequestedSize(embeddingOutput) < numTokens * hiddenSize * 4
      || (embeddingOutput.usage & GPUBufferUsage.STORAGE) === 0))) {
    throw new Error('[QwenNextn] The embedding output must be a sufficiently sized GPU buffer or null.');
  }
  if (embeddingOutput !== null && [tokenIds, embeddingTable.buffer, hidden?.buffer, weights?.embeddingNorm?.buffer,
    weights?.hiddenNorm?.buffer, weights?.projection?.buffer, ...Object.values(options.buffers ?? {})].includes(embeddingOutput)) {
    throw new Error('[QwenNextn] The embedding output must not alias hidden, weights or prepared buffers.');
  }
  const embedding = await recordGather(recorder, tokenIds, embeddingTable.buffer, numTokens, hiddenSize, vocabSize, {
    embeddingDtype: 'q4_0', outputDtype: 'f32', transpose: false, indexOffset, outputBuffer: embeddingOutput,
  });
  try {
    return await recordQwenNextnInput(recorder, embedding, hidden, weights, options);
  } finally {
    if (embeddingOutput === null) recorder.trackTemporaryBuffer(embedding.buffer);
  }
}
