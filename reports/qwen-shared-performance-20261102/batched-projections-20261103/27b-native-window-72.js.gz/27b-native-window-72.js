import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/tests/helpers/gpu-probe.js';
import {createPipeline} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text.js';
import {createNodeFileArtifactStorageContext} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/storage/artifact-storage-context.js';
import {getDevice,destroyDevice,getKernelCapabilities} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/device.js';
import {releaseNodeWebGPU} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/tooling/node-webgpu.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/memory/buffer-pool.js';
import {createTensor} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/tensor.js';
import {createWeightBuffer} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/weight-buffer.js';
import {recordRMSNorm} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/kernels/rmsnorm.js';
import {recordQ40Matmul} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/kernels/q4_0.js';
import {createCommandRecorder} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/command-recorder.js';
import {runPipelineOperation} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/shader-scoped-pipeline.js';
import {buildLayerContext} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/generator/session-context.js';
import {resolveActiveExecutionPlan} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/execution-plan.js';
import {processLayerGPU} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/layer.js';
import {embed} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/embed.js';
import {getWeightDtype,getWeightMetadata,isWeightBuffer} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/weight-buffer.js';
import {selectRuleValue} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/rules/rule-registry.js';
import {recordLogitsGPU} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/logits/index.js';
import {getLogitsWeights,getLogitsConfig} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/generator/logits-config.js';
import {recordArgmax} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/kernels/sample.js';
import {loadRuntimeProfile} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/tooling/browser-harness/runtime-config.js';
import {mergeRuntimeValues} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/config/runtime-merge.js';
import {createLinearAttentionRecovery} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/kernels/linear-attention-recovery.js';
import {recordSpeculativeAcceptance,recordSpeculativeCarry} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/gpu/kernels/speculative-accept.js';
import {checkpointLinearAttentionRuntime} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/linear-attention/state-checkpoint.js';
const root='/home/x/deco-evidence/doppler-jupiter-20261103',src='/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71';
const baseDir=root+'/27b-native-03';
let base,initial,auxCache,loaded,bs;const owned=[],errors=[],receipt={scope:'32-token experimental native MTP integration screen, not public serving qualification',qualified:false};
let activeOwned=owned;
const alloc=size=>{const b=acquireBuffer(size);activeOwned.push(b);return b;};
const candidateHeadPath=null;
import {open} from 'node:fs/promises';
import {KVCache} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/kv-cache/base.js';
import {loadQwenNextnWeights} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/loader/qwen-nextn-loader.js';
import {recordQwenNextnLayerFromTokens} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/generator/qwen-nextn-layer.js';
import {recordQwenNextnCacheStart} from '/home/x/deco-evidence/doppler-jupiter-20261103/source-27b-native-window-71/src/inference/pipelines/text/generator/qwen-nextn-cache.js';
const sourceFile=await open('/run/media/x/models/deco-evidence/qwen-economics-20261030/Qwen3.8-27B-Q4_0.gguf','r');
let auxContext,draftOptions;
const tensor=(buffer,n,h)=>createTensor(buffer,'f32',[n,h]);
const embedInto=async(state,recorder,tokens,n,indexOffset=0)=>{
 const c=state.modelConfig,w=state.weights.get('embed'),metadata=getWeightMetadata(w);
 const E=await embed(tokens,isWeightBuffer(w)?w.buffer:w,{hiddenSize:c.hiddenSize,vocabSize:c.vocabSize,scaleEmbeddings:c.scaleEmbeddings,
 embeddingScale:c.embeddingScale,embeddingNormalization:c.embeddingNormalization,recorder,numTokens:n,indexOffset,transpose:state.embeddingTranspose,
 activationDtype:'f32',intermediatePrecision:'f32',embeddingDtype:selectRuleValue('inference','dtype','embeddingDtype',{dtype:getWeightDtype(w)}),
 embeddingStorageEncoding:metadata?.storageEncoding??null,debugProbes:state.runtimeConfig.shared.debug.probes,executionPolicies:state.executionV1State?.policies??null});
 recorder.trackTemporaryBuffer(E.buffer);return E;
};
const recordTarget=async(recorder,tokens,n,pos)=>runPipelineOperation(base,async state=>{
 const H=state.modelConfig.hiddenSize,E=await embedInto(state,recorder,tokens,n),context=buildLayerContext(state,recorder,false,null,undefined,resolveActiveExecutionPlan(state));context.currentSeqLen=pos;
 let hidden=E.buffer;
 for(let l=0;l<state.modelConfig.numLayers;l++){const previous=hidden;hidden=await processLayerGPU(l,hidden,n,true,n*H*4,context);recorder.trackTemporaryBuffer(previous);}
 recorder.trackTemporaryBuffer(hidden);state.currentSeqLen=pos+n;
 const head=await recordLogitsGPU(recorder,hidden,n,getLogitsWeights(state),getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});activeOwned.push(head.logitsBuffer);
 assert.equal(head.logitsDtype,'f32');return {hidden,head};
});
const recordIDs=async(recorder,head,n,out)=>{
 const scratch=alloc(head.vocabSize*4);
 for(let j=0;j<n;j++){recorder.getEncoder().copyBufferToBuffer(head.logitsBuffer,j*head.vocabSize*4,scratch,0,head.vocabSize*4);
 await recordArgmax(recorder,scratch,head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:out,outputIndex:j});}
};
const recordAux=async(recorder,tokens,offset,previous,pos,wantHead)=>runPipelineOperation(base,async state=>{
 const H=state.modelConfig.hiddenSize;auxContext.currentSeqLen=pos;
 const hidden=await recordQwenNextnLayerFromTokens(recorder,tokens,state.weights.get('embed'),tensor(previous,1,H),loaded,auxContext,
   {...draftOptions,indexOffset:offset,vocabSize:state.modelConfig.vocabSize,embeddingOutput:null,tokenIdsAreValidated:true});
 recorder.trackTemporaryBuffer(hidden);
 if(!wantHead)return {hidden};
 const head=await recordLogitsGPU(recorder,hidden,1,{finalNorm:loaded.headNorm.buffer,lmHead:state.weights.get('lm_head')},getLogitsConfig(state),state.operatorDiagnostics,{applySoftcap:true});activeOwned.push(head.logitsBuffer);return {hidden,head};
});

try{
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
 const profile=await loadRuntimeProfile('profiles/default',{baseUrl:pathToFileURL(src+'/src/config/runtime/').href});
 const saved=JSON.parse(await fs.readFile(root+'/27b-nextn-screen-config-64.json','utf8'));
 const runtimeConfig=mergeRuntimeValues(profile.runtime,saved.runtimeConfig),path=runtimeConfig.inference.kernelPath;
 const {createHash}=await import('node:crypto');const digest='sha256:'+createHash('sha256').update(await fs.readFile(src+'/src/gpu/kernels/matmul_gguf_pair_columns_f32.wgsl')).digest('hex');
 for(const section of [path,...(path.layerOverrides??[])]){
  if(!section.decode?.steps||!section.prefill?.steps)continue;
  for(let i=0;i<section.prefill.steps.length;i++){
   const step=section.prefill.steps[i],twin=section.decode.steps.find(v=>v.op===step.op&&v.weights===step.weights);
   if(twin&&['matmul_gguf_pair_f32.wgsl','matmul_q5k.wgsl'].includes(twin.kernel)&&step.kernel.startsWith('matmul_')){
    const v=structuredClone(twin);
    if(twin.kernel==='matmul_gguf_pair_f32.wgsl'&&[0,2].includes(twin.constants?.QUANT_FORMAT)){v.kernel='matmul_gguf_pair_columns_f32.wgsl';v.constants={...v.constants,ROWS:1,COLS:4};v.digest=digest;}
    section.prefill.steps[i]=v;
   }
  }
 }
 const decodeHead=path.postLayer.find(v=>v.op==='lm_head');path.postLayer=path.postLayer.map(v=>v.op==='lm_head_prefill'?{...structuredClone(decodeHead),op:'lm_head_prefill'}:v);
 const manifest=JSON.parse(await fs.readFile(baseDir+'/manifest.json','utf8'));let start=performance.now();
 base=await createPipeline(manifest,{storage:createNodeFileArtifactStorageContext(pathToFileURL(baseDir+'/').href,manifest),runtimeConfig});
 bs=base.generator._state;receipt.baseReadyMs=performance.now()-start;console.log('BASE_READY',receipt.baseReadyMs);
 const sourcePlan=JSON.parse(await fs.readFile(root+'/27b-nextn-plan-71.json','utf8'));
 const auxiliaryOwned=[],scope={async load(t){const data=new Uint8Array(t.size);assert.equal((await sourceFile.read(data,0,t.size,t.offset)).bytesRead,t.size);const b=acquireBuffer(t.size);auxiliaryOwned.push(b);uploadData(b,data);return createWeightBuffer(b,t.dtype.toLowerCase(),'row',t.shape,t.name);},async close(){await device.queue.onSubmittedWorkDone();for(const b of auxiliaryOwned)releaseBuffer(b);}};
 loaded=await loadQwenNextnWeights(sourcePlan.plan,scope,{moe:false,maxStorageBufferBindingSize:device.limits.maxStorageBufferBindingSize});
 auxCache=new KVCache({numLayers:1,numHeads:4,headDim:256,maxSeqLen:256,useGPU:true,layout:'contiguous',pageSize:4,kvDtype:'f32'});
 await runPipelineOperation(base,async state=>{
  auxContext=buildLayerContext(state,null,true,null,undefined,resolveActiveExecutionPlan(state));
  Object.assign(auxContext,{config:{...auxContext.config,numLayers:1,layerTypes:['full_attention']},kvCache:auxCache,currentSeqLen:0,pipelinePlan:null,decodeBuffers:null,kernelPath:null,linearAttentionRuntime:null,convLayerStates:new Map(),executionPolicies:null});
  draftOptions={numTokens:1,hiddenSize:state.modelConfig.hiddenSize,epsilon:state.modelConfig.rmsNormEps,rmsNormWeightOffset:false,kernelPath:null,layerIdx:0,phase:'decode',buffers:null,roles:{embeddingNorm:'nextn_embedding_norm',hiddenNorm:'nextn_hidden_norm',projection:'nextn_projection'},trunkCache:state.kvCache};
 });
 const external=JSON.parse(await fs.readFile('/tmp/doppler-jupiter-20261103-screen/results/short-1-pooled.json','utf8'));
 const prompt=external.promptIds;receipt.promptIDs=prompt;const S=prompt.length,H=bs.modelConfig.hiddenSize;
 const promptIDs=alloc(S*4);uploadData(promptIDs,new Uint32Array(prompt));const seed=alloc(4),previous=alloc(H*4),promptRec=createCommandRecorder('mtp_prompt');
 let promptSubmitted=false;
 try{
  const result=await recordTarget(promptRec,promptIDs,S,0);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(S-1)*H*4,previous,0,H*4);
  const lastHead={...result.head,logitsBuffer:alloc(result.head.vocabSize*4)};promptRec.getEncoder().copyBufferToBuffer(result.head.logitsBuffer,(S-1)*result.head.vocabSize*4,lastHead.logitsBuffer,0,result.head.vocabSize*4);await recordIDs(promptRec,lastHead,1,seed);
  recordQwenNextnCacheStart(promptRec,auxContext,bs.kvCache);
  for(let pos=1;pos<S;pos++){const row=alloc(H*4);promptRec.getEncoder().copyBufferToBuffer(result.hidden,(pos-1)*H*4,row,0,H*4);await recordAux(promptRec,promptIDs,pos,row,pos,false);}
  promptRec.submit({cleanup:'deferred'});promptSubmitted=true;await device.queue.onSubmittedWorkDone();
 }finally{if(promptSubmitted)await promptRec.completeDeferredCleanup();else await promptRec.abort();}
 const first=new Uint32Array(await readBuffer(seed,4))[0];receipt.seed=first;
 initial=await checkpointLinearAttentionRuntime(bs.linearAttentionRuntime);
 const reference=[first],referenceHeads=[];let next=first;
 for(let j=0;j<31;j++){
  const rec=createCommandRecorder('mtp_reference'),token=alloc(4),out=alloc(4);uploadData(token,new Uint32Array([next]));
  const result=await recordTarget(rec,token,1,S+j);await recordIDs(rec,result.head,1,out);await rec.submitAndWait();next=new Uint32Array(await readBuffer(out,4))[0];reference.push(next);if(j<4)referenceHeads.push(new Float32Array(await readBuffer(result.head.logitsBuffer,result.head.vocabSize*4)));
 }
 await initial.restore();bs.kvCache.truncate(S);bs.currentSeqLen=S;receipt.reference=reference;
 const generated=[first];receipt.windows=[];
 receipt.externalPrefixMatches=reference.every((token,index)=>token===external.tokenIds[index]);assert.ok(receipt.externalPrefixMatches);
 const nativeStarted=performance.now();
 while(generated.length<32){
  const pos=bs.currentSeqLen,limit=Math.min(4,32-generated.length),rec=createCommandRecorder('native_mtp_profile_window'),recovery=createLinearAttentionRecovery(rec,4),drafts=alloc(12),targets=alloc(16),inputs=alloc(16),compact=alloc(36);
  const staging=rec.createTempBuffer(36,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST,'native_mtp_compact_readback');let submitted=false,mapped=false;
  const windowOwned=[];activeOwned=windowOwned;for(const b of [drafts,targets,inputs,compact]){const i=owned.indexOf(b);if(i>=0){owned.splice(i,1);windowOwned.push(b);}}
  const windowStart=performance.now(),phases=[];
  let previousPass=0,previousClock=windowStart;
  const mark=name=>{const end=rec.getStats().computePassCount,now=performance.now();phases.push({name,start:previousPass,end,recordMs:now-previousClock});previousPass=end;previousClock=now;};
  try{
   let hidden=previous;
   for(let j=0;j<3;j++){const draft=await recordAux(rec,j===0?seed:drafts,Math.max(0,j-1),hidden,pos+j,true);hidden=draft.hidden;await recordArgmax(rec,draft.head.logitsBuffer,draft.head.vocabSize,{padTokenId:null,logitSoftcap:0,logitsDtype:'f32',outputBuffer:drafts,outputIndex:j});}
   mark('draft3');
   const enc=rec.getEncoder();enc.copyBufferToBuffer(seed,0,inputs,0,4);enc.copyBufferToBuffer(drafts,0,inputs,4,12);
   const target=await recordTarget(rec,inputs,4,pos);mark('target_layers_and_batched_head');await recordIDs(rec,target.head,4,targets);mark('target_argmax');
   const acceptance=await recordSpeculativeAcceptance(rec,drafts,targets,{draftCount:3,outputLimit:limit,vocabSize:bs.modelConfig.vocabSize,outputBuffer:compact});
   mark('greedy_accept');await recovery.recordRecover(rec,acceptance);mark('restore_and_recurrent_prefix');
   // Refill every possible row. Only the accepted prefix is admitted next round;
   // extra rows remain outside the cache cursor and are overwritten before use.
   auxCache.truncate(pos+1);auxContext.currentSeqLen=pos+1;
   for(let j=0;j<4;j++){const row=alloc(H*4);rec.getEncoder().copyBufferToBuffer(target.hidden,j*H*4,row,0,H*4);await recordAux(rec,targets,j,row,pos+j+1,false);}
   mark('auxiliary_refill4');await recordSpeculativeCarry(rec,acceptance,tensor(target.hidden,4,H),H,previous,seed);mark('carry');
   rec.getEncoder().copyBufferToBuffer(compact,0,staging,0,36);
   const recordMs=performance.now()-windowStart;rec.submit({cleanup:'deferred'});submitted=true;await staging.mapAsync(GPUMapMode.READ);mapped=true;
   const summary=Array.from(new Uint32Array(staging.getMappedRange()));staging.unmap();mapped=false;assert.equal(summary[2],0);const count=summary[0];
   const tokens=summary.slice(5,5+count);assert.deepEqual(tokens,reference.slice(generated.length,generated.length+count));generated.push(...tokens);
   const nextPos=pos+count;for(const layer of bs.linearAttentionRuntime.layers.values()){layer.seqLen=nextPos;layer.warnedSeqMismatch=false;}bs.kvCache.truncate(nextPos);bs.currentSeqLen=nextPos;auxCache.truncate(nextPos);auxContext.currentSeqLen=nextPos;
   const row={pos,limit,emitted:count,accepted:summary[1],nextToken:summary[4],tokens,recordMs,windowMs:performance.now()-windowStart,capturedLayers:recovery.layerCount,recorderSubmissions:rec.getStats().submissionCount,feedbackBytes:36};if(generated.length-count===1){const actualHead=new Float32Array(await readBuffer(target.head.logitsBuffer,target.head.vocabSize*16));let maxAbs=0;for(let j=0;j<count;j++)for(let k=0;k<target.head.vocabSize;k++)maxAbs=Math.max(maxAbs,Math.abs(actualHead[j*target.head.vocabSize+k]-referenceHeads[j][k]));assert.ok(maxAbs<=0.001,'target head precision gate');row.logitsMaxAbs=maxAbs;}
   row.phases=phases;receipt.windows.push(row);console.log('NATIVE_MTP_WINDOW',JSON.stringify(row));
  }finally{if(mapped)staging.unmap();recovery.close();if(submitted)await rec.completeDeferredCleanup();else await rec.abort();for(const b of windowOwned)releaseBuffer(b);activeOwned=owned;}
 }
 receipt.nativeMs=performance.now()-nativeStarted;assert.deepEqual(generated,reference);receipt.generated=generated;receipt.matchingPublishedTokens=true;receipt.remaining=['public generator integration','bounded resource reuse across long runs','real task-quality evaluation','paired complete-request timings against Pooled'];
 assert.deepEqual(errors,[]);receipt.errors=errors;
}catch(error){receipt.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();initial?.close();for(const b of owned)releaseBuffer(b);auxCache?.destroy();await loaded?.close();await sourceFile.close();await base?.unload();destroyDevice();await releaseNodeWebGPU();await fs.writeFile(root+'/27b-native-window-72.json',JSON.stringify(receipt,null,2)+'\n');}
