import { isNativeGpuBuffer } from '../../../../gpu/buffer-identity.js';
import { KVCache } from '../../../kv-cache/base.js';

// NextN pairs target position i with token i+1. Position zero in its private
// attention cache is a zero KV slot; real auxiliary rows start at position one.
/** @type {typeof import('./qwen-nextn-cache.js').recordQwenNextnCacheStart} */
export function recordQwenNextnCacheStart(recorder, context, trunkCache) {
  const cache = context?.kvCache;
  if (!(cache instanceof KVCache) || cache.layout !== 'contiguous') {
    throw new Error('[QwenNextn] Starting the auxiliary cache requires an empty private contiguous GPU cache.');
  }
  const layer = cache.layers[0], bytes = cache.kvSize * cache.bytesPerElem;
  if (!recorder || trunkCache === undefined || cache === trunkCache
    || cache.numLayers !== 1 || cache.currentSeqLen !== 0 || context.currentSeqLen !== 0 || layer?.seqLen !== 0
    || !Number.isSafeInteger(bytes) || bytes < 4 || bytes % 4 !== 0
    || !isNativeGpuBuffer(layer.keysGPU) || !isNativeGpuBuffer(layer.valuesGPU)
    || layer.keysGPU === layer.valuesGPU
    || layer.keysGPU.size < bytes || layer.valuesGPU.size < bytes
    || (layer.keysGPU.usage & GPUBufferUsage.COPY_DST) === 0 || (layer.valuesGPU.usage & GPUBufferUsage.COPY_DST) === 0) {
    throw new Error('[QwenNextn] Starting the auxiliary cache requires an empty private contiguous GPU cache.');
  }
  const encoder = recorder.getEncoder();
  encoder.clearBuffer(layer.keysGPU, 0, bytes); encoder.clearBuffer(layer.valuesGPU, 0, bytes);
  cache.markAppended(0, 0, 1); context.currentSeqLen = 1;
}
