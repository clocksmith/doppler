import { recordLogitsGPU } from '../logits/gpu-executor.js';
import { recordArgmax } from '../../../../gpu/kernels/sample.js';
import { isWeightBuffer } from '../../../../gpu/weight-buffer.js';
import { isNativeGpuBuffer } from '../../../../gpu/buffer-identity.js';

// Output logits and token storage remain caller-owned; the recorder owns the
// intermediate normalized hidden state. Publication follows target verification.
/** @type {typeof import('./qwen-nextn-head.js').recordQwenNextnHead} */
export async function recordQwenNextnHead(recorder, hidden, headNorm, lmHead, config, options) {
  if (!recorder || !isNativeGpuBuffer(hidden) || !isWeightBuffer(headNorm) || headNorm.dtype !== 'f32'
    || !isWeightBuffer(lmHead) || !config || config.activationDtype !== 'f32' || config.normalizationType !== 'rmsnorm'
    || config.activationPrecision != null || config.activationComponents != null || config.activationElementStrideBytes != null
    || !options || !isNativeGpuBuffer(options.outputBuffer) || !Number.isSafeInteger(options.outputIndex)
    || options.outputIndex < 0 || options.outputBuffer.size < (options.outputIndex + 1) * 4
    || (options.outputBuffer.usage & GPUBufferUsage.STORAGE) === 0
    || options.outputBuffer === hidden || options.outputBuffer === headNorm.buffer || options.outputBuffer === lmHead.buffer
    || options.padTokenId === undefined || options.logitSoftcap === undefined) {
    throw new Error('[QwenNextn] A declared F32 output head and non-aliasing token buffer are required.');
  }
  const logits = await recordLogitsGPU(recorder, hidden, 1, { finalNorm: headNorm.buffer, lmHead }, config);
  try {
    await recordArgmax(recorder, logits.logitsBuffer, logits.vocabSize, {
      logitsDtype: logits.logitsDtype, outputBuffer: options.outputBuffer, outputIndex: options.outputIndex,
      padTokenId: options.padTokenId, logitSoftcap: options.logitSoftcap,
    });
    return logits;
  } catch (error) {
    recorder.trackTemporaryBuffer(logits.logitsBuffer);
    throw error;
  }
}
