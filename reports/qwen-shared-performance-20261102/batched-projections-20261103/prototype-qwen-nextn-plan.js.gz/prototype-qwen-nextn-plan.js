import { ggufBlockBytes } from '../formats/gguf/block-storage.js';

// This source plan is intentionally separate from the base decoder. It validates
// a complete auxiliary layer before any loader may materialize its weights.
/** @type {typeof import('./qwen-nextn-plan.js').prepareQwenNextnSource} */
export function prepareQwenNextnSource(source, geometry) {
  const { hiddenSize: h, numHeads, numKvHeads, headDim, intermediateSize: f, expertCount, sharedIntermediateSize } = geometry;
  if (![h, numHeads, numKvHeads, headDim, f].every(n => Number.isSafeInteger(n) && n > 0)
    || !Number.isSafeInteger(expertCount) || expertCount < 0 || !Number.isSafeInteger(sharedIntermediateSize)
    || (expertCount ? sharedIntermediateSize < 1 : sharedIntermediateSize !== 0)
    || !source || !Number.isSafeInteger(source.firstLayer) || source.firstLayer < 0
    || source.layerCount !== 1 || !Array.isArray(source.tensors)) {
    throw new Error('[QwenNextn] One auxiliary layer and explicit positive geometry are required.');
  }
  /** @type {Record<string, [number[], string[]]>} */
  const specs = {
    'attn_k.weight': [[numKvHeads * headDim, h], ['Q4_0', 'Q8_0']],
    'attn_k_norm.weight': [[headDim], ['F32']],
    'attn_norm.weight': [[h], ['F32']],
    'attn_output.weight': [[h, numHeads * headDim], ['Q4_0', 'Q8_0']],
    'attn_q.weight': [[2 * numHeads * headDim, h], ['Q4_0', 'Q8_0']],
    'attn_q_norm.weight': [[headDim], ['F32']],
    'attn_v.weight': [[numKvHeads * headDim, h], ['Q4_0', 'Q8_0']],
    'nextn.eh_proj.weight': [[h, 2 * h], ['Q8_0']],
    'nextn.enorm.weight': [[h], ['F32']],
    'nextn.hnorm.weight': [[h], ['F32']],
    'nextn.shared_head_norm.weight': [[h], ['F32']],
    'post_attention_norm.weight': [[h], ['F32']],
    ...(expertCount ? {
      'ffn_down_exps.weight': [[expertCount, h, f], ['Q4_0', 'Q8_0']],
      'ffn_gate_exps.weight': [[expertCount, f, h], ['Q4_0', 'Q8_0']],
      'ffn_up_exps.weight': [[expertCount, f, h], ['Q4_0', 'Q8_0']],
      'ffn_gate_inp.weight': [[expertCount, h], ['BF16']],
      'ffn_gate_inp_shexp.weight': [[1, h], ['BF16']],
      'ffn_down_shexp.weight': [[h, sharedIntermediateSize], ['Q4_0', 'Q8_0']],
      'ffn_gate_shexp.weight': [[sharedIntermediateSize, h], ['Q4_0', 'Q8_0']],
      'ffn_up_shexp.weight': [[sharedIntermediateSize, h], ['Q4_0', 'Q8_0']],
    } : {
      'ffn_down.weight': [[h, f], ['Q4_0', 'Q8_0']],
      'ffn_gate.weight': [[f, h], ['Q4_0', 'Q8_0']],
      'ffn_up.weight': [[f, h], ['Q4_0', 'Q8_0']],
    }),
  };
  const prefix = `blk.${source.firstLayer}.`;
  /** @type {Record<string, import('./qwen-nextn-plan.js').QwenNextnTensorSource>} */
  const tensors = {};
  for (const tensor of source.tensors) {
    const name = tensor.name;
    const key = typeof name === 'string' && name.startsWith(prefix) ? name.slice(prefix.length) : '';
    const spec = Object.hasOwn(specs, key) ? specs[key] : null;
    if (!spec || Object.hasOwn(tensors, key)) throw new Error(`[QwenNextn] Unexpected or duplicate auxiliary tensor ${name}.`);
    const [shape, dtypes] = spec;
    if (!Array.isArray(tensor.shape) || tensor.shape.length !== shape.length
      || tensor.shape.some((n, i) => n !== shape[i]) || !dtypes.includes(tensor.dtype)
      || (shape.length > 1 && tensor.layout !== 'row')) {
      throw new Error(`[QwenNextn] Unsupported shape, dtype or layout for ${name}.`);
    }
    const size = tensor.dtype === 'F32' ? shape.reduce((a, b) => a * b, 1) * 4
      : tensor.dtype === 'BF16' ? shape.reduce((a, b) => a * b, 1) * 2
        : ggufBlockBytes(shape, tensor.dtype.toLowerCase());
    if (!Number.isSafeInteger(size) || tensor.size !== size || !Number.isSafeInteger(tensor.offset) || tensor.offset < 0
      || !tensor.source || typeof tensor.source.readRange !== 'function' || !Number.isSafeInteger(tensor.source.size)
      || !Number.isSafeInteger(tensor.offset + size) || tensor.offset + size > tensor.source.size) {
      throw new Error(`[QwenNextn] Invalid source byte range for ${name}.`);
    }
    tensors[key] = tensor;
  }
  for (const key of Object.keys(specs)) {
    if (!Object.hasOwn(tensors, key)) throw new Error(`[QwenNextn] Missing auxiliary tensor ${prefix}${key}.`);
  }
  const values = Object.values(tensors);
  if (values.some(tensor => tensor.source !== values[0].source)) throw new Error('[QwenNextn] Auxiliary tensors must share one source.');
  const ranges = values.map(tensor => [tensor.offset, tensor.offset + tensor.size]).sort((a, b) => a[0] - b[0]);
  if (ranges.some((range, i) => i > 0 && range[0] < ranges[i - 1][1])) throw new Error('[QwenNextn] Auxiliary tensor ranges overlap.');
  return { firstLayer: source.firstLayer, layerCount: 1, tensors };
}
