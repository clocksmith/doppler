import { isWeightBuffer } from '../gpu/weight-buffer.js';
import { getBufferRequestedSize } from '../memory/buffer-pool.js';
import { ggufBlockBytes } from '../formats/gguf/block-storage.js';
import { isNativeGpuBuffer } from '../gpu/buffer-identity.js';

// Map the validated source layer into the ordinary layer executor's weight
// vocabulary. A separate load scope owns every returned allocation.
/** @type {typeof import('./qwen-nextn-loader.js').loadQwenNextnWeights} */
export async function loadQwenNextnWeights(plan, scope, options) {
  if (!plan || plan.layerCount !== 1 || !plan.tensors || !scope || typeof scope.load !== 'function'
    || typeof scope.close !== 'function' || !options || typeof options.moe !== 'boolean'
    || !Number.isSafeInteger(options.maxStorageBufferBindingSize) || options.maxStorageBufferBindingSize < 1) {
    throw new Error('[QwenNextn] An auxiliary source plan, load scope and device binding limit are required.');
  }
  const common = {
    inputNorm: 'attn_norm.weight', qProj: 'attn_q.weight', kProj: 'attn_k.weight', vProj: 'attn_v.weight',
    oProj: 'attn_output.weight', qNorm: 'attn_q_norm.weight', kNorm: 'attn_k_norm.weight',
    postAttentionNorm: 'post_attention_norm.weight',
  };
  const ffn = options.moe ? {
    routerWeight: 'ffn_gate_inp.weight', sharedExpertRouter: 'ffn_gate_inp_shexp.weight',
    sharedExpertGate: 'ffn_gate_shexp.weight', sharedExpertUp: 'ffn_up_shexp.weight',
    sharedExpertDown: 'ffn_down_shexp.weight',
  } : { ffnGate: 'ffn_gate.weight', ffnUp: 'ffn_up.weight', ffnDown: 'ffn_down.weight' };
  const auxiliary = { embeddingNorm: 'nextn.enorm.weight', hiddenNorm: 'nextn.hnorm.weight',
    projection: 'nextn.eh_proj.weight', headNorm: 'nextn.shared_head_norm.weight' };
  const experts = options.moe ? { gate: 'ffn_gate_exps.weight', up: 'ffn_up_exps.weight', down: 'ffn_down_exps.weight' } : {};
  const expected = { ...common, ...ffn, ...auxiliary, ...experts };
  const distinct = new Set(Object.values(expected));
  if (Object.keys(plan.tensors).length !== distinct.size || [...distinct].some(name => !Object.hasOwn(plan.tensors, name))) {
    throw new Error('[QwenNextn] The source plan does not contain exactly the declared layer weights.');
  }
  /** @type {Record<string, import('../gpu/weight-buffer.js').WeightBuffer>} */
  const loaded = {};
  try {
    // Serial acquisition keeps peak transient host and GPU memory bounded. The
    // scope is responsible for integrity, cancellation and allocation accounting.
    for (const [role, key] of Object.entries(expected)) {
      options.signal?.throwIfAborted();
      const source = plan.tensors[key];
      const weight = await scope.load(source, role, options.signal);
      options.signal?.throwIfAborted();
      const wantedDtype = source.dtype === 'BF16' ? 'f32' : source.dtype.toLowerCase();
      const bytes = wantedDtype === 'f32' ? source.shape.reduce((a, b) => a * b, 1) * 4
        : ggufBlockBytes(source.shape, wantedDtype);
      if (!isWeightBuffer(weight) || !isNativeGpuBuffer(weight.buffer) || weight.dtype !== wantedDtype || weight.layout !== 'row'
        || weight.shape.length !== source.shape.length || weight.shape.some((n, i) => n !== source.shape[i])
        || !Number.isSafeInteger(bytes) || getBufferRequestedSize(weight.buffer) < bytes
        || weight.buffer.size > options.maxStorageBufferBindingSize
        || (weight.buffer.usage & GPUBufferUsage.STORAGE) === 0) {
        throw new Error(`[QwenNextn] Materialization for ${source.name} violates its prepared shape, dtype or binding limit.`);
      }
      loaded[role] = weight;
    }
    let closed = false;
    /** @type {import('../inference/pipelines/text/weights.js').LayerWeights} */
    const layer = { inputNorm: loaded.inputNorm.buffer, qProj: loaded.qProj, kProj: loaded.kProj,
      vProj: loaded.vProj, oProj: loaded.oProj, qNorm: loaded.qNorm.buffer, kNorm: loaded.kNorm.buffer,
      postAttentionNorm: loaded.postAttentionNorm.buffer, postAttnNorm: loaded.postAttentionNorm.buffer };
    for (const role of Object.keys(ffn)) Object.assign(layer, { [role]: loaded[role] });
    if (!options.moe) Object.assign(layer, { gate: loaded.ffnGate, up: loaded.ffnUp, down: loaded.ffnDown });
    return { layer, input: { embeddingNorm: loaded.embeddingNorm, hiddenNorm: loaded.hiddenNorm, projection: loaded.projection },
      headNorm: loaded.headNorm, expertBanks: options.moe ? { gate: loaded.gate, up: loaded.up, down: loaded.down } : null,
      async close() { if (!closed) { closed = true; await scope.close(); } } };
  } catch (error) {
    try { await scope.close(); }
    catch (cleanup) { throw new AggregateError([error, cleanup], 'Auxiliary weight loading and cleanup failed.'); }
    throw error;
  }
}
