import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {probeNodeGPU} from '/home/x/deco/doppler/tests/helpers/gpu-probe.js';
import {packedFixture,decodePacked,projectReference} from '/home/x/deco/doppler/tests/helpers/q4_0-fixture.js';
import {getDevice,destroyDevice} from '/home/x/deco/doppler/src/gpu/device.js';
import {acquireBuffer,releaseBuffer,uploadData,readBuffer} from '/home/x/deco/doppler/src/memory/buffer-pool.js';
import {createTensor} from '/home/x/deco/doppler/src/gpu/tensor.js';
import {createWeightBuffer} from '/home/x/deco/doppler/src/gpu/weight-buffer.js';
import {createCommandRecorder} from '/home/x/deco/doppler/src/gpu/command-recorder.js';
import {recordQ40Matmul} from '/home/x/deco/doppler/src/gpu/kernels/q4_0.js';
function fixture(rows, cols) {
  const bytes = new Uint8Array(rows * cols / 256 * 176), view = new DataView(bytes.buffer);
  for (let b = 0; b < rows * cols / 256; b++) {
    const base = b * 176;
    view.setUint16(base, b % 3 === 0 ? 0 : 0x1400, true);
    view.setUint16(base + 2, b % 3 === 2 ? 0 : 0x0c00, true);
    for (let g = 0; g < 8; g++) {
      const scale = (g * 11 + b * 7) % 64, min = (g * 13 + b * 5) % 64;
      if (g < 4) { bytes[base + 4 + g] = scale; bytes[base + 8 + g] = min; }
      else {
        bytes[base + 8 + g] = (scale & 15) | ((min & 15) << 4);
        bytes[base + g] |= (scale >> 4) << 6;
        bytes[base + 4 + g] |= (min >> 4) << 6;
      }
    }
    for (let i = 0; i < 32; i++) bytes[base + 16 + i] = (b * 37 + i * 53) % 256;
    for (let i = 0; i < 128; i++) bytes[base + 48 + i] = (b * 19 + i * 29) % 256;
  }
  return bytes;
}
function decode(bytes) {
  const values = new Float32Array(bytes.length / 176 * 256), view = new DataView(bytes.buffer);
  for (let b = 0; b < bytes.length / 176; b++) {
    const base = b * 176, scales = bytes.subarray(base + 4, base + 16);
    const d = view.getUint16(base, true) === 0 ? 0 : 2 ** -10;
    const minimum = view.getUint16(base + 2, true) === 0 ? 0 : 2 ** -12;
    for (let groupPair = 0; groupPair < 4; groupPair++) {
      for (let half = 0; half < 2; half++) {
        const g = groupPair * 2 + half;
        const scale = g < 4 ? scales[g] & 63 : (scales[g + 4] & 15) | ((scales[g - 4] >> 6) << 4);
        const min = g < 4 ? scales[g + 4] & 63 : (scales[g + 4] >> 4) | ((scales[g] >> 6) << 4);
        for (let l = 0; l < 32; l++) {
          const packed = bytes[base + 48 + groupPair * 32 + l];
          const q = (half ? packed >> 4 : packed & 15) + ((bytes[base + 16 + l] & (1 << g)) ? 16 : 0);
          values[b * 256 + g * 32 + l] = d * scale * q - minimum * min;
        }
      }
    }
  }
  return values;
}

const root='/home/x/deco-evidence/doppler-jupiter-20261103',policy=JSON.parse(await fs.readFile(root+'/q5k-columns-benchmark-policy-75.json','utf8'));
const result={scope:policy.scope,startedAt:new Date().toISOString(),cases:[]},owned=[],errors=[];
const upload=values=>{const b=acquireBuffer(Math.ceil(values.byteLength/4)*4);owned.push(b);uploadData(b,values);return b;};
try{
 assert.ok((await probeNodeGPU({installFileFetchShim:true})).ready);const device=getDevice();device.addEventListener('uncapturederror',e=>errors.push(e.error.message));
 for(const shape of policy.cases){
  const {dtype,M,N,K}=shape,packed=fixture(N,K),values=Float32Array.from({length:M*K},(_,i)=>Math.sin(i*0.017)*0.1);
  const weight=createWeightBuffer(upload(packed),dtype,'row',[N,K]),input=createTensor(upload(values),'f32',[M,K]);
  const firstEight=decode(packed.subarray(0,8*K/256*176)),expected=projectReference(values,firstEight,M,8,K),outputs=new Map(),row={...shape,correctness:[],runs:[]};
  let baseline;
  for(const variant of policy.variants[dtype]){
   const output=upload(new Float32Array(M*N));outputs.set(variant,output);const recorder=createCommandRecorder('columns_gate');
   await recordQ40Matmul(recorder,input,weight,M,N,K,{variant,outputDtype:'f32',outputBuffer:output});await recorder.submitAndWait();const actual=new Float32Array(await readBuffer(output,M*N*4));
   for(let m=0;m<M;m++)for(let n=0;n<8;n++)assert.ok(Math.abs(actual[m*N+n]-expected[m*8+n])<=policy.referenceAbs+policy.referenceRelative*Math.abs(expected[m*8+n]),'independent CPU projection mismatch');
   let maxAbs=0;if(!baseline)baseline=actual;else for(let i=0;i<actual.length;i++)maxAbs=Math.max(maxAbs,Math.abs(actual[i]-baseline[i]));assert.ok(maxAbs<=policy.maxAbsToPaired);row.correctness.push({variant,maxAbsToPaired:maxAbs});
  }
  for(let round=0;round<policy.rounds;round++){
   const order=[...policy.variants[dtype]];if(round%2)order.reverse();
   for(const variant of order){const recorder=createCommandRecorder('columns_timing',{profile:true,profilePhase:'prefill'}),start=performance.now();
    for(let i=0;i<policy.dispatches;i++)await recordQ40Matmul(recorder,input,weight,M,N,K,{variant,outputDtype:'f32',outputBuffer:outputs.get(variant)});
    const recordMs=performance.now()-start;await recorder.submitAndWait();const wallMs=performance.now()-start;const times=await recorder.resolveProfileTimings({requireComplete:true});
    const gpuMs=Object.values(times).reduce((a,b)=>a+b,0)/policy.dispatches;row.runs.push({round,variant,gpuMs,recordMsPerDispatch:recordMs/policy.dispatches,wallMsPerDispatch:wallMs/policy.dispatches});
   }
  }
  result.cases.push(row);console.log('COLUMNS_CASE',JSON.stringify(row));
 }
 assert.deepEqual(errors,[]);result.errors=errors;
}catch(error){result.error=String(error.stack??error);process.exitCode=1;}
finally{await getDevice()?.queue.onSubmittedWorkDone();for(const b of owned)releaseBuffer(b);destroyDevice();result.finishedAt=new Date().toISOString();await fs.writeFile(root+'/q5k-columns-benchmark-75.json',JSON.stringify(result,null,2)+'\n');}
