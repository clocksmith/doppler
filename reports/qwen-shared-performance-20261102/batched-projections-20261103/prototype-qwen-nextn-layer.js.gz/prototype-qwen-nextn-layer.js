import { recordQwenNextnInput, recordQwenNextnInputFromTokens } from './qwen-nextn-input.js';
import { processLayerGPU } from '../layer.js';

// The auxiliary layer has a private one-layer KV cache and executor context.
// The caller owns recorder settlement and must roll back this cache if its
// recorded commands are aborted or the speculative draft is rejected.
/** @param {import('../../../../gpu/command-recorder.js').CommandRecorder} recorder
 * @param {Parameters<import('./qwen-nextn-layer.js').recordQwenNextnLayer>[3]} prepared
 * @param {import('../types.js').LayerContext} context
 * @param {import('./qwen-nextn-layer.js').QwenNextnLayerOptions} options */
function assertLayerContext(recorder, prepared, context, options) {
  const cache = context?.kvCache, config = context?.config;
  if (!recorder || !prepared?.layer || !prepared.input || !options
    || !config || config.numLayers !== 1 || config.layerTypes?.length !== 1 || config.layerTypes[0] !== 'full_attention'
    || context.pipelinePlan != null || context.decodeBuffers != null || context.activationDtype !== 'f32'
    || context.activationPrecision != null || context.activationComponents != null || context.activationElementStrideBytes != null
    || !cache || cache.layout !== 'contiguous' || options.trunkCache === undefined || cache === options.trunkCache
    || cache.numLayers !== 1 || cache.currentSeqLen !== context.currentSeqLen
    || !cache.layers?.[0] || cache.layers[0].seqLen !== context.currentSeqLen
    || !Number.isSafeInteger(context.currentSeqLen) || context.currentSeqLen < 0
    || !Number.isSafeInteger(options.numTokens) || options.numTokens < 1
    || context.currentSeqLen + options.numTokens > cache.maxSeqLen
    || options.phase !== context.phase
    || options.hiddenSize !== config.hiddenSize || options.layerIdx !== 0 || options.buffers !== null
    || (context.config.useMoE && context.runtimeMoERoutingConfig?.activeExpertSelection !== 'topk-route')) {
    throw new Error('[QwenNextn] A declared F32 auxiliary layer, private contiguous KV cache and matching cursor are required.');
  }
}

/** @param {import('../../../../gpu/command-recorder.js').CommandRecorder} recorder
 * @param {import('../../../../gpu/tensor.js').Tensor} input
 * @param {Parameters<import('./qwen-nextn-layer.js').recordQwenNextnLayer>[3]} prepared
 * @param {import('../types.js').LayerContext} context
 * @param {import('./qwen-nextn-layer.js').QwenNextnLayerOptions} options */
async function recordLayer(recorder, input, prepared, context, options) {
  const weights = new Map([['layer_0', prepared.layer]]);
  const execution = { ...context, weights, recorder, pipelinePlan: null, decodeBuffers: null };
  try {
    const output = await processLayerGPU(0, input.buffer, options.numTokens, options.phase === 'prefill',
      options.numTokens * options.hiddenSize, execution);
    if (output !== input.buffer) recorder.trackTemporaryBuffer(input.buffer);
    return output;
  } catch (error) {
    recorder.trackTemporaryBuffer(input.buffer);
    throw error;
  }
}

/** @type {typeof import('./qwen-nextn-layer.js').recordQwenNextnLayer} */
export async function recordQwenNextnLayer(recorder, embedding, hidden, prepared, context, options) {
  assertLayerContext(recorder, prepared, context, options);
  const input = await recordQwenNextnInput(recorder, embedding, hidden, prepared.input, options);
  return recordLayer(recorder, input, prepared, context, options);
}

/** @type {typeof import('./qwen-nextn-layer.js').recordQwenNextnLayerFromTokens} */
export async function recordQwenNextnLayerFromTokens(recorder, tokenIds, embeddingTable, hidden, prepared, context, options) {
  assertLayerContext(recorder, prepared, context, options);
  const input = await recordQwenNextnInputFromTokens(recorder, tokenIds, embeddingTable, hidden, prepared.input, options);
  return recordLayer(recorder, input, prepared, context, options);
}
