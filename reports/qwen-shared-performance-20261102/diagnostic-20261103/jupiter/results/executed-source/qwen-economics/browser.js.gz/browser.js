import { lookupDrafts } from '/pooled/room/lookup.js';
import { encodeSharedPrompt } from '../pooled-equal-weights/shared-input.js';

const config = await (await fetch('/probe-config.json')).json();
// Declared experiment switches (recorded in execution.json via the run config).
for (const [key, value] of Object.entries(config.pageGlobals ?? {})) globalThis[key] = value;
const shared = config.contract.shared;
// Harness-only WebGPU API observer (countGpuApi): counts calls and awaited wait time; no runtime change.
const gpuApi = { submit: 0, commandBuffers: 0, writeBuffer: 0, writeBufferBytes: 0, mapAsync: 0, mapAsyncWaitMs: 0,
  onSubmittedWorkDone: 0, onSubmittedWorkDoneWaitMs: 0, createBuffer: 0, destroyBuffer: 0, createBindGroup: 0,
  createComputePipeline: 0, createComputePipelineAsync: 0, createShaderModule: 0, createCommandEncoder: 0,
  beginComputePass: 0, dispatchWorkgroups: 0, dispatchWorkgroupsIndirect: 0, copyBufferToBuffer: 0, resolveQuerySet: 0 };
if (config.countGpuApi) {
  const wrap = (proto, name, key = name, timed = null) => {
    const original = proto[name];
    if (typeof original !== 'function') return;
    proto[name] = function (...args) {
      gpuApi[key]++;
      if (name === 'submit') gpuApi.commandBuffers += args[0]?.length ?? 0;
      if (name === 'writeBuffer') gpuApi.writeBufferBytes += (args[4] ?? args[2]?.byteLength ?? 0);
      const result = original.apply(this, args);
      if (timed) { const t0 = performance.now(); Promise.resolve(result).then(() => { gpuApi[timed] += performance.now() - t0; }, () => {}); }
      return result;
    };
  };
  wrap(GPUQueue.prototype, 'submit'); wrap(GPUQueue.prototype, 'writeBuffer');
  wrap(GPUQueue.prototype, 'onSubmittedWorkDone', 'onSubmittedWorkDone', 'onSubmittedWorkDoneWaitMs');
  wrap(GPUBuffer.prototype, 'mapAsync', 'mapAsync', 'mapAsyncWaitMs'); wrap(GPUBuffer.prototype, 'destroy', 'destroyBuffer');
  for (const n of ['createBuffer', 'createBindGroup', 'createComputePipeline', 'createComputePipelineAsync', 'createShaderModule', 'createCommandEncoder']) wrap(GPUDevice.prototype, n);
  wrap(GPUCommandEncoder.prototype, 'beginComputePass'); wrap(GPUCommandEncoder.prototype, 'copyBufferToBuffer'); wrap(GPUCommandEncoder.prototype, 'resolveQuerySet');
  wrap(GPUComputePassEncoder.prototype, 'dispatchWorkgroups'); wrap(GPUComputePassEncoder.prototype, 'dispatchWorkgroupsIndirect');
}
const snapApi = () => ({ t: performance.now(), ...gpuApi });
const gpuErrors = [];
let engine, pipeline, tokenizer, device, adapter, manifest, nativeOptions, expertReadiness = null;
// Common-weights diagnostic lane only (config.commonWeightsInventory): the builder's inventory of
// the tensors whose Pooled-prepared Q8 values both engines must hold; each engine's actual GPU
// bytes are read back and hashed against it.
const commonWeights = config.commonWeightsInventory ? { inventory: null, checks: [] } : null;
const sha256Hex = async (bytes) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
  .map((x) => x.toString(16).padStart(2, '0')).join('');
async function readGpuBytes(gpuDevice, buffer, offset, size) {
  const staging = gpuDevice.createBuffer({ size: Math.ceil(size / 4) * 4, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
  const encoder = gpuDevice.createCommandEncoder();
  encoder.copyBufferToBuffer(buffer, offset, staging, 0, Math.ceil(size / 4) * 4);
  gpuDevice.queue.submit([encoder.finish()]);
  await staging.mapAsync(GPUMapMode.READ);
  const bytes = new Uint8Array(staging.getMappedRange().slice(0, size));
  staging.unmap(); staging.destroy();
  return bytes;
}
if (commonWeights) commonWeights.inventory = await (await fetch(config.commonWeightsInventory)).json();
const startedLoad = performance.now();
try {
  if (config.kind === 'pooled') {
    const { Qwen35Engine, prefillMathFeatures } = await import('/pooled/engine/qwen35.js');
    const { roomQwen35Options, applyRoomFlags } = await import('/pooled/engine/preset.js');
    const { makeTokenizer } = await import('/pooled/engine/engine.js');
    const { parseGGUFHeader, qwen35Weights, tokenizerFromGGUF, streamEntryToGPU } = await import('/pooled/engine/gguf.js');
    const ad = await navigator.gpu.requestAdapter();
    device = await ad.requestDevice({ requiredFeatures: [...prefillMathFeatures(ad),
      ...(config.pooledKernelProfile && ad.features.has('timestamp-query') ? ['timestamp-query'] : [])],
      requiredLimits: { maxBufferSize: ad.limits.maxBufferSize,
        maxStorageBufferBindingSize: ad.limits.maxStorageBufferBindingSize } });
    adapter = { vendor: ad.info.vendor, architecture: ad.info.architecture,
      device: ad.info.device, description: ad.info.description };
    const readAt = async (offset, length) => {
      const response = await fetch('/model.gguf', { headers: { Range: `bytes=${offset}-${offset + length - 1}` } });
      if (response.status !== 206) throw new Error('GGUF reader requires exact partial responses');
      return new Uint8Array(await response.arrayBuffer());
    };
    const G = parseGGUFHeader((await readAt(0, 64 << 20)).buffer);
    const architecture = G.meta['general.architecture'];
    const layers = G.meta[architecture + '.block_count'] - (G.meta[architecture + '.nextn_predict_layers'] || 0);
    tokenizer = makeTokenizer(tokenizerFromGGUF(G.meta));
    const replacedByName = new Map((commonWeights?.inventory.replaced ?? []).map((entry) => [entry.name, entry]));
    G.streamEntry = async info => {
      const result = await streamEntryToGPU(device, info, value => fetch('/model.gguf', {
        headers: { Range: `bytes=${value.byteOffset}-${value.byteOffset + value.byteLength - 1}` },
      }));
      const expected = replacedByName.get(info.name);
      if (expected) {
        // Pooled's actual uploaded storage, read as soon as its loader returns it.
        const blocks = info.nElems / 32;
        const qs = await sha256Hex(await readGpuBytes(device, result.gpu.qs, 0, info.nElems));
        const sc = await sha256Hex(await readGpuBytes(device, result.gpu.sc, 0, blocks * 2));
        const check = { name: info.name, kind: result.gpu.kind, qs: `sha256:${qs}`, scales: `sha256:${sc}`,
          pass: result.gpu.kind === 'q8' && `sha256:${qs}` === expected.pooledQs && `sha256:${sc}` === expected.pooledScales };
        Object.defineProperty(check, 'buffers', { value: [result.gpu.qs, result.gpu.sc], enumerable: false });
        commonWeights.checks.push(check);
      }
      return result;
    };
    const weights = await qwen35Weights(G, value => readAt(value.byteOffset, value.byteLength),
      { lo: 0, hi: layers, hasEmbed: true, hasHead: true, mtp: config.pooledMtp ?? true });
    // Contract-declared Pooled overlay (e.g. attnFlash:false for native F32 KV); recorded in READY.
    nativeOptions = { ...roomQwen35Options(new URLSearchParams()), ...(config.pooledNativeOptions ?? {}) };
    engine = await Qwen35Engine.create({ device, meta: G.meta, weights, layerRange: [0, layers],
      hasEmbed: true, hasHead: true, maxSeq: shared.contextTokens,
      vocab: G.tensors['token_embd.weight'].shape[0], ...nativeOptions, adapterInfo: ad.info });
    applyRoomFlags(engine, new URLSearchParams());
    if (config.pooledSpec && (!engine.mtp || typeof engine.specStep !== 'function')) throw new Error('Requested native MTP speculation is unavailable');
    if (commonWeights) {
      // The checked upload buffers must be the ones the engine binds: every GPUBuffer reachable
      // from the created engine's object graph; one Pooled copied into a fused buffer and
      // dropped fails here instead of passing on its upload bytes.
      const reachable = new Set(), seen = new Set(), queue = [engine];
      while (queue.length) {
        const value = queue.pop();
        if (!value || typeof value !== 'object' || seen.has(value)) continue;
        seen.add(value);
        if (value instanceof GPUBuffer) { reachable.add(value); continue; }
        if (ArrayBuffer.isView(value) || value instanceof ArrayBuffer || value instanceof GPUDevice) continue;
        for (const item of value instanceof Map ? value.values() : Object.values(value)) queue.push(item);
      }
      for (const check of commonWeights.checks) {
        check.boundByEngine = check.buffers.every((buffer) => reachable.has(buffer));
      }
      // Pooled packs each shared expert's gate and up into one bound buffer (packGU:
      // [gate qs | up qs | gate scales | up scales]) and destroys the uploads; for those the
      // consumed bytes are read from the pack itself (no COPY_SRC: a compute copy reads it).
      const words = device.createShaderModule({ code: `
        @group(0) @binding(0) var<storage, read> src: array<u32>;
        @group(0) @binding(1) var<storage, read_write> dst: array<u32>;
        @group(0) @binding(2) var<uniform> span: vec4<u32>;
        @compute @workgroup_size(256) fn main(@builtin(global_invocation_id) id: vec3<u32>) {
          if (id.x < span.y) { dst[id.x] = src[span.x + id.x]; }
        }` });
      const copier = await device.createComputePipelineAsync({ layout: 'auto', compute: { module: words, entryPoint: 'main' } });
      const readStorage = async (buffer, offset, size) => {
        const out = device.createBuffer({ size: Math.ceil(size / 4) * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC });
        const span = device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        device.queue.writeBuffer(span, 0, new Uint32Array([offset / 4, Math.ceil(size / 4), 0, 0]));
        const encoder = device.createCommandEncoder(), pass = encoder.beginComputePass();
        pass.setPipeline(copier);
        pass.setBindGroup(0, device.createBindGroup({ layout: copier.getBindGroupLayout(0),
          entries: [buffer, out, span].map((b, binding) => ({ binding, resource: { buffer: b } })) }));
        pass.dispatchWorkgroups(Math.ceil(size / 4 / 256)); pass.end();
        device.queue.submit([encoder.finish()]);
        const bytes = await readGpuBytes(device, out, 0, size);
        out.destroy(); span.destroy();
        return bytes;
      };
      const byName = new Map(commonWeights.checks.map((check) => [check.name, check]));
      const expected = new Map(commonWeights.inventory.replaced.map((entry) => [entry.name, entry]));
      for (const [index, layer] of (engine.layers ?? []).entries()) {
        const gate = byName.get(`blk.${index}.ffn_gate_shexp.weight`), up = byName.get(`blk.${index}.ffn_up_shexp.weight`);
        const pack = layer?.shPack;
        if (!gate || !up || gate.boundByEngine || up.boundByEngine || !pack?.buf) continue;
        const qsBytes = (name) => G.tensors[name].nElems, scBytes = (name) => G.tensors[name].nElems / 32 * 2;
        const gName = gate.name, uName = up.name;
        const parts = [[gName, 'pooledQs', 0, qsBytes(gName)], [uName, 'pooledQs', pack.oUq * 4, qsBytes(uName)],
          [gName, 'pooledScales', pack.oGs * 4, scBytes(gName)], [uName, 'pooledScales', pack.oUs * 4, scBytes(uName)]];
        const matches = {};
        for (const [name, field, offset, size] of parts) {
          const hash = `sha256:${await sha256Hex(await readStorage(pack.buf, offset, size))}`;
          matches[name] = (matches[name] ?? true) && hash === expected.get(name)[field];
        }
        for (const check of [gate, up]) {
          check.boundVia = 'shPack';
          check.boundByEngine = reachable.has(pack.buf) && matches[check.name];
        }
      }
      for (const check of commonWeights.checks) check.pass = check.pass && check.boundByEngine;
    }
    manifest = { architecture, layers, metadata: G.meta,
      tensors: Object.fromEntries(Object.entries(G.tensors).map(([key, value]) =>
        [key, { shape: value.shape, ggmlType: value.ggmlType, byteLength: value.byteLength }])) };
  } else {
    const { initializeSuiteModel } = await import('/runtime/src/tooling/browser-harness/model-initialization.js');
    const { getDevice, getKernelCapabilities } = await import('/runtime/src/gpu/device.js');
    let runtimeConfig = config.runtimeConfigByKind?.[config.kind] ?? config.runtimeConfig;
    const profileId = config.runtimeProfileByKind?.[config.kind];
    if (profileId) {
      const { loadRuntimeProfile } = await import('/runtime/src/tooling/browser-harness/runtime-config.js');
      const { mergeRuntimeValues } = await import('/runtime/src/config/runtime-merge.js');
      const loaded = await loadRuntimeProfile(profileId, { baseUrl: new URL('/runtime/src/config/runtime', location.href).href });
      runtimeConfig = mergeRuntimeValues(loaded.runtime, runtimeConfig);
      nativeOptions = { profileId, profile: loaded.config, runtimeConfig };
    }
    const harness = await initializeSuiteModel({ modelId: config.modelId,
      modelUrl: new URL('/rdrr', location.href).href, loadMode: 'http',
      runtime: { runtimeConfig } });
    pipeline = harness.pipeline;
    if (config.dopplerExpertReadiness) {
      // Explicit expert readiness: make every layer's routed-expert bank resident before READY,
      // so load time is comparable with an engine that uploads every tensor up front.
      const state = pipeline.generator._state, layers = state.modelConfig.numLayers, started = performance.now();
      for (let layer = 0; layer < layers; layer++) {
        const bank = await state.dopplerLoader.loadExpert(layer, 0);
        if (!bank) throw new Error('Expert readiness could not load layer ' + layer);
      }
      expertReadiness = { layers, ms: performance.now() - started };
    }
    tokenizer = pipeline.tokenizer;
    device = getDevice();
    if (commonWeights) {
      // Doppler's actual GPU storage for each replaced tensor (Q8_0 blocks as built).
      const state = pipeline.generator._state;
      const sharedSlots = { ffn_gate_shexp: 'sharedExpertGate', ffn_up_shexp: 'sharedExpertUp', ffn_down_shexp: 'sharedExpertDown' };
      for (const expected of commonWeights.inventory.replaced) {
        let value;
        const layer = expected.name.match(/^blk\.(\d+)\.(.+)\.weight$/);
        if (expected.name === 'output.weight') value = state.weights.get('lm_head');
        else if (layer && layer[2] === 'attn_q') value = state.weights.get(`layer_${layer[1]}`)?.qProj;
        else if (layer && sharedSlots[layer[2]]) value = state.weights.get(`layer_${layer[1]}`)?.[sharedSlots[layer[2]]];
        else if (layer && layer[2] === 'ffn_down_exps') value = (await state.dopplerLoader.loadExpert(+layer[1], 0))?.down;
        const buffer = value?.buffer ?? value;
        if (!buffer?.size || buffer.size < expected.bytes) {
          commonWeights.checks.push({ name: expected.name, pass: false, reason: 'no resident GPU buffer of the expected extent' });
          continue;
        }
        const actual = `sha256:${await sha256Hex(await readGpuBytes(device, buffer, 0, expected.bytes))}`;
        commonWeights.checks.push({ name: expected.name, dtype: value?.dtype ?? null, label: buffer.label ?? null, actual, pass: actual === expected.q8_0 });
      }
    }
    adapter = getKernelCapabilities().adapterInfo;
    manifest = harness.manifest;
  }
  device.addEventListener('uncapturederror', event => gpuErrors.push(event.error.message));
  if (String(adapter.vendor).toLowerCase() !== shared.requiredVendor) throw new Error('Unexpected physical GPU vendor');
  await device.queue.onSubmittedWorkDone();
  const observedWeights = {};
  const weightLayers = pipeline ? config.recordWeightLayers ?? [] : [];
  for (const layer of weightLayers) {
    observedWeights[layer] = Object.fromEntries(Object.entries(pipeline.weights.get(`layer_${layer}`)).map(([key, value]) => [key, value ? { dtype: value.dtype ?? null, shape: value.shape ?? null, type: value.constructor?.name, materializations: Object.keys(value.materializations ?? {}) } : null]));
  }
  if (commonWeights) {
    const expected = commonWeights.inventory.replaced.length;
    commonWeights.summary = { expected, checked: commonWeights.checks.length, passed: commonWeights.checks.filter((c) => c.pass).length };
    if (commonWeights.summary.passed !== expected) {
      const failed = commonWeights.checks.filter((check) => !check.pass).map((check) => `${check.name}${check.boundByEngine === false ? ' (not bound)' : ''}`);
      throw new Error(`Common-weights materialization check failed: ${JSON.stringify(commonWeights.summary)} ${failed.slice(0, 12).join(', ')}`);
    }
  }
  globalThis.READY = { observedWeights, kind: config.kind, loadMs: performance.now() - startedLoad, expertReadiness, commonWeights,
    adapter, features: [...device.features], manifest, nativeOptions,
    executedOptions: engine ? Object.fromEntries([
      'moeFuse', 'moeNormRouter', 'moeGroupPrefill', 'moeGroupDp4a', 'prefillDp4a',
      'prefillMath', 'fuseProj', 'hostFuse', 'layerFuse', 'gpuSample', 'argmaxWide',
      'dnNormBA', 'attnDecode', 'attnFlash', 'prefillUbatch', 'mtpBatchFill', 'mtpBatchRefill', 'mtpPreDraft',
    ].map(key => [key, engine[key] ?? null])) : null,
    resolvedRuntime: pipeline?.runtimeConfig ?? null,
    speculation: engine ? { requested: config.pooledSpec ?? null, mtpAvailable: Boolean(engine.mtp), mtpFill: engine.mtpFill ?? null } : null,
    userAgent: navigator.userAgent, power: null };
  const sessionConfig = config;
  // Numerical probe (diagnostic only, config.layerProbe): one identical token at position 0
  // from a reset state; the residual stream after every layer and the logits, per engine.
  globalThis.LAYER_PROBE = async () => {
    const { tokenId, layers: count } = config.layerProbe;
    if (engine) {
      const { captureSingleTokenLayers } = await import('/runtime/tools/pooled-equal-weights/capture-pooled-boundaries.js');
      const result = await captureSingleTokenLayers(engine, tokenId);
      engine.reset();
      return { kind: 'pooled', tokenId, position: 0, logits: result.logits, layers: result.layers, scope: result.scope };
    }
    const targetOpIds = Array.from({ length: count }, (_, layer) => `layer.${layer}.layer.out`);
    pipeline.reset();
    pipeline.beginDiagnosticSequence({ captureConfig: { defaultLevel: 'none', targetOpIds, targetLevel: 'full' } });
    let prefill, sequence;
    try {
      prefill = await pipeline.prefillWithLogits('', { inputIds: [tokenId, ...(config.layerProbe.extraIds ?? [])], useChatTemplate: false });
    } finally {
      sequence = pipeline.endDiagnosticSequence();
    }
    pipeline.reset();
    const layers = sequence.timeline.filter((record) => record.stageName === 'layer.out' && record.capture?.data)
      .map((record) => ({ layer: record.layerIndex, values: Array.from(record.capture.data).slice(0, 2048 * (1 + (config.layerProbe.extraIds?.length ?? 0))), phase: record.phase, sequenceStep: record.sequenceStep }));
    return { kind: 'doppler', tokenId, extraIds: config.layerProbe.extraIds ?? [], position: 0, logits: Array.from(prefill.logits), layers, recordCount: sequence.recordCount,
      scope: 'Doppler prefillWithLogits of one token at position 0 inside one diagnostic sequence; layer.out captured in full' };
  };
  // Numerical probe (diagnostic only, config.prefixProbe): prefill a frozen prompt, then one
  // forced decode step with a given token; the residual stream after every layer at that
  // step (generated index forcedIndex + 1 is predicted) and the prefill and step logits.
  globalThis.PREFIX_PROBE = async (probe) => {
    const { promptIds, forcedTokenId, layers: count } = probe;
    if (engine) {
      engine.reset();
      await engine.prefillTokens(promptIds.slice(0, -1));
      const prefillLogits = Array.from(await engine.forwardToken(promptIds.at(-1)));
      const original = engine._encodeLayerR, copies = [], fuse = engine.layerFuse.pass, ahead = engine.encodeAhead;
      engine.layerFuse.pass = false; engine.encodeAhead = false; engine._fwdPre = null;
      engine._encodeLayerR = function (encoder, layer, position) {
        original.call(this, encoder, layer, position);
        const buffer = device.createBuffer({ size: this.dims.dim * 4, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
        encoder.copyBufferToBuffer(this.x, 0, buffer, 0, this.dims.dim * 4);
        copies.push({ layer: this.layers.indexOf(layer), position, buffer });
      };
      let stepLogits;
      try {
        stepLogits = Array.from(await engine.forwardToken(forcedTokenId));
      } finally {
        engine._encodeLayerR = original; engine.layerFuse.pass = fuse; engine.encodeAhead = ahead; engine._fwdPre = null;
      }
      const layers = [];
      for (const { layer, position, buffer } of copies) {
        await buffer.mapAsync(GPUMapMode.READ);
        layers.push({ layer, position, values: Array.from(new Float32Array(buffer.getMappedRange())) });
        buffer.unmap(); buffer.destroy();
      }
      engine.reset();
      return { kind: 'pooled', promptLength: promptIds.length, forcedTokenId, stepPosition: promptIds.length,
        prefillLogits, stepLogits, layers };
    }
    pipeline.reset();
    const prefill = await pipeline.prefillWithLogits('', { inputIds: promptIds, useChatTemplate: false });
    const targetOpIds = Array.from({ length: count }, (_, layer) => `layer.${layer}.layer.out`);
    pipeline.beginDiagnosticSequence({ captureConfig: { defaultLevel: 'none', targetOpIds, targetLevel: 'full' } });
    let step, sequence;
    try {
      step = await pipeline.decodeStepLogits([...promptIds, forcedTokenId], {});
    } finally {
      sequence = pipeline.endDiagnosticSequence();
    }
    pipeline.reset();
    const layers = sequence.timeline.filter((record) => record.stageName === 'layer.out' && record.capture?.data)
      .map((record) => ({ layer: record.layerIndex, position: record.tokenIndex, values: record.capture.data }));
    return { kind: 'doppler', promptLength: promptIds.length, forcedTokenId, stepPosition: promptIds.length,
      prefillLogits: Array.from(prefill.logits), stepLogits: Array.from(step.logits), layers };
  };
  // Routing probe (diagnostic only, config.routeProbes): prefill a frozen prompt as PREFIX_PROBE does
  // (Pooled: prefillTokens of all but the last token, then forwardToken of the last) and copy each MoE
  // layer's router logits for every prompt position out of the engine's own buffers, right after the
  // router ran (same kernels, same order: only extra copies). Per layer and position: the top routeTopN
  // routed experts by logit (Pooled's shared-gate row nExp excluded) and their logits.
  globalThis.ROUTE_PROBE = async (probe) => {
    const { promptIds } = probe, topN = probe.topN ?? 10, captures = [];
    const COPY = GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ;
    const copyOut = (enc, src, offset, bytes) => {
      const buffer = device.createBuffer({ size: bytes, usage: COPY });
      enc.copyBufferToBuffer(src, offset, buffer, 0, bytes);
      return buffer;
    };
    let nExp;
    if (engine) {
      const E = engine, origW = E._encodeLayerWide, origB = E._encodeLayerBatch, origR = E._encodeLayerR;
      const fuse = E.layerFuse.pass, ahead = E.encodeAhead;
      nExp = E.moe.nExp;
      E.reset();
      E.layerFuse.pass = false; E.encodeAhead = false; E._fwdPre = null;
      E._encodeLayerWide = function (enc, i, basePos, w) {
        origW.call(this, enc, i, basePos, w);
        const L = this.layers[i];
        if (!L.moe) return;
        if (!(this._wideGrp(L, w) && this.layerW[i].nrtW && this.wideRouter !== false)) throw new Error('route probe: wide MoE layer without the whole-chunk router');
        const stride = this.B.mLogits.stride;
        captures.push({ layer: i, pos0: basePos, n: w, stride: stride / 4, buffer: copyOut(enc, this.gB.LG, 0, w * stride) });
      };
      E._encodeLayerBatch = function (enc, i, basePos, nCols = this.NC, snapshotDN = false, routeOnly = false) {
        const result = origB.call(this, enc, i, basePos, nCols, snapshotDN, routeOnly);
        if (i < this.layers.length && this.layers[i].moe) {
          const M = this.B.mLogits;
          captures.push({ layer: i, pos0: basePos, n: nCols, stride: M.stride / 4, buffer: copyOut(enc, M.buf, M.off || 0, nCols * M.stride) });
        }
        return result;
      };
      E._encodeLayerR = function (enc, L, pos) {
        origR.call(this, enc, L, pos);
        if (L.moe) captures.push({ layer: this.layers.indexOf(L), pos0: pos, n: 1, stride: nExp + 1, buffer: copyOut(enc, this.moeB.logits, 0, (nExp + 1) * 4) });
      };
      try {
        await E.prefillTokens(promptIds.slice(0, -1));
        await E.forwardToken(promptIds.at(-1));
      } finally {
        E._encodeLayerWide = origW; E._encodeLayerBatch = origB; E._encodeLayerR = origR;
        E.layerFuse.pass = fuse; E.encodeAhead = ahead; E._fwdPre = null;
      }
    } else {
      const { MoERouter } = await import('/runtime/src/inference/moe-router.js');
      const orig = MoERouter.prototype.computeRouterLogitsGPU, next = new Map();
      MoERouter.prototype.computeRouterLogitsGPU = async function (hidden, numTokens, gpuContext = null, options = {}) {
        const out = await orig.call(this, hidden, numTokens, gpuContext, options);
        if (this.lastLogitsDtype !== 'f32') throw new Error(`route probe: router logits are ${this.lastLogitsDtype}, not f32`);
        nExp = this.numExperts;
        const layer = options.layerIdx, pos0 = next.get(layer) ?? 0, bytes = numTokens * nExp * 4;
        next.set(layer, pos0 + numTokens);
        let buffer;
        if (options.recorder) buffer = copyOut(options.recorder.getEncoder(), out, 0, bytes);
        else { const enc = device.createCommandEncoder(); buffer = copyOut(enc, out, 0, bytes); device.queue.submit([enc.finish()]); }
        captures.push({ layer, pos0, n: numTokens, stride: nExp, buffer });
        return out;
      };
      pipeline.reset();
      try {
        await pipeline.prefillWithLogits('', { inputIds: promptIds, useChatTemplate: false });
      } finally {
        MoERouter.prototype.computeRouterLogitsGPU = orig;
      }
    }
    await device.queue.onSubmittedWorkDone();
    const T = promptIds.length, layers = [...new Set(captures.map((c) => c.layer))].sort((a, b) => a - b);
    const ids = new Int32Array(layers.length * T * topN).fill(-1), vals = new Float32Array(layers.length * T * topN);
    const seen = new Uint8Array(layers.length * T);
    let duplicates = 0;
    for (const { layer, pos0, n, stride, buffer } of captures) {
      await buffer.mapAsync(GPUMapMode.READ);
      const data = new Float32Array(buffer.getMappedRange());
      const li = layers.indexOf(layer);
      for (let c = 0; c < n; c++) {
        const pos = pos0 + c, row = c * stride, at = (li * T + pos) * topN;
        if (pos >= T) throw new Error(`route probe: layer ${layer} position ${pos} beyond the prompt`);
        if (seen[li * T + pos]++) duplicates++;
        const topI = [], topV = [];
        for (let e = 0; e < nExp; e++) {
          const v = data[row + e];
          if (topV.length === topN && !(v > topV[topN - 1])) continue;
          let k = topV.length === topN ? topN - 1 : topV.length;
          while (k > 0 && v > topV[k - 1]) { topV[k] = topV[k - 1]; topI[k] = topI[k - 1]; k--; }
          topV[k] = v; topI[k] = e;
        }
        ids.set(topI, at); vals.set(topV, at);
      }
      buffer.unmap(); buffer.destroy();
    }
    const missing = seen.reduce((sum, x) => sum + (x === 0 ? 1 : 0), 0);
    if (engine) engine.reset(); else pipeline.reset();
    if (missing) throw new Error(`route probe: ${missing} (layer, position) rows not captured`);
    const b64 = (array) => { const u8 = new Uint8Array(array.buffer); let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000)); return btoa(s); };
    return { kind: engine ? 'pooled' : 'doppler', promptLength: T, nExp, topN, layers, duplicates, captures: captures.length,
      ids: b64(ids), logits: b64(vals) };
  };
  globalThis.REQUEST = async (task, phase = 'workload') => {
    if (!['workload', 'reference-probe'].includes(phase)) throw new Error('Unknown frozen request phase');
    if (phase === 'reference-probe' && (!sessionConfig.referenceProbe || engine)) throw new Error('Reference probe requires its explicit Doppler protocol');
    const config = phase === 'reference-probe'
      ? { ...sessionConfig, ...sessionConfig.referenceProbe.observation } : sessionConfig;
    const shared = phase === 'reference-probe' ? sessionConfig.referenceProbe.contract.shared : sessionConfig.contract.shared;
    if (gpuErrors.length) throw new Error('Prior GPU errors: ' + gpuErrors.join(';'));
    if (engine) engine.reset(); else pipeline.reset();
    if (engine?.mtp) engine.mtpFill = Boolean(config.pooledSpec);
    await device.queue.onSubmittedWorkDone();
    const text = task.text + (task.repeat ? task.repeat.repeat(task.repeatCount) : '');
    const rendered = shared.promptFormat.before + text + shared.promptFormat.after;
    const promptIds = engine ? encodeSharedPrompt(tokenizer, text, shared.promptFormat)
      : Array.from(tokenizer.encode(rendered));
    if (promptIds.length + shared.maxNewTokens > shared.contextTokens) throw new Error('Request exceeds frozen context budget');
    const tokenIds = [], deliveryMs = [], chunks = [], textDeliveryMs = [], logits = [];
    let logitIndex = 0;
    const prefixRecords = [], prefixAbort = config.prefixDiagnostic ? new AbortController() : null;
    let prefixReached = false, restoreObserver = null;
    if (config.prefixDiagnostic) {
      const { OperatorEventEmitter } = await import('/runtime/src/inference/pipelines/text/operator-events.js');
      const original = OperatorEventEmitter.prototype.emitRecord;
      OperatorEventEmitter.prototype.emitRecord = function(stage, options) {
        const record = original.call(this, stage, options);
        prefixRecords.push(record);
        if (stage === config.prefixDiagnostic.stopStage && options.layerIdx === config.prefixDiagnostic.layer) {
          prefixReached = true; prefixAbort.abort();
        }
        return record;
      };
      restoreObserver = () => { OperatorEventEmitter.prototype.emitRecord = original; };
    }
    const apiSnapshots = config.countGpuApi ? [snapApi()] : null;
    const begin = performance.now();
    let prefillMs = null, firstTokenMs = null, stats = null;
    try {
      if (engine) {
        // Harness-only Pooled prefill kernel profile (its own tests/prof/gpuprof.js, kernel mode: every
        // dispatch in its own timestamped pass). Profiled repeats only; never a timing receipt.
        let prof = null;
        if (task.profile && config.pooledKernelProfile) {
          if (!globalThis.__pooledProf) {
            const P = (await import('/pooled/tests/prof/gpuprof.js')).installProf(device, engine,
              { mode: 'kernel', maxQ: config.pooledKernelProfile.maxQueries ?? 400000 });
            // gpuprof's kernel-mode pass wrapper has no dispatchWorkgroupsIndirect (the grouped MoE expert
            // launches use it): time those here, each in its own timestamped pass.
            const ind = { qs: device.createQuerySet({ type: 'timestamp', count: 4096 }), n: 0, recs: [] };
            const pooledCreate = device.createCommandEncoder;
            device.createCommandEncoder = (d) => {
              const enc = pooledCreate(d);
              if (!P.on) return enc;
              const fakeBegin = enc.beginComputePass;
              enc.beginComputePass = (desc) => {
                const fake = fakeBegin(desc);
                if (fake.dispatchWorkgroupsIndirect) return fake;
                let pipe = null; const groups = {};
                const setPipeline = fake.setPipeline.bind(fake), setBindGroup = fake.setBindGroup.bind(fake);
                fake.setPipeline = (value) => { pipe = value; setPipeline(value); };
                fake.setBindGroup = (index, group) => { groups[index] = group; setBindGroup(index, group); };
                fake.dispatchWorkgroupsIndirect = (buffer, offset) => {
                  if (ind.n + 2 > 4096) throw new Error('indirect profile query budget exceeded');
                  const q = ind.n; ind.n += 2; ind.recs.push({ q, pipe });
                  const pass = GPUCommandEncoder.prototype.beginComputePass.call(enc,
                    { timestampWrites: { querySet: ind.qs, beginningOfPassWriteIndex: q, endOfPassWriteIndex: q + 1 } });
                  pass.setPipeline(pipe); for (const k in groups) pass.setBindGroup(+k, groups[k]);
                  pass.dispatchWorkgroupsIndirect(buffer, offset); pass.end();
                };
                return fake;
              };
              return enc;
            };
            P.indirect = ind;
            globalThis.__pooledProf = P;
          }
          prof = globalThis.__pooledProf; prof.indirect.n = 0; prof.indirect.recs = []; prof.start();
        }
        await engine.prefillTokens(promptIds.slice(0, -1));
        prefillMs = performance.now() - begin;
        if (prof) {
          prof.stop(); await prof.resolve();
          const byPipe = {}, byCat = {};
          for (const sub of prof.subs) for (const k of sub.kern) {
            (byPipe[k.name] ||= { n: 0, ms: 0 }); byPipe[k.name].n++; byPipe[k.name].ms += k.ms ?? 0;
            (byCat[k.cat] ||= { n: 0, ms: 0 }); byCat[k.cat].n++; byCat[k.cat].ms += k.ms ?? 0;
          }
          const ind = prof.indirect;
          if (ind.n) {
            const resolve = device.createBuffer({ size: ind.n * 8, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC });
            const read = device.createBuffer({ size: ind.n * 8, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
            const enc = GPUDevice.prototype.createCommandEncoder.call(device);
            enc.resolveQuerySet(ind.qs, 0, ind.n, resolve, 0); enc.copyBufferToBuffer(resolve, 0, read, 0, ind.n * 8);
            device.queue.submit([enc.finish()]); await read.mapAsync(GPUMapMode.READ);
            const ts = new BigUint64Array(read.getMappedRange().slice(0)); read.unmap();
            const names = new Map(Object.entries(engine.pipes).map(([key, value]) => [value, key]));
            for (const r of ind.recs) {
              const name = (names.get(r.pipe) ?? '?') + ' (indirect)', ms = ts[r.q + 1] > ts[r.q] ? Number(ts[r.q + 1] - ts[r.q]) / 1e6 : 0;
              (byPipe[name] ||= { n: 0, ms: 0 }); byPipe[name].n++; byPipe[name].ms += ms;
              (byCat['MoE experts (indirect)'] ||= { n: 0, ms: 0 }); byCat['MoE experts (indirect)'].n++; byCat['MoE experts (indirect)'].ms += ms;
            }
          }
          stats = { pooledPrefillProfile: { overflow: prof.overflow, queries: prof.nq, indirectQueries: ind.n, byPipe, byCat } };
        }
        if (config.pooledSpec) {
          if (config.captureLogitPositions || shared.sampling.temperature !== 0 || shared.sampling.topK !== 1
              || shared.sampling.repetitionPenalty !== 1) throw new Error('Native MTP diagnostic requires unchanged greedy sampling');
          const { pickSampler } = await import('/pooled/room/sampling.js');
          const sample = pickSampler('exact'), depth = config.pooledSpec.depth;
          if (![3,5,7].includes(depth)) throw new Error('Declared MTP depth must be 3, 5 or 7');
          const before = { ...engine.mtp.stats }, steps = [];
          let next = (await engine.forwardTokenIds(promptIds.at(-1))).ids[0], previousText = '';
          const emit = token => {
            if (!Number.isSafeInteger(token) || token < 0) throw new Error('Invalid speculative token');
            tokenIds.push(token); deliveryMs.push(performance.now() - begin); firstTokenMs ??= deliveryMs.at(-1);
            if (!shared.eosTokenIds.includes(token)) {
              const nextText = tokenizer.decode(tokenIds), chunk = nextText.slice(previousText.length);
              if (chunk) { chunks.push(chunk); textDeliveryMs.push(performance.now() - begin); }
              previousText = nextText;
            }
          };
          const fed = [...promptIds]; let lookupFull = false;
          if ((task.pooledLookup ?? config.pooledSpec.lookup) && !engine.specStepDrafts) throw new Error('Native prompt lookup unavailable');
          emit(next);
          while (!shared.eosTokenIds.includes(tokenIds.at(-1)) && tokenIds.length < shared.maxNewTokens) {
            const room = shared.contextTokens - engine.pos - 2;
            if (room < 1) throw new Error('Speculative request exceeds frozen context budget');
            const K = Math.min(depth, room, shared.maxNewTokens - tokenIds.length), started = performance.now();
            const lookupMax = lookupFull ? (engine.maxDrafts || 7) : 7;
            const drafts = (task.pooledLookup ?? config.pooledSpec.lookup) ? lookupDrafts([...fed, next], Math.min(lookupMax, room, shared.maxNewTokens - tokenIds.length)) : [];
            const viaLookup = drafts.length >= 2;
            const values = viaLookup ? await engine.specStepDrafts(next, sample, drafts) : await engine.specStep(next, sample, K);
            lookupFull = viaLookup && values.length === drafts.length + 1;
            fed.push(next, ...values.slice(0, -1));
            if (!values.length) throw new Error('Speculative step returned no tokens');
            steps.push({ K, viaLookup, lookupDrafts: drafts.length, returned: values.length, ms: performance.now() - started, pos: engine.pos });
            for (const token of values) {
              if (tokenIds.length >= shared.maxNewTokens || shared.eosTokenIds.includes(tokenIds.at(-1))) break;
              emit(token);
            }
            next = values.at(-1);
          }
          stats = { nativeSpeculation: { depth, lookup: Boolean((task.pooledLookup ?? config.pooledSpec.lookup)), before, after: { ...engine.mtp.stats }, steps,
            semantics: 'Native room-style greedy MTP, final returned lookahead may remain pending at the output cap; all GPU completion is timed.' } };
        } else {
        let input = promptIds.at(-1), previousText = '';
        for (let index = 0; index < shared.maxNewTokens; index++) {
          // Logit diagnostics read the full head through forwardToken (no decode-ahead) and
          // take the greedy token on the CPU (first maximum: ties to the lower index).
          let token;
          if (config.captureLogitPositions) {
            const values = await engine.forwardToken(input);
            let best = 0;
            for (let v = 1; v < values.length; v++) if (values[v] > values[best]) best = v;
            token = best;
            if (config.captureLogitPositions.includes(logitIndex)) logits.push({ index: logitIndex, values: Array.from(values) });
            logitIndex++;
          } else token = (await engine.forwardTokenIds(input)).ids[0];
          tokenIds.push(token); deliveryMs.push(performance.now() - begin);
          firstTokenMs ??= deliveryMs.at(-1);
          if (shared.eosTokenIds.includes(token)) break;
          // Deliberate application-visible text delivery; record this overhead.
          const nextText = tokenizer.decode(tokenIds);
          const chunk = nextText.slice(previousText.length);
          if (chunk) { chunks.push(chunk); textDeliveryMs.push(performance.now() - begin); }
          previousText = nextText; input = token;
        }
        }
      } else {
        for await (const chunk of pipeline.generate(rendered, { inputIds: promptIds,
          maxTokens: shared.maxNewTokens, ...shared.sampling,
          ...(config.prefixDiagnostic ? { signal: prefixAbort.signal, diagnostics: {
            enabled: true, captureConfig: config.prefixDiagnostic.captureConfig,
          } } : {}),
          onToken(id) { tokenIds.push(id); deliveryMs.push(performance.now() - begin); if (config.countGpuApi) apiSnapshots.push(snapApi()); },
          ...((task.profile ?? config.profileGeneration) ? { profile: true, executionObserver: true } : {}),
          ...(config.captureLogitPositions ? { onLogits(values) {
            if (config.captureLogitPositions.includes(logitIndex)) logits.push({ index: logitIndex, values: Array.from(values) });
            logitIndex++;
          } } : {}),
        })) { chunks.push(chunk); textDeliveryMs.push(performance.now() - begin); }
        stats = pipeline.getStats();
        prefillMs = stats.prefillTimeMs ?? null;
        firstTokenMs = deliveryMs[0] ?? null;
      }
      await device.queue.onSubmittedWorkDone();
      const referenceStates = [];
      if (config.referenceStateLayers) {
        const decodeSteps = config.referenceDecodeSteps ?? 0;
        if (![0, 1].includes(decodeSteps) || !config.captureLogitPositions
            || shared.maxNewTokens !== 1 + decodeSteps || tokenIds.length !== 1 + decodeSteps || !pipeline) {
          throw new Error('State observation requires an explicit zero/one cached-step Doppler diagnostic with an exact output budget');
        }
        const { readbackBuffer } = await import('/runtime/src/gpu/readback-buffer.js');
        for (const layer of config.referenceStateLayers) {
          const state = pipeline.linearAttentionRuntime.layers.get(layer);
          if (!state || state.recurrentStateComponents !== 1 || state.convStateComponents !== 1) {
            throw new Error('Reference observation requires declared scalar recurrent and convolution state');
          }
          for (const field of ['recurrentState', 'convState']) {
            const bytes = await readbackBuffer(device, state[field + 'GPU'], state[field].byteLength);
            referenceStates.push({ layer, field, seqLen: state.seqLen,
              numKHeads: state.numKHeads, numVHeads: state.numVHeads,
              headKDim: state.headKDim, headVDim: state.headVDim,
              convDim: state.convDim, convKernelSize: state.convKernelSize,
              values: Array.from(new Float32Array(bytes)) });
          }
        }
      }
      const completeMs = performance.now() - begin;
      const output = chunks.join('');
      return { task: task.id, promptIds, tokenIds, deliveryMs, chunks, textDeliveryMs,
        firstTokenMs, firstTextMs: textDeliveryMs[0] ?? null, prefillMs, completeMs,
        text: output, qualityPass: task.expected === undefined ? null : output.trim() === task.expected,
        stopReason: shared.eosTokenIds.includes(tokenIds.at(-1)) ? 'eos' : 'max-tokens',
        apiSnapshots, apiFinal: config.countGpuApi ? snapApi() : null,
        profiled: Boolean(task.profile ?? config.profileGeneration),
        stats, memory: pipeline?.getMemoryStats?.() ?? engine?.memory?.() ?? null, gpuErrors: [...gpuErrors],
        ...(config.captureLogitPositions ? { diagnosticOnly: true, logits, referenceStates } : {}) };
    } catch (error) {
      return { task: task.id, error: String(error.stack || error), promptIds, tokenIds, deliveryMs,
        chunks, textDeliveryMs, elapsedMs: performance.now() - begin, gpuErrors: [...gpuErrors],
        ...(config.prefixDiagnostic ? { prefixDiagnostic: { reached: prefixReached, records: prefixRecords } } : {}) }; 
    } finally { restoreObserver?.(); }
  };
  globalThis.CLOSE = async () => {
    await device.queue.onSubmittedWorkDone();
    if (pipeline) await pipeline.unload(); else engine.destroy?.();
    device.destroy();
  };
} catch (error) {
  globalThis.READY = { error: String(error.stack || error), elapsedMs: performance.now() - startedLoad };
}
