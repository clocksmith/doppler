import pathlib,json,subprocess
root=pathlib.Path.cwd();out=root/'reports/qwen-competition-20261017'
for size in ['08','2b']:
 for lane in ['baseline','candidate']:
  c=json.loads((out/f'tile-{size}-{lane}-config.json').read_text());c['request']['inferenceInput']['maxTokens']=1
  run=c['request']['runtimeConfig']['shared']['benchmark']['run'];run['maxNewTokens']=1;run['warmupRuns']=2;run['timedRuns']=10;run.pop('executionObserver',None)
  (out/f'prefill-{size}-{lane}-config.json').write_text(json.dumps(c,indent=2)+'\n')
 for index,lane in enumerate(['baseline','candidate','candidate','baseline']):
  tree='.tmp/qwen-final-20261017' if lane=='baseline' else '.tmp/qwen-tile-20261017'
  argv=['node',tree+'/src/cli/doppler-cli.js','bench','--surface','browser','--config',str(out/f'prefill-{size}-{lane}-config.json'),'--json']
  p=out/f'prefill-{size}-{index}-{lane}.log'
  with p.open('w') as log:subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=180,check=True)
  s=p.read_text();d=json.loads(s[s.index('{'):]);m=d['result']['metrics'];assert m['avgTokensGenerated']==1
  print(json.dumps({'size':size,'index':index,'lane':lane,'ttftMs':m['firstTokenMs'],'prefillMs':m['prefillMs'],'promptTokens':m['avgPrefillTokens']}),flush=True)
