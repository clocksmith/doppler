import os
os.environ['HF_HUB_OFFLINE']='1'
import json,pathlib,sys,time,resource,platform,importlib.metadata,statistics
import mlx.core as mx
from mlx_lm import load
from mlx_lm.generate import generate_step
root=pathlib.Path.cwd();size=sys.argv[1];out=root/'reports/qwen-competition-20261017'
reference=json.loads(next((out/'compare-metal-08').glob('*.json')).read_text())
prompt=reference['prompt'];model_path=root/f'.cache/qwen-comparators-20261017/mlx-{size}'
report={'schema':'qwen-native-comparison/v1','engine':'mlx-lm','model':str(model_path),'provenance':json.loads((model_path/'download-provenance.json').read_text())['sha'],'versions':{p:importlib.metadata.version(p) for p in ['mlx','mlx-lm']},'platform':platform.platform(),'prompt':prompt,'maxTokens':128,'sampling':'greedy','chatTemplate':False,'loadScope':'fresh process; local files; OS page cache uncontrolled','runs':[],'timingScope':'first/last delivered token; generator drain separately; upstream one-token lookahead retained'}
start=time.perf_counter();model,tokenizer=load(str(model_path));mx.eval(model.parameters());mx.synchronize();report['loadMs']=(time.perf_counter()-start)*1000
ids=tokenizer.encode(prompt,add_special_tokens=False);assert len(ids)==64,len(ids);report['promptTokenIds']=ids
try:
 for index in range(4):
  mx.reset_peak_memory();tokens=[];times=[];start=time.perf_counter()
  iterator=generate_step(mx.array(ids),model,max_tokens=128)
  for token,logprobs in iterator:
   tokens.append(int(token));times.append((time.perf_counter()-start)*1000)
  mx.synchronize();finished=(time.perf_counter()-start)*1000
  assert len(tokens)==128
  row={'index':index,'phase':'first-request' if index==0 else 'warm','tokenIds':tokens,'tokenTimesMs':times,'ttftMs':times[0],'decodeMs':times[-1]-times[0],'decodeTokens':len(tokens)-1,'decodeTokensPerSec':127000/(times[-1]-times[0]),'drainMs':finished-times[-1],'totalMs':finished,'peakMlxBytes':mx.get_peak_memory(),'processPeakRssBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'text':tokenizer.decode(tokens)}
  report['runs'].append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['tokenIds','tokenTimesMs','text']}),flush=True)
finally:
 (out/f'mlx-metal-{size}.json').write_text(json.dumps(report,indent=2)+'\n')
