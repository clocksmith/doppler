import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { probeNodeGPU } from '../tests/helpers/gpu-probe.js';
import { getDevice, destroyDevice } from '../src/gpu/device.js';
import { getMatmulConfig } from '../src/gpu/kernels/matmul-selection.js';
import { calculateMatmulDispatch } from '../src/gpu/kernels/matmul-dispatch.js';
const probe = await probeNodeGPU(); assert(probe.ready, probe.reason);
const device = getDevice(); assert(device.features.has('timestamp-query'));
const source = await fs.readFile('src/gpu/kernels/fused_matmul_q4_widetile.wgsl','utf8');
const hash = x => createHash('sha256').update(x).digest('hex');
const report = { provider: probe.providerReceipt, shaderSha256: hash(source), warmups: 3, pairs: 12, dispatches: 8, rows: [], passed: false };
const owned=[];const buffer=(size,usage,data)=>{const b=device.createBuffer({size,usage});owned.push(b);if(data)device.queue.writeBuffer(b,0,data);return b;};
const errors=[];device.addEventListener('uncapturederror',e=>errors.push(e.error.message));
const query=device.createQuerySet({type:'timestamp',count:2});
try {
 const shard=await fs.readFile('models/local/qwen-3-5-0-8b-q4k-ehaf16/shard_00007.bin');
 const module=device.createShaderModule({code:source});
 for(const [role,N,K,offset,bytes] of [['linear_qkv',6144,1024,38924448,3538944],['ffn_down',1024,3584,44822688,2064384]]) {
  const weights=shard.subarray(offset,offset+bytes);const B=buffer(bytes,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,weights);
  for(const M of [64,256]) {
   const input=Float32Array.from({length:M*K},(_,i)=>Math.sin(i*.31)*.7);
   const uniform=new ArrayBuffer(32),view=new DataView(uniform);[M,N,K].forEach((v,i)=>view.setUint32(i*4,v,true));view.setFloat32(12,1,true);view.setUint32(16,K/256,true);
   const U=buffer(32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST,uniform),A=buffer(input.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,input);
   const C=buffer(M*N*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST);
   const resolved=buffer(16,GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC),stage=buffer(C.size+16,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
   const pipelines=new Map();
   for(const [tm,tn] of [[4,256],[4,128],[8,128],[8,256],[4,64],[8,64]]) {
    const constants={TILE_M:tm,TILE_N:tn};const config=getMatmulConfig('q4_fused_widetile',constants);
    const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'main',constants}});
    const group=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[U,A,B,C].map((b,binding)=>({binding,resource:{buffer:b}}))});
    pipelines.set(`${tm}x${tn}`,{pipeline,group,workgroups:calculateMatmulDispatch('q4_fused_widetile',true,false,false,M,N,config).workgroups});
   }
   async function run(key){const {pipeline,group,workgroups}=pipelines.get(key);const enc=device.createCommandEncoder();enc.clearBuffer(C);const pass=enc.beginComputePass({timestampWrites:{querySet:query,beginningOfPassWriteIndex:0,endOfPassWriteIndex:1}});pass.setPipeline(pipeline);pass.setBindGroup(0,group);for(let i=0;i<report.dispatches;i++)pass.dispatchWorkgroups(...workgroups);pass.end();enc.resolveQuerySet(query,0,2,resolved,0);enc.copyBufferToBuffer(resolved,0,stage,0,16);enc.copyBufferToBuffer(C,0,stage,16,C.size);device.queue.submit([enc.finish()]);await stage.mapAsync(GPUMapMode.READ);const mapped=stage.getMappedRange(),times=new BigUint64Array(mapped,0,2);const result={ms:Number(times[1]-times[0])/1e6,hash:hash(Buffer.from(mapped,16))};assert(new Float32Array(mapped,16).every(Number.isFinite));stage.unmap();return result;}
   for(const candidate of [...pipelines.keys()].slice(1)) {const row={role,M,N,K,candidate,weightSha256:hash(weights),pairs:[]};report.rows.push(row);for(let pair=-report.warmups;pair<report.pairs;pair++){const order=pair%2?['candidate','baseline']:['baseline','candidate'];const result={pair,order};for(const lane of order)result[lane]=await run(lane==='baseline'?'4x256':candidate);assert.equal(result.baseline.hash,result.candidate.hash,`${role} ${M} ${candidate}`);row.pairs.push(result);}console.log(role,M,candidate,'exact');}
  }
 }
 assert.deepEqual(errors,[]);report.passed=true;
} finally {await device.queue.onSubmittedWorkDone();query.destroy();for(const b of owned)b.destroy();destroyDevice();await fs.writeFile('reports/qwen-competition-20261017/metal-widetile-profile.json',JSON.stringify(report,null,2)+'\n');}
