import json,pathlib,subprocess,sys
root=pathlib.Path.cwd(); size=sys.argv[1]; suffix='0-8b' if size=='08' else '2b';label='0.8B' if size=='08' else '2B'
out=root/'reports/qwen-competition-20261017';name='compare-first-request-metal-'+size
argv=['node','.tmp/qwen-final-20261017/tools/compare-engines.js','--model-id',f'qwen-3-5-{suffix}-q4k-ehaf16','--model-url',f'file://{root}/models/local/qwen-3-5-{suffix}-q4k-ehaf16','--tjs-version','4','--tjs-dtype','q4f16','--tjs-local-model-path',str(root/'.cache/qwen-comparator-relay'),'--prefill-tokens','64','--max-tokens','128','--temperature','0','--top-k','1','--top-p','1','--seed','0','--warmup','0','--runs','1','--mode','cold','--decode-profile','parity','--doppler-surface','browser','--load-mode','http','--browser-executable','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--resource-telemetry','on','--resource-telemetry-samples','--save','--save-dir',str(out/name),'--skip-matrix-update','--timeout-ms','240000','--json']
(out/(name+'-command.json')).write_text(json.dumps({'argv':argv,'sourceBase':'5beddd5d','sourceChanges':['46f5496a attention cache ownership','scalar fused recurrent state reuse plus corrected decode token accounting'],'comparison':'optimized 4-bit product formats; same work, separate quality gate'},indent=2)+'\n')
with (out/(name+'.log')).open('w') as log:
 result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=900)
raise SystemExit(result.returncode)
