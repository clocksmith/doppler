import json,pathlib,sys,time,subprocess,urllib.request,hashlib,platform
root=pathlib.Path.cwd();size=sys.argv[1];binary=pathlib.Path(sys.argv[2]).resolve();model=pathlib.Path(sys.argv[3]).resolve();revision=sys.argv[4];out=root/'reports/qwen-competition-20261017';out.mkdir(parents=True,exist_ok=True)
prompt='evidence supports it user request must stay safe true false yes no a the system should allow review when policy is clear and block unsafe changes only if evidence supports it user request must stay safe true false yes no a the system should allow review when policy is clear and block unsafe changes only if evidence supports it user request must stay'
report={'schema':'qwen-native-comparison/v1','engine':'llama.cpp','sourceRevision':revision,'platform':platform.platform(),'binary':str(binary),'model':str(model),'modelBytes':model.stat().st_size,'modelSha256':hashlib.file_digest(model.open('rb'),'sha256').hexdigest(),'prompt':prompt,'maxTokens':128,'runs':[],'loadScope':'fresh server; local files; OS page cache uncontrolled; ready time includes runtime/device initialization','timingScope':'HTTP SSE first/last token; same clock for endpoints; engine timings retained separately'}
argv=[str(binary),'-m',str(model),'-ngl','99','-c','256','-np','1','--flash-attn','on','--no-warmup','--host','127.0.0.1','--port','18839'];report['argv']=argv
log=(out/f'llama-{size}-server.log').open('w');start=time.perf_counter();proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);url='http://127.0.0.1:18839'
def request(path,body):return urllib.request.urlopen(urllib.request.Request(url+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=180)
try:
 while True:
  if proc.poll() is not None:raise RuntimeError('llama-server exited; inspect log')
  try:
   with urllib.request.urlopen(url+'/health',timeout=1) as response:
    if response.status==200:break
  except Exception:
   if time.perf_counter()-start>180:raise
   time.sleep(.05)
 report['readyMs']=(time.perf_counter()-start)*1000
 with request('/tokenize',{'content':prompt,'add_special':False}) as response:ids=json.load(response)['tokens']
 assert len(ids)==64,len(ids);report['promptTokenIds']=ids
 body={'prompt':ids,'n_predict':128,'temperature':0,'top_k':1,'top_p':1,'repeat_penalty':1,'seed':0,'cache_prompt':False,'stream':True,'return_tokens':True};report['request']=body
 for index in range(4):
  started=time.perf_counter();tokens=[];times=[];text='';events=[]
  with request('/completion',body) as response:
   for line in response:
    if not line.startswith(b'data: '):continue
    event=json.loads(line[6:]);events.append(event);now=(time.perf_counter()-started)*1000
    current=event.get('tokens',[])
    if current:tokens.extend(current);times.extend([now]*len(current))
    text+=event.get('content','')
  assert len(tokens)==128,(len(tokens),events[-1])
  row={'index':index,'phase':'first-request' if index==0 else 'warm','tokenIds':tokens,'tokenTimesMs':times,'text':text,'ttftMs':times[0],'decodeMs':times[-1]-times[0],'decodeTokens':127,'decodeTokensPerSec':127000/(times[-1]-times[0]),'totalMs':(time.perf_counter()-started)*1000,'finalEvent':events[-1]}
  report['runs'].append(row);print(json.dumps({k:row[k] for k in ['index','ttftMs','decodeMs','decodeTokensPerSec','totalMs']}),flush=True)
finally:
 proc.terminate()
 try:proc.wait(timeout=15)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close();(out/f'llama-{size}.json').write_text(json.dumps(report,indent=2)+'\n')
