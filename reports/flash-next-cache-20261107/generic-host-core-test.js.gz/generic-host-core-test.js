import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createNodeFileAccess } from '../../src/storage/node-file-access.js';
import { createNodeFileArtifactStorageContext } from '../../src/storage/artifact-storage-context.js';
import { resolveRuntimeConfig, enterRuntimeConfig, getRuntimeConfig, getRuntimeConfigDefaults } from '../../src/config/runtime.js';

const root = await fs.mkdtemp(path.join(os.tmpdir(), 'doppler-range-cache-'));
const policy = { enabled: true, maxBytes: 8, maxEntryBytes: 4 };
const one = path.join(root, 'one.bin'), two = path.join(root, 'two.bin');
await fs.writeFile(one, new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]));
await fs.writeFile(two, new Uint8Array([9, 10, 11, 12, 13, 14, 15, 16]));
try {
  assert.equal(resolveRuntimeConfig().loading.shardCache.hostRangeCache.enabled, false);
  const defaults = getRuntimeConfigDefaults();
  const active = resolveRuntimeConfig({ loading: { shardCache: { hostRangeCache: policy } } });
  const leave = enterRuntimeConfig(active);
  try {
    assert.equal(getRuntimeConfig(), active);
    assert.equal(getRuntimeConfigDefaults(), defaults, 'a concurrent load must not inherit another live session cache policy');
  } finally { leave(); }
  await assert.rejects(async () => createNodeFileAccess({ hostRangeCache: { ...policy, maxBytes: 2 } }), /bounded/);
  const access = createNodeFileAccess({ hostRangeCache: policy });
  try {
    const first = await access.readRange(one, 0, 4);
    new Uint8Array(first)[0] = 99;
    assert.deepEqual([...new Uint8Array(await access.readRange(one, 0, 4))], [1, 2, 3, 4]);
    assert.equal(access.getReadStats().sourceBytes, 4);
    assert.equal(access.getReadStats().hits, 1);
    await access.readRange(two, 0, 4);
    await access.readRange(one, 4, 4);
    assert.equal(access.getReadStats().residentBytes, 8);
    assert.equal(access.getReadStats().evictions, 1);
    assert.deepEqual([...new Uint8Array(await access.readRange(one, 0, 4))], [1, 2, 3, 4]);
    assert.equal(access.getReadStats().misses, 4, 'file and offset must both identify ranges');
    assert.equal((await access.readRange(one, 7, 3)).byteLength, 1, 'EOF clamping remains supported');
    assert.equal((await access.readRange(one, 100, 4)).byteLength, 0);
    assert.equal((await access.readRange(one, 0, null)).byteLength, 8);
    assert.equal(access.getReadStats().residentBytes, 8, 'large and truncated reads cannot populate cache');
  } finally { await access.close(); }
  assert.equal(access.getReadStats().residentBytes, 0);
  await assert.rejects(access.readRange(two, 0, 4), /closed/);
  await assert.rejects(access.getSize(two), /closed/);

  const pending = createNodeFileAccess({ hostRangeCache: policy });
  const a = pending.readRange(one, 0, 4), b = pending.readRange(one, 0, 4);
  a.catch(() => {}); b.catch(() => {});
  assert.equal(pending.getReadStats().pending, 1);
  assert.equal(pending.getReadStats().misses, 1);
  const closing = pending.close(), sameClosing = pending.close();
  assert.equal(closing, sameClosing, 'concurrent close shares cleanup ownership');
  await assert.rejects(a, /closed/); await assert.rejects(b, /closed/);
  await closing;
  assert.equal(pending.getReadStats().pending, 0);
  assert.equal(pending.getReadStats().residentBytes, 0, 'late reads cannot repopulate closed cache');

  const context = createNodeFileArtifactStorageContext(root, { modelId: 'cache-test',
    shards: [{ filename: 'one.bin', size: 8 }] }, { hostRangeCache: policy });
  try {
    const a = await context.loadShardRange(0, 1, 3), b = await context.loadShardRange(0, 1, 3);
    assert.notEqual(a, b); assert.deepEqual([...new Uint8Array(b)], [2, 3, 4]);
    assert.equal(context.getReadStats().hits, 1);
  } finally { await context.close(); }
} finally { await fs.rm(root, { recursive: true, force: true }); }
console.log('Node range cache: bounded immutable reads, EOF, identity, deduplication and pending/concurrent close passed.');
