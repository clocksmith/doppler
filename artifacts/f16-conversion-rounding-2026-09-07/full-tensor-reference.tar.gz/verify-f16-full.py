"""Offline exhaustive tensor-codec reference, not a model execution fallback."""
import hashlib
import json
import math
import mmap
import pathlib
import struct
import sys

import numpy as np

root = pathlib.Path(__file__).resolve().parent
output = pathlib.Path(sys.argv[1])
assert not output.exists(), 'Refusing to overwrite retained evidence'
model_roots = [root / 'f16-model', root / 'f16-rne-model']
manifest_bytes = [(p / 'manifest.json').read_bytes() for p in model_roots]
manifests = [json.loads(b) for b in manifest_bytes]
assert manifests[0]['tensors'] == manifests[1]['tensors']
assert manifests[0]['inference'] == manifests[1]['inference']
source_path = root / 'source/model.safetensors-00001-of-00001.safetensors'
with source_path.open('rb') as stream:
    header_size = struct.unpack('<Q', stream.read(8))[0]
    header = json.loads(stream.read(header_size))
source_map = np.memmap(source_path, dtype=np.uint8, mode='r')
shards = [[np.memmap(p / shard['filename'], dtype=np.uint8, mode='r')
           for shard in manifest['shards']]
          for p, manifest in zip(model_roots, manifests)]
report = {
    'schema': 'reploid.full-converted-tensor-reference/v1', 'complete': False,
    'boundary': 'Every stored text-tensor scalar compared as binary16 words against NumPy source rounding. No activation, inference, or semantic qualification.',
    'numpyVersion': np.__version__,
    'manifestDigests': ['sha256:' + hashlib.sha256(b).hexdigest() for b in manifest_bytes],
    'tensors': [],
}
chunk_elements = 1024 * 1024
for name, tensor in manifests[0]['tensors'].items():
    original = header[name]
    assert tensor['dtype'] == 'F16' and tensor['shape'] == original['shape']
    elements = math.prod(tensor['shape'])
    assert tensor['size'] == elements * 2
    dtype = original['dtype']
    source_dtype = {'BF16': '<u2', 'F16': '<f2', 'F32': '<f4'}[dtype]
    source_item_size = np.dtype(source_dtype).itemsize
    source_offset = 8 + header_size + original['data_offsets'][0]
    spans = tensor.get('spans', [{'shardIndex': tensor.get('shard'), 'offset': tensor.get('offset'), 'size': tensor['size']}])
    record = {'name': name, 'sourceDtype': dtype, 'elements': elements,
              'originalMismatches': 0, 'correctedMismatches': 0, 'changedWords': 0,
              'nonfiniteSource': 0, 'nonfiniteExpected': 0, 'examples': []}
    tensor_index = 0
    for span in spans:
        assert span['size'] % 2 == 0
        for start in range(0, span['size'] // 2, chunk_elements):
            count = min(chunk_elements, span['size'] // 2 - start)
            source = np.frombuffer(source_map, dtype=source_dtype, count=count,
                                   offset=source_offset + (tensor_index + start) * source_item_size)
            if dtype == 'BF16':
                values = (source.astype('<u4') << 16).view('<f4')
            else:
                values = source
            expected_half = values.astype('<f2')
            expected = expected_half.view('<u2')
            actual = [np.frombuffer(bank[span['shardIndex']], dtype='<u2', count=count,
                                   offset=span['offset'] + start * 2) for bank in shards]
            old_bad, new_bad = actual[0] != expected, actual[1] != expected
            record['originalMismatches'] += int(np.count_nonzero(old_bad))
            record['correctedMismatches'] += int(np.count_nonzero(new_bad))
            record['changedWords'] += int(np.count_nonzero(actual[0] != actual[1]))
            record['nonfiniteSource'] += int(np.count_nonzero(~np.isfinite(values)))
            record['nonfiniteExpected'] += int(np.count_nonzero(~np.isfinite(expected_half)))
            if len(record['examples']) < 4:
                for index in np.flatnonzero(old_bad | new_bad)[:4-len(record['examples'])]:
                    record['examples'].append({'index': tensor_index + start + int(index),
                        'source': float(values[index]), 'expectedWord': int(expected[index]),
                        'originalWord': int(actual[0][index]), 'correctedWord': int(actual[1][index])})
        tensor_index += span['size'] // 2
    assert tensor_index == elements
    report['tensors'].append(record)
    print(json.dumps({'tensor': len(report['tensors']), **{k:v for k,v in record.items() if k not in ['examples']}}), flush=True)
report['totals'] = {key: sum(row[key] for row in report['tensors']) for key in
    ['elements', 'originalMismatches', 'correctedMismatches', 'changedWords', 'nonfiniteSource', 'nonfiniteExpected']}
report['complete'] = True
report['passed'] = all(report['totals'][key] == 0 for key in ['correctedMismatches', 'nonfiniteSource', 'nonfiniteExpected'])
with output.open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'passed': report['passed'], **report['totals']}), flush=True)
if not report['passed']:
    raise SystemExit(1)
