import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';

const root = '/tmp/reploid-qwen35-answer-screen.06HATl';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const readJson = async path => JSON.parse(await readFile(path));
const modelRoot = root + '/f16-model';
const manifestBytes = await readFile(modelRoot + '/manifest.json');
const manifest = JSON.parse(manifestBytes);
const corrected = await readJson(root + '/f16-rne-model/manifest.json');
const integrity = await readJson(root + '/f16-integrity.json');
const comparisonBytes = await readFile(root + '/f16-full-tensor-comparison.json');
const comparison = JSON.parse(comparisonBytes);
assert.equal(integrity.complete, true);
assert.equal(comparison.complete, true);
assert.equal(integrity.manifestDigest, 'sha256:' + sha(manifestBytes));
assert.equal(comparison.manifestDigests[0], integrity.manifestDigest);
assert.equal(comparison.manifestDigests[1], 'sha256:' + sha(await readFile(root + '/f16-rne-model/manifest.json')));
assert.equal(comparison.totals.correctedMismatches, 0);
assert(comparison.totals.originalMismatches > 0);
assert.deepEqual(manifest.inference, corrected.inference);
assert.deepEqual(manifest.tensors, corrected.tensors);
assert.deepEqual(manifest.tokenizer, corrected.tokenizer);
const tokenizerName = manifest.tokenizer.file;
assert(/^[a-zA-Z0-9_.-]+$/.test(tokenizerName));
const tokenizerBytes = await readFile(modelRoot + '/' + tokenizerName);
assert.equal(sha(tokenizerBytes), sha(await readFile(root + '/f16-rne-model/' + tokenizerName)));
assert.equal(integrity.shards.length, manifest.shards.length);
const files = [{ filename: 'manifest.json', bytes: manifestBytes.length, sha256: sha(manifestBytes) }];
for (const shard of manifest.shards) {
  const verified = integrity.shards.find(row => row.filename === shard.filename);
  assert(verified);
  assert.equal(verified.bytes, shard.size);
  assert.equal(verified.blake3, shard.hash);
  files.push({ filename: shard.filename, bytes: verified.bytes, sha256: verified.sha256 });
}
files.push({ filename: tokenizerName, bytes: tokenizerBytes.length, sha256: sha(tokenizerBytes) });
const acquisition = { schema: 'reploid.local-conversion-artifacts/v1', complete: true,
  modelId: manifest.modelId, manifestDigest: integrity.manifestDigest,
  boundary: 'Known nonconforming original F16 conversion, executed only as a paired adverse control. Artifact identity is verified; source-rounded numerical qualification is explicitly false. No promotion.',
  sourceRoundedNumericsPassed: false,
  fullComparisonDigest: 'sha256:' + sha(comparisonBytes),
  files, totalBytes: files.reduce((sum, row) => sum + row.bytes, 0) };
await writeFile(root + '/f16-original-control-acquisition.json', JSON.stringify(acquisition, null, 2) + '\n', { flag: 'wx' });
await mkdir(root + '/f16-original-screen-01');
await writeFile(root + '/f16-original-screen-01/model-screen-config.json', JSON.stringify({
  artifactRoot: modelRoot, manifestDigest: integrity.manifestDigest,
  acquisitionPath: root + '/f16-original-control-acquisition.json',
  browserUserDataDir: '/tmp/reploid-f16-original-profile.zR0BVu',
}, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ originalManifestDigest: integrity.manifestDigest,
  inferenceIdentical: true, tensorDescriptorsIdentical: true, tokenizerBytesIdentical: true,
  fullComparisonDigest: acquisition.fullComparisonDigest, sourceRoundedNumericsPassed: false }));
