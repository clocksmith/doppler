// Physical development screening through the published model API, not Capsule qualification.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '/home/clocksmith/deco/reploid/node_modules/playwright/index.mjs';
import { createStaticFileServer } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/tooling/node-browser-command-runner.js';
import { hash as blake3 } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/storage/blake3.js';
import { buildDocumentAnswerPrompt } from '/home/clocksmith/deco/reploid/self/pool/document-answer.js';
import { readDocumentAnswerCorpus } from '/home/clocksmith/deco/reploid/scripts/evaluate-document-answers.js';
const root = process.argv[2] ? resolve(process.argv[2]) : dirname(fileURLToPath(import.meta.url));
const modelInput = process.argv[2] ? await jsonInput(root + '/model-screen-config.json') : null;
async function jsonInput(path) { return JSON.parse(await readFile(path, 'utf8')); }
const repo = '/home/clocksmith/deco/reploid';
const packageRoot = modelInput?.runtimeRoot ?? repo + '/node_modules/doppler-gpu';
const selfRoot = modelInput?.selfRoot ?? repo + '/self';
const artifactRoot = modelInput?.artifactRoot ?? '/home/clocksmith/deco/doppler/models/local/create-gemma-3-1b-qualification';
const sha = bytes => 'sha256:' + createHash('sha256').update(bytes).digest('hex');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const baseline = await json('/tmp/reploid-answer-development.gojRmi/experiment.json');
const policy = await json(repo + '/self/pool/document-search-policy.json');
const originalCorpusBytes = await readFile('/tmp/reploid-answer-development.gojRmi/development.json');
const corpus = JSON.parse(originalCorpusBytes);
corpus.id = 'answer-development-2026-09-07-a-review-bindings';
corpus.parentDigest = sha(originalCorpusBytes);
corpus.boundary = 'Same exposed development questions, passages, and requirements; explicit supporting passage IDs added for strict admission. Not a holdout.';
for (const row of corpus.cases) {
  if (['answerable', 'partially-answerable'].includes(row.category)) row.review.supportingPassages = row.passages.map(p => p.id);
}
const corpusBytes = JSON.stringify(corpus, null, 2) + '\n';
await writeFile(root + '/corpus.json', corpusBytes, { flag: 'wx' });
await readDocumentAnswerCorpus({ corpusPath: root + '/corpus.json', corpusDigest: sha(corpusBytes) });
const generationOptions = { ...baseline.options };
delete generationOptions.maxSeqLen; // Public model API owns context size at load, not generation call time.
const config = {
  hypothesis: modelInput?.hypothesis ?? 'This declared model configuration satisfies all development support requirements using the unchanged product prompt.',
  selectionRule: baseline.selectionRule,
  corpusDigest: sha(corpusBytes), parentCorpusDigest: sha(originalCorpusBytes),
  productPromptDigest: sha(await readFile(repo + '/self/pool/document-answer.js')),
  generationOptions,
  loadOptions: { cache: 'opfs', runtimeConfig: modelInput?.runtimeConfig ?? { inference: { kvcache: { maxSeqLen: baseline.options.maxSeqLen } } } },
  browserExecutablePath: '/home/clocksmith/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome',
  browserArgs: ['--enable-unsafe-webgpu', '--enable-features=Vulkan', '--use-angle=vulkan', '--disable-gpu-sandbox'],
  browserUserDataDir: modelInput?.browserUserDataDir ?? null,
  timeoutMs: 1200000,
};
const manifestBytes = await readFile(artifactRoot + '/manifest.json');
assert.equal(sha(manifestBytes), modelInput?.manifestDigest ?? 'sha256:f947e3ccac8028c9fcd0eb87cad3deec023102672288c75353d97d3b813e731b');
const manifest = JSON.parse(manifestBytes);
const acquisition = await json(modelInput?.acquisitionPath ?? '/home/clocksmith/deco/doppler/artifacts/create-generation-qualification/acquisition.json');
if (modelInput) assert.equal(acquisition.complete, true, 'Acquisition must complete before execution');
const files = [];
for (const expected of acquisition.files) {
  const bytes = await readFile(artifactRoot + '/' + expected.filename);
  assert.equal(bytes.length, expected.bytes);
  assert.equal(sha(bytes), 'sha256:' + expected.sha256);
  const shard = manifest.shards.find(row => row.filename === expected.filename);
  if (shard) {
    assert.equal(manifest.hashAlgorithm, 'blake3');
    assert.equal(Buffer.from(await blake3(bytes)).toString('hex'), shard.blake3 ?? shard.hash);
  }
  files.push(expected);
}
await writeFile(root + '/manifest.json', manifestBytes, { flag: 'wx' });
await writeFile(root + '/config.json', JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
await writeFile(root + '/acquisition.json', JSON.stringify(acquisition, null, 2) + '\n', { flag: 'wx' });
await writeFile(root + '/runner.js', await readFile(fileURLToPath(import.meta.url)), { flag: 'wx' });
const rows = corpus.cases.map(row => ({ ...row, prompt: buildDocumentAnswerPrompt({ question: row.question,
  passages: row.passages, abstention: policy.answerAbstention, unknown: policy.answerUnknown }) }));
for (const row of rows) assert.equal(row.prompt, baseline.rows.find(r => r.id === row.id && r.arm === 'baseline').prompt);
const report = { schema: 'reploid.document-answer-model-screen/v1', startedAt: new Date().toISOString(),
  complete: false, semanticSupportQualified: false, independentOperators: false, signedCapsuleExecution: false,
  manifestDigest: sha(manifestBytes), files, config, configDigest: sha(await readFile(root + '/config.json')),
  package: await json(packageRoot + '/package.json'), cases: [], logs: [], requests: [], servedSources: [] };
let server, browser, timer;
const captures = [];
const sources = new Map();
const retain = () => writeFile(root + '/execution.json', JSON.stringify(report, null, 2) + '\n');
try {
  server = await createStaticFileServer({ rootDir: packageRoot, host: '127.0.0.1', port: 0,
    staticMounts: [{ urlPrefix: '/self', rootDir: selfRoot }, { urlPrefix: '/model', rootDir: artifactRoot }] });
  const launchOptions = { executablePath: config.browserExecutablePath, headless: true, args: config.browserArgs };
  browser = config.browserUserDataDir
    ? await chromium.launchPersistentContext(config.browserUserDataDir, launchOptions)
    : await chromium.launch(launchOptions);
  timer = setTimeout(() => { report.timedOut = true; void browser.close(); }, config.timeoutMs);
  const page = await browser.newPage();
  const browserProbe = await page.context().newCDPSession(page);
  const version = await browserProbe.send('Browser.getVersion');
  await browserProbe.detach();
  report.browser = { version: version.product, digest: sha(await readFile(config.browserExecutablePath)),
    contextKind: config.browserUserDataDir ? 'fresh-persistent-profile' : 'temporary-context' };
  page.on('console', message => report.logs.push({ type: message.type(), text: message.text() }));
  page.on('pageerror', error => report.logs.push({ type: 'pageerror', text: error.message }));
  page.on('response', response => {
    const path = new URL(response.url()).pathname;
    if (!response.ok() || !/\.(js|json|wgsl)$/.test(path) || path.startsWith('/model/')) return;
    captures.push(response.body().then(async bytes => {
      if (sources.has(path)) assert.equal(sources.get(path).digest, sha(bytes));
      sources.set(path, { path, digest: sha(bytes), bytes: bytes.length });
      const destination = resolve(root, 'runtime', '.' + path);
      assert(destination.startsWith(root + '/runtime/'));
      await mkdir(dirname(destination), { recursive: true }); await writeFile(destination, bytes);
    }));
  });
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    report.requests.push({ url: url.href, method: route.request().method() });
    if (url.origin !== server.baseUrl || route.request().method() !== 'GET') return route.abort();
    if (url.pathname === '/screen') return route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Answer development screen</title>' });
    return route.continue();
  });
  await page.exposeFunction('retainCase', async row => {
    report.cases.push(row); await retain(); console.log(JSON.stringify({ id: row.id, output: row.evidence?.outputText, error: row.error }));
  });
  await page.exposeFunction('retainPhase', async phase => { Object.assign(report, phase); await retain(); console.log(JSON.stringify(phase)); });
  await page.goto(server.baseUrl + '/screen');
  report.execution = await page.evaluate(async ({ rows, config, policy }) => {
    const adapter = await navigator.gpu?.requestAdapter();
    const gpu = adapter && { vendor: adapter.info.vendor, architecture: adapter.info.architecture,
      fallback: adapter.isFallbackAdapter ?? adapter.info.isFallbackAdapter };
    if (gpu?.vendor !== 'intel' || gpu.fallback !== false) throw new Error('Physical Intel GPU required');
    await window.retainPhase({ gpu, phase: 'loading', storageEstimate: await navigator.storage.estimate() });
    const { doppler } = await import('/src/client/doppler-api.browser.js');
    const { inspectDocumentAnswer } = await import('/self/pool/document-answer.js');
    let model;
    try {
      const began = performance.now();
      model = await doppler.load({ url: location.origin + '/model' }, config.loadOptions);
      const loadMs = performance.now() - began;
      await window.retainPhase({ phase: 'generating', loadMs });
      for (const row of rows) {
        const start = performance.now();
        const result = { id: row.id, prompt: row.prompt, passages: row.passages, options: config.generationOptions };
        try {
          result.evidence = await model.generateWithEvidence([{ role: 'user', content: row.prompt }], config.generationOptions);
          result.inspection = inspectDocumentAnswer({ text: result.evidence.outputText, passages: row.passages,
            abstention: policy.answerAbstention, unknown: policy.answerUnknown });
        } catch (error) { result.error = { name: error.name, message: error.message }; }
        result.elapsedMs = performance.now() - start;
        await window.retainCase(result);
      }
      return { loadMs, gpu };
    } finally { await model?.unload(); }
  }, { rows, config, policy });
  await Promise.all(captures);
  report.complete = report.cases.length === rows.length && report.cases.every(row => !row.error);
} catch (error) { report.error = { name: error.name, message: error.message, stack: error.stack }; }
finally {
  clearTimeout(timer);
  const cleanup = await Promise.allSettled([browser?.close(), server?.close()]);
  await Promise.allSettled(captures);
  report.cleanupErrors = cleanup.filter(row => row.status === 'rejected').map(row => String(row.reason));
  report.complete &&= report.cleanupErrors.length === 0;
  report.servedSources = [...sources.values()];
  await retain();
}
console.log(JSON.stringify({ complete: report.complete, cases: report.cases.length, error: report.error }));
if (!report.complete) process.exitCode = 1;
