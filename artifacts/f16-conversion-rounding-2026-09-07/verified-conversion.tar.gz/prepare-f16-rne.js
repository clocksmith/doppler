import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root = '/tmp/reploid-qwen35-answer-screen.06HATl';
const repo = '/home/clocksmith/deco/doppler';
const sha = bytes => 'sha256:' + createHash('sha256').update(bytes).digest('hex');
const original = await readFile(root + '/f16-config.json');
const config = JSON.parse(original);
config.output.modelBaseId = 'qwen-3-5-2b-f16-af32-rne-diagnostic';
const bytes = JSON.stringify(config, null, 2) + '\n';
await writeFile(root + '/f16-rne-config.json', bytes, {flag:'wx'});
const files = ['src/converter/quantizer.js', 'src/converter/tensor-transform.js', 'tools/convert-safetensors-node.js'];
const snapshots = [];
for (const path of files) {
  const source = await readFile(repo + '/' + path);
  const destination = 'f16-rne-' + path.replaceAll('/', '_');
  await writeFile(root + '/' + destination, source, {flag:'wx'});
  snapshots.push({path, digest:sha(source), snapshot:destination});
}
await writeFile(root + '/f16-rne-lineage.json', JSON.stringify({
  schema: 'reploid.precision-control-lineage/v1', originalConfigDigest: sha(original), configDigest:sha(bytes),
  sourceFiles:snapshots, priorNumericObservationDigest:sha(await readFile(root + '/f16-tensor-samples.json')),
  boundary:'New conversion from the same pinned source checkpoint after correcting F32-to-F16 rounding. Original artifacts unchanged. No model promotion.',
  hypothesis:'Nearest-even conversion makes sampled artifact values equal the source rounded to F16; subsequent physical execution tests the retained carton-output discrepancy.'
}, null, 2) + '\n', {flag:'wx'});
console.log(JSON.stringify({configDigest:sha(bytes),modelId:config.output.modelBaseId}));
