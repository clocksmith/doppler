"""Offline source-to-converted sampling only; never an inference fallback."""
import collections, hashlib, json, math, pathlib, struct, sys

root = pathlib.Path(__file__).resolve().parent
model_root = pathlib.Path(sys.argv[1]).resolve()
report_path = pathlib.Path(sys.argv[2]).resolve()
assert not report_path.exists(), 'Refusing to overwrite retained evidence'
manifest_bytes = (model_root / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
source = root / 'source/model.safetensors-00001-of-00001.safetensors'
report = {'schema': 'reploid.converted-tensor-samples/v1', 'complete': False,
          'manifestDigest': 'sha256:' + hashlib.sha256(manifest_bytes).hexdigest(),
          'boundary': '16 evenly spaced scalar samples per text tensor, compared after explicit F16 rounding. Not full-tensor equivalence or runtime evidence.', 'tensors': []}
with source.open('rb') as stream:
    header_size = struct.unpack('<Q', stream.read(8))[0]
    header = json.loads(stream.read(header_size))
    report['sourceDtypes'] = dict(collections.Counter(v['dtype'] for k, v in header.items() if k != '__metadata__'))
    for name, tensor in manifest['tensors'].items():
        original = header[name]
        assert original['shape'] == tensor['shape'], name
        assert tensor['dtype'] == 'F16', name
        count = math.prod(tensor['shape'])
        assert tensor['size'] == count * 2, name
        offsets = sorted(set(round((count - 1) * index / 15) for index in range(16)))
        spans = tensor.get('spans', [{'shardIndex': tensor.get('shard'), 'offset': tensor.get('offset'), 'size': tensor['size']}])
        observations = []
        for index in offsets:
            dtype = original['dtype']
            size = {'BF16': 2, 'F32': 4, 'F16': 2}[dtype]
            stream.seek(8 + header_size + original['data_offsets'][0] + index * size)
            raw = stream.read(size)
            value = struct.unpack('<f', b'\x00\x00' + raw)[0] if dtype == 'BF16' else struct.unpack('<f' if dtype == 'F32' else '<e', raw)[0]
            rounded = struct.unpack('<e', struct.pack('<e', value))[0]
            location = index * 2
            for span in spans:
                if location < span['size']:
                    with (model_root / manifest['shards'][span['shardIndex']]['filename']).open('rb') as shard:
                        shard.seek(span['offset'] + location)
                        actual = struct.unpack('<e', shard.read(2))[0]
                    break
                location -= span['size']
            else:
                raise ValueError('Sample outside tensor spans: ' + name)
            observations.append({'index': index, 'source': value, 'expectedF16': rounded, 'actual': actual,
                                 'equal': math.isfinite(actual) and math.isfinite(value) and rounded == actual})
        report['tensors'].append({'name': name, 'sourceDtype': dtype, 'shape': tensor['shape'], 'samples': observations,
                                  'passed': all(row['equal'] for row in observations)})
source_config = json.loads((root / 'source/config.json').read_text())
report['layerPatternMatchesSource'] = source_config['text_config']['layer_types'] == manifest['inference']['layerPattern']['layerTypes']
report['complete'] = True
report['passed'] = report['layerPatternMatchesSource'] and all(t['passed'] for t in report['tensors'])
with report_path.open('x') as report_stream:
    report_stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'tensors': len(report['tensors']),
                  'samples': sum(len(t['samples']) for t in report['tensors']),
                  'failedTensors': [t['name'] for t in report['tensors'] if not t['passed']]}))
if not report['passed']:
    raise SystemExit(1)
