import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {hash as blake3} from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/storage/blake3.js';
const root = '/tmp/reploid-qwen35-answer-screen.06HATl';
const [modelRoot, reportPath] = process.argv.slice(2);
assert(modelRoot && reportPath, 'Expected explicit model root and new report path');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const manifestBytes = await readFile(modelRoot + '/manifest.json');
const manifest = JSON.parse(manifestBytes);
const acquisition = JSON.parse(await readFile(root + '/source-acquisition.json'));
const sourceName = 'model.safetensors-00001-of-00001.safetensors';
const expected = acquisition.files.find(f => f.filename === sourceName);
assert(expected);
const hash = createHash('sha256');
let sourceBytes = 0;
for await (const chunk of createReadStream(root + '/source/' + sourceName)) {hash.update(chunk); sourceBytes += chunk.length;}
const sourceDigest = hash.digest('hex');
assert.equal(sourceDigest, expected.sha256);
assert.equal(sourceBytes, expected.bytes);
const report = {complete:false, manifestDigest:'sha256:' + sha(manifestBytes),
  sourceWeights:{filename:sourceName,bytes:sourceBytes,sha256:sourceDigest},shards:[]};
assert.equal(manifest.hashAlgorithm, 'blake3');
for (const shard of manifest.shards) {
  assert(/^[a-zA-Z0-9_.-]+$/.test(shard.filename));
  const bytes = await readFile(modelRoot + '/' + shard.filename);
  const actual = Buffer.from(await blake3(bytes)).toString('hex');
  assert.equal(bytes.length, shard.size);
  assert.equal(actual, shard.hash);
  report.shards.push({filename:shard.filename,bytes:bytes.length,blake3:actual,sha256:sha(bytes)});
}
report.complete = true;
await writeFile(reportPath,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({sourceDigest,shards:report.shards.length,manifestDigest:report.manifestDigest}));
