import assert from 'node:assert/strict';
import {readFile, writeFile, stat, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {hash as blake3} from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/storage/blake3.js';
const root = '/tmp/reploid-qwen35-answer-screen.06HATl';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const manifestBytes = await readFile(root + '/f16-rne-model/manifest.json');
const manifest = JSON.parse(manifestBytes);
const conversionBytes = await readFile('/home/clocksmith/deco/doppler/reports/qwen-3-5-2b-f16-af32-rne-diagnostic/2026-09-07T18-49-20.395Z.json');
const conversion = JSON.parse(conversionBytes);
assert.equal(conversion.result.shardCount, manifest.shards.length);
assert.equal(conversion.result.tensorCount, Object.keys(manifest.tensors).length);
for (const name of ['executionContractArtifact', 'layerPatternContractArtifact', 'requiredInferenceFieldsArtifact']) assert.equal(conversion[name].ok, true);
assert.equal(manifest.hashAlgorithm, 'blake3');
assert.equal(manifest.quantization, 'F16');
const samples = JSON.parse(await readFile(root + '/f16-rne-tensor-samples.json'));
const integrity = JSON.parse(await readFile(root + '/f16-rne-integrity.json'));
assert.equal(integrity.complete, true);
assert.equal(integrity.manifestDigest, 'sha256:' + sha(manifestBytes));
assert.equal(samples.passed, true);
assert.equal(samples.manifestDigest, 'sha256:' + sha(manifestBytes));
const record = {schema: 'reploid.local-conversion-artifacts/v1', complete: false,
  modelId: manifest.modelId, manifestDigest: 'sha256:' + sha(manifestBytes),
  configDigest: 'sha256:' + sha(await readFile(root + '/f16-rne-config.json')),
  sourceAcquisitionDigest: 'sha256:' + sha(await readFile(root + '/source-acquisition.json')),
  conversionReportDigest: 'sha256:' + sha(conversionBytes), tensorSamplesDigest: 'sha256:' + sha(await readFile(root + '/f16-rne-tensor-samples.json')),
  integrityReportDigest: 'sha256:' + sha(await readFile(root + '/f16-rne-integrity.json')),
  boundary: 'Locally converted precision-control artifacts. No peer acquisition or signed Capsule qualification.', files: []};
for (const filename of ['manifest.json', ...manifest.shards.map(s => s.filename), manifest.tokenizer.file]) {
  assert(/^[a-zA-Z0-9_.-]+$/.test(filename));
  const bytes = await readFile(root + '/f16-rne-model/' + filename);
  const shard = manifest.shards.find(s => s.filename === filename);
  if (shard) {
    assert.equal(bytes.length, shard.size);
    assert.equal(Buffer.from(await blake3(bytes)).toString('hex'), shard.hash);
  }
  record.files.push({filename, bytes: bytes.length, sha256: sha(bytes)});
}
record.complete = true;
record.totalBytes = record.files.reduce((sum, f) => sum + f.bytes, 0);
await writeFile(root + '/f16-rne-acquisition.json', JSON.stringify(record, null, 2) + '\n', {flag:'wx'});
await writeFile(root + '/f16-rne-conversion-report.json', conversionBytes, {flag:'wx'});
await mkdir(root + '/f16-rne-screen-01');
await writeFile(root + '/f16-rne-screen-01/model-screen-config.json', JSON.stringify({
  artifactRoot: root + '/f16-rne-model', manifestDigest: record.manifestDigest, acquisitionPath: root + '/f16-rne-acquisition.json'
}, null, 2) + '\n', {flag:'wx'});
console.log(JSON.stringify({manifestDigest:record.manifestDigest,files:record.files.length,totalBytes:record.totalBytes}));
