// =============================================================================
// Default Config
// =============================================================================

export const DEFAULT_HARNESS_CONFIG = {
  mode: 'verify',
  workload: 'kernels',
  autorun: false,
  skipLoad: false,
  modelId: null,
  referenceTranscript: {
    enabled: false,
    captureLogits: false,
    captureKvBytes: false,
  },
  tsirFixture: null,
  trainingBench: {
    ebmRecorded: {
      dims: {
        M: 128,
        K: 512,
        H: 1024,
        O: 1,
      },
    },
  },
};
