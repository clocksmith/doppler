import { loadJson } from '../../formats/load-json.js';
import { GB } from './units.schema.js';

const gh200Profile = await loadJson('../platforms/nvidia-gh200.json', import.meta.url, 'Failed to load platform config');
const gh200Nvl2Profile = await loadJson('../platforms/nvidia-gh200-nvl2.json', import.meta.url, 'Failed to load platform config');
const gb2008Profile = await loadJson('../platforms/nvidia-gb200-8gpu.json', import.meta.url, 'Failed to load platform config');
const gb200Nvl72Profile = await loadJson('../platforms/nvidia-gb200-nvl72.json', import.meta.url, 'Failed to load platform config');

// =============================================================================
// GPU Specifications
// =============================================================================

const H100_GPU_SPEC = {
  name: 'H100',
  vramBytes: 96 * GB,
  hbmBandwidthBytesPerSec: 3.35e12,   // 3.35 TB/s HBM3
  fp16Tflops: 1979,                    // ~2 PFLOPS
};

const H200_GPU_SPEC = {
  name: 'H200',
  vramBytes: 144 * GB,
  hbmBandwidthBytesPerSec: 4.8e12,     // 4.8 TB/s HBM3e
  fp16Tflops: 1979,                     // ~2 PFLOPS
};

const B200_GPU_SPEC = {
  name: 'B200',
  vramBytes: 192 * GB,
  hbmBandwidthBytesPerSec: 8e12,       // 8 TB/s HBM3e
  fp16Tflops: 4500,                     // 4.5 PFLOPS
  fp8Tflops: 9000,                      // 9 PFLOPS FP8
};

export const DEFAULT_GH200_GPU_SPEC = H200_GPU_SPEC;

// =============================================================================
// CPU Specifications
// =============================================================================

const GRACE_CPU_SPEC = {
  name: 'Grace',
  cores: 72,
  memoryBytes: 480 * GB, // LPDDR5X
  memoryBandwidthBytesPerSec: 546e9,      // 546 GB/s
};

export const DEFAULT_GH200_CPU_SPEC = GRACE_CPU_SPEC;

// =============================================================================
// NVLink Specifications
// =============================================================================

const NVLINK_4_SPEC = {
  bandwidthBytesPerSec: 900e9, // 900 GB/s
  latencyUs: 1.0,              // ~1 microsecond
};

const NVLINK_5_SPEC = {
  bandwidthBytesPerSec: 1.8e12, // 1.8 TB/s
  latencyUs: 0.8,               // ~0.8 microseconds
};

export const DEFAULT_NVLINK_SPEC = NVLINK_4_SPEC;

export const DEFAULT_NVLINK_C2C_SPEC = {
  bandwidthBytesPerSec: 900e9, // 900 GB/s
  latencyUs: 0.5,              // Lower latency for coherent access
  coherent: true,
};

// =============================================================================
// Cluster Topologies
// =============================================================================

const GH200_TOPOLOGY = {
  gpuCount: 1,
  gpusPerNode: 1,
  nodeCount: 1,
  cpuCount: 1,
};

const GH200_NVL2_TOPOLOGY = {
  gpuCount: 2,
  gpusPerNode: 2,
  nodeCount: 1,
  cpuCount: 2,
};

const GB200_8GPU_TOPOLOGY = {
  gpuCount: 8,
  gpusPerNode: 8,
  nodeCount: 1,
  cpuCount: 2,
};

const GB200_NVL72_TOPOLOGY = {
  gpuCount: 72,
  gpusPerNode: 8,
  nodeCount: 9,
  cpuCount: 18, // 2 CPUs per node
};

// =============================================================================
// Parallelism Defaults
// =============================================================================

export const DEFAULT_PARALLELISM_CONFIG = {
  tensorParallel: {
    enabled: false,
    degree: 1,
  },
  pipelineParallel: {
    enabled: false,
    stages: 1,
    microBatches: 1,
  },
  dataParallel: {
    enabled: false,
    degree: 1,
  },
  expertParallel: {
    enabled: false,
    degree: 1,
  },
};

const TP2_PARALLELISM_CONFIG = {
  ...DEFAULT_PARALLELISM_CONFIG,
  tensorParallel: {
    enabled: true,
    degree: 2,
  },
};

const TP8_PARALLELISM_CONFIG = {
  ...DEFAULT_PARALLELISM_CONFIG,
  tensorParallel: {
    enabled: true,
    degree: 8,
  },
};

// =============================================================================
// Timing Scaling Defaults
// =============================================================================

const DEFAULT_TIMING_SCALING = {
  computeScale: 1.0,
  memoryScale: 1.0,
  nvlinkScale: 1.0,
};

// =============================================================================
// Complete Emulation Config Defaults
// =============================================================================

export const DEFAULT_EMULATION_CONFIG = {
  enabled: false,
  targetChip: 'gh200',
  timingMode: 'functional',
  gpuSpec: DEFAULT_GH200_GPU_SPEC,
  cpuSpec: DEFAULT_GH200_CPU_SPEC,
  topology: GH200_TOPOLOGY,
  nvlink: DEFAULT_NVLINK_SPEC,
  nvlinkC2C: DEFAULT_NVLINK_C2C_SPEC,
  parallelism: DEFAULT_PARALLELISM_CONFIG,
  timingScaling: DEFAULT_TIMING_SCALING,
  localResources: undefined,
  opfsRootPath: 'emulation',
  maxActiveWorkingSetBytes: 4 * GB, // default working set
  statsEnabled: true,
  logOperations: false,
};

// =============================================================================
// Chip Profiles
// =============================================================================

const CHIP_PROFILES = {
  'gh200': gh200Profile.emulation,
  'gh200-nvl2': gh200Nvl2Profile.emulation,
  'gb200-8gpu': gb2008Profile.emulation,
  'gb200-nvl72': gb200Nvl72Profile.emulation,
};

export function getChipProfile(chipType) {
  const profile = CHIP_PROFILES[chipType];
  if (!profile) {
    throw new Error(`Unknown chip type: ${chipType}. Valid types: ${Object.keys(CHIP_PROFILES).join(', ')}`);
  }
  return { ...profile };
}

export function createEmulationConfig(overrides) {
  if (!overrides) {
    return { ...DEFAULT_EMULATION_CONFIG };
  }

  // If targetChip is specified, apply the chip profile first
  const chipProfile = overrides.targetChip
    ? getChipProfile(overrides.targetChip)
    : {};
  const { enabled: _enabled, ...chipProfileConfig } = chipProfile;
  const profileParallelism = chipProfileConfig.parallelism
    ? mergeParallelismConfig(DEFAULT_PARALLELISM_CONFIG, chipProfileConfig.parallelism)
    : DEFAULT_PARALLELISM_CONFIG;
  const resolvedParallelism = overrides.parallelism
    ? mergeParallelismConfig(profileParallelism, overrides.parallelism)
    : profileParallelism;

  return {
    ...DEFAULT_EMULATION_CONFIG,
    ...chipProfileConfig,
    ...overrides,
    enabled: overrides.enabled ?? DEFAULT_EMULATION_CONFIG.enabled,
    // Deep merge nested objects
    gpuSpec: {
      ...DEFAULT_EMULATION_CONFIG.gpuSpec,
      ...chipProfileConfig.gpuSpec,
      ...overrides.gpuSpec,
    },
    cpuSpec: {
      ...DEFAULT_EMULATION_CONFIG.cpuSpec,
      ...chipProfileConfig.cpuSpec,
      ...overrides.cpuSpec,
    },
    topology: {
      ...DEFAULT_EMULATION_CONFIG.topology,
      ...chipProfileConfig.topology,
      ...overrides.topology,
    },
    nvlink: {
      ...DEFAULT_EMULATION_CONFIG.nvlink,
      ...chipProfileConfig.nvlink,
      ...overrides.nvlink,
    },
    nvlinkC2C: {
      ...DEFAULT_EMULATION_CONFIG.nvlinkC2C,
      ...chipProfileConfig.nvlinkC2C,
      ...overrides.nvlinkC2C,
    },
    parallelism: resolvedParallelism,
    timingScaling: {
      ...DEFAULT_EMULATION_CONFIG.timingScaling,
      ...overrides.timingScaling,
    },
  };
}

function mergeParallelismConfig(base, overrides) {
  return {
    tensorParallel: {
      ...base.tensorParallel,
      ...overrides.tensorParallel,
    },
    pipelineParallel: {
      ...base.pipelineParallel,
      ...overrides.pipelineParallel,
    },
    dataParallel: {
      ...base.dataParallel,
      ...overrides.dataParallel,
    },
    expertParallel: {
      ...base.expertParallel,
      ...overrides.expertParallel,
    },
  };
}

// =============================================================================
// Utility Functions
// =============================================================================

function calculateTotalVram(config) {
  return config.gpuSpec.vramBytes * config.topology.gpuCount;
}

function calculateTotalCpuMemory(config) {
  return config.cpuSpec.memoryBytes * config.topology.cpuCount;
}

export function formatBytes(bytes) {
  if (typeof bytes !== 'number' || Number.isNaN(bytes)) return 'NaN';
  if (bytes < 0) return '0 B';
  if (bytes >= 1e12) {
    return `${(bytes / 1e12).toFixed(1)} TB`;
  } else if (bytes >= 1e9) {
    return `${(bytes / 1e9).toFixed(1)} GB`;
  } else if (bytes >= 1e6) {
    return `${(bytes / 1e6).toFixed(1)} MB`;
  } else if (bytes >= 1e3) {
    return `${(bytes / 1e3).toFixed(1)} KB`;
  }
  return `${bytes} B`;
}

function formatBandwidth(bytesPerSec) {
  return `${formatBytes(bytesPerSec)}/s`;
}
