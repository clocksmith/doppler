// =============================================================================
// Manifest Schema
// =============================================================================
export {
  RDRR_VERSION,
  SHARD_SIZE,
  TENSORS_FILENAME,
  MAX_HEADER_SIZE,
  HEADER_READ_SIZE,
  DEFAULT_RMS_NORM_EPS,
  DEFAULT_HIGH_PRECISION_EPS,
  DEFAULT_MANIFEST_INFERENCE,
  isV1Manifest,
  hasMoEConfig,
  validateManifestInference,
  hasInferenceConfig,
} from './manifest.schema.js';

// =============================================================================
// Kernel Path Schema
// =============================================================================
export {
  DEFAULT_ENTRY,
  DEFAULT_INPUT,
  DEFAULT_OUTPUT,
} from './kernel-path.schema.js';

// =============================================================================
// Inference Schema
// =============================================================================
export {
  computeGlobalLayers,
} from './inference.schema.js';

// =============================================================================
// Execution v1 Schema
// =============================================================================
export {
  EXECUTION_V1_SCHEMA_ID,
  DEFAULT_EXECUTION_V1_COMPUTE_DEFAULTS,
  DEFAULT_EXECUTION_V1_SESSION,
  DEFAULT_EXECUTION_V1_POLICIES,
  DEFAULT_EXECUTION_V1_PATCH,
  isExecutionV1Digest,
  hasExecutionV1,
  expandExecutionV1,
} from './execution-v1.schema.js';

// =============================================================================
// Conversion Schema
// =============================================================================
export {
  ConversionStage,
} from './conversion.schema.js';

// =============================================================================
// Browser Suite Metrics Schema
// =============================================================================
export {
  BROWSER_SUITE_METRICS_SCHEMA_VERSION,
  DEFAULT_BROWSER_SUITE_METRICS,
  validateBrowserSuiteMetrics,
} from './browser-suite-metrics.schema.js';

// =============================================================================
// Program Bundle Schema
// =============================================================================
export {
  PROGRAM_BUNDLE_SCHEMA_VERSION,
  PROGRAM_BUNDLE_SCHEMA_ID,
  PROGRAM_BUNDLE_HOST_SCHEMA_ID,
  PROGRAM_BUNDLE_HOST_JS_SUBSET,
  PROGRAM_BUNDLE_CAPTURE_PROFILE_SCHEMA_ID,
  PROGRAM_BUNDLE_REFERENCE_TRANSCRIPT_SCHEMA_ID,
  validateProgramBundle,
} from './program-bundle.schema.js';

// =============================================================================
// Support-Tier Registry Schema
// =============================================================================
export {
  SUPPORT_TIER_REGISTRY_SCHEMA_VERSION,
  SUPPORT_TIERS,
  SUPPORT_SCOPES,
  CLAIM_VISIBILITY_LEVELS,
  DEFAULT_SUPPORT_TIER_REGISTRY,
  validateSupportTierRegistry,
} from './support-tiers.schema.js';

// =============================================================================
// Conversion Report Schema
// =============================================================================
export {
  CONVERSION_REPORT_SCHEMA_VERSION,
  DEFAULT_CONVERSION_REPORT,
  validateConversionReport,
} from './conversion-report.schema.js';

// =============================================================================
// Converter Schema
// =============================================================================
export {
  DEFAULT_CONVERTER_QUANTIZATION_CONFIG,
  DEFAULT_CONVERTER_SHARDING_CONFIG,
  DEFAULT_CONVERTER_STREAMING_CONFIG,
  DEFAULT_CONVERTER_HTTP_CONFIG,
  DEFAULT_CONVERTER_WEIGHT_LAYOUT_CONFIG,
  DEFAULT_CONVERTER_MANIFEST_CONFIG,
  DEFAULT_CONVERTER_INFERENCE_CONFIG,
  DEFAULT_CONVERTER_OUTPUT_CONFIG,
  DEFAULT_GGUF_PARSER_DEFAULTS,
  DEFAULT_CONVERTER_EXECUTION_CONFIG,
  DEFAULT_CONVERTER_CONFIG,
  createConverterConfig,
} from './converter.schema.js';

// =============================================================================
// Loading Schema
// =============================================================================
export {
  DEFAULT_Q4K_LAYOUT,
  DEFAULT_SHARD_CACHE_CONFIG,
  DEFAULT_LOADER_MEMORY_BUDGET_CONFIG,
  DEFAULT_MEMORY_MANAGEMENT_CONFIG,
  DEFAULT_PREFETCH_CONFIG,
  DEFAULT_OPFS_PATH_CONFIG,
  DEFAULT_EXPERT_CACHE_CONFIG,
  DEFAULT_LOADING_CONFIG,
} from './loading.schema.js';

// =============================================================================
// Kernel Registry Schema
// =============================================================================
export {
  mergeBindings,
  resolveKernelConfig,
} from './kernel-registry.schema.js';

// =============================================================================
// Storage Schema
// =============================================================================
export {
  DEFAULT_QUOTA_CONFIG,
  DEFAULT_VRAM_ESTIMATION_CONFIG,
  DEFAULT_STORAGE_ALIGNMENT_CONFIG,
  DEFAULT_STORAGE_FULL_CONFIG,
} from './storage.schema.js';

// =============================================================================
// Distribution Schema
// =============================================================================
export {
  DEFAULT_DISTRIBUTION_CONFIG,
} from './distribution.schema.js';

// =============================================================================
// MoE Runtime Schema
// =============================================================================
export {
  DEFAULT_MOE_ROUTING_CONFIG,
  DEFAULT_MOE_CACHE_CONFIG,
  DEFAULT_MOE_RUNTIME_CONFIG,
} from './moe.schema.js';

// =============================================================================
// Diffusion Schema
// =============================================================================
export {
  DEFAULT_DIFFUSION_SCHEDULER_CONFIG,
  DEFAULT_DIFFUSION_LATENT_CONFIG,
  DEFAULT_DIFFUSION_TEXT_ENCODER_CONFIG,
  DEFAULT_DIFFUSION_DECODE_CONFIG,
  DEFAULT_DIFFUSION_TILING_CONFIG,
  DEFAULT_DIFFUSION_SWAPPER_CONFIG,
  DEFAULT_DIFFUSION_QUANTIZATION_CONFIG,
  DEFAULT_DIFFUSION_BACKEND_CONFIG,
  DEFAULT_DIFFUSION_CONFIG,
} from './diffusion.schema.js';

// =============================================================================
// Energy Schema
// =============================================================================
export {
  DEFAULT_ENERGY_STATE_CONFIG,
  DEFAULT_ENERGY_INIT_CONFIG,
  DEFAULT_ENERGY_TARGET_CONFIG,
  DEFAULT_ENERGY_LOOP_CONFIG,
  DEFAULT_ENERGY_DIAGNOSTICS_CONFIG,
  DEFAULT_ENERGY_QUINTEL_RULES,
  DEFAULT_ENERGY_QUINTEL_WEIGHTS,
  DEFAULT_ENERGY_QUINTEL_CLAMP,
  DEFAULT_ENERGY_QUINTEL_CONFIG,
  DEFAULT_ENERGY_CONFIG,
} from './energy.schema.js';

// =============================================================================
// KV Cache Schema
// =============================================================================
export {
  DEFAULT_KVCACHE_CONFIG,
  PAGED_LAYOUT_SEQ_LEN_THRESHOLD,
} from './kvcache.schema.js';

// =============================================================================
// GPU Cache Schema
// =============================================================================
export {
  DEFAULT_GPU_CACHE_CONFIG,
} from './gpu-cache.schema.js';

// =============================================================================
// Debug Schema
// =============================================================================
export {
  LOG_LEVELS,
  DEFAULT_LOG_OUTPUT_CONFIG,
  DEFAULT_LOG_HISTORY_CONFIG,
  DEFAULT_LOG_LEVEL_CONFIG,
  DEFAULT_TRACE_CONFIG,
  DEFAULT_LOADER_DEBUG_CONFIG,
  DEFAULT_MATMUL_DEBUG_CONFIG,
  DEFAULT_KERNEL_TRACE_CONFIG,
  DEFAULT_PIPELINE_DEBUG_CONFIG,
  DEFAULT_PROFILER_CONFIG,
  DEFAULT_PERF_GUARDS_CONFIG,
  DEFAULT_DEBUG_CONFIG,
} from './debug.schema.js';

// =============================================================================
// Benchmark Schema
// =============================================================================
export {
  DEFAULT_BENCHMARK_OUTPUT_CONFIG,
  DEFAULT_BENCHMARK_RUN_CONFIG,
  DEFAULT_BENCHMARK_STATS_CONFIG,
  DEFAULT_BENCHMARK_COMPARISON_CONFIG,
  DEFAULT_BENCHMARK_BASELINE_CONFIG,
  DEFAULT_BENCHMARK_CONFIG,
} from './benchmark.schema.js';

// =============================================================================
// Tooling Schema
// =============================================================================
export {
  TOOLING_INTENTS,
  TOOLING_DIAGNOSTICS,
  REFACTOR_RECEIPT_POLICIES,
  DEFAULT_TOOLING_CONFIG,
} from './tooling.schema.js';
export {
  validateRuntimeProfileMetadata,
  assertRuntimeProfileIntentCompatibility,
} from './runtime-profile.schema.js';

// =============================================================================
// Ecosystem Schema
// =============================================================================
export {
  ECOSYSTEM_STABILITY_MODES,
  ECOSYSTEM_RANKING_MODES,
  ECOSYSTEM_INCENTIVE_MODES,
  ECOSYSTEM_ANTISYBIL_COST,
  ECOSYSTEM_ENFORCEMENT_MODES,
  ECOSYSTEM_FAILOVER_TIERS,
  ECOSYSTEM_NOTARIZATION_ALGORITHMS,
  DEFAULT_ECOSYSTEM_CONFIG,
  mergeEcosystemConfig,
  createEcosystemConfig,
  validateEcosystemConfig,
} from './ecosystem.schema.js';

// =============================================================================
// Hot-Swap Schema
// =============================================================================
export {
  DEFAULT_HOTSWAP_CONFIG,
} from './hotswap.schema.js';

// =============================================================================
// Buffer Pool Schema
// =============================================================================
export {
  DEFAULT_BUFFER_POOL_BUCKET_CONFIG,
  DEFAULT_BUFFER_POOL_LIMITS_CONFIG,
  DEFAULT_BUFFER_POOL_ALIGNMENT_CONFIG,
  DEFAULT_BUFFER_POOL_BUDGET_CONFIG,
  DEFAULT_BUFFER_POOL_CONFIG,
} from './buffer-pool.schema.js';

// =============================================================================
// Memory Limits Schema
// =============================================================================
export {
  DEFAULT_HEAP_TESTING_CONFIG,
  DEFAULT_SEGMENT_TESTING_CONFIG,
  DEFAULT_ADDRESS_SPACE_CONFIG,
  DEFAULT_SEGMENT_ALLOCATION_CONFIG,
  DEFAULT_EMULATED_STORAGE_CONFIG,
  DEFAULT_MEMORY_LIMITS_CONFIG,
} from './memory-limits.schema.js';

// =============================================================================
// Bridge Schema
// =============================================================================
export {
  // Defaults
  DEFAULT_BRIDGE_TIMEOUT_CONFIG,
  DEFAULT_BRIDGE_CONFIG,
} from './bridge.schema.js';

// =============================================================================
// Adapter Schema
// =============================================================================
export {
  // Constants
  VALID_LORA_TARGET_MODULES,

  // Defaults
  DEFAULT_ADAPTER_VALIDATION_CONFIG,
  DEFAULT_ADAPTER_STACK_CONFIG,
  DEFAULT_ADAPTER_REGISTRY_CONFIG,
  DEFAULT_ADAPTER_CONFIG,
} from './adapter.schema.js';

// =============================================================================
// LoRA Schema
// =============================================================================
export {
  DEFAULT_LORA_CONFIG,
} from './lora.schema.js';

// =============================================================================
// Training Schema
// =============================================================================
export {
  DEFAULT_TRAINING_OPTIMIZER_CONFIG,
  DEFAULT_TRAINING_GRADIENT_CONFIG,
  DEFAULT_TRAINING_PRECISION_CONFIG,
  DEFAULT_TRAINING_ATTENTION_CONFIG,
  DEFAULT_TRAINING_LOSS_SCALING_CONFIG,
  DEFAULT_TRAINING_TELEMETRY_CONFIG,
  DEFAULT_TRAINING_SETTINGS,
} from './training.schema.js';

// =============================================================================
// Distill Training Schema
// =============================================================================
export {
  DISTILL_STAGE_VALUES,
  DISTILL_TRAINING_SCHEMA_VERSION,
  DEFAULT_DISTILL_FREEZE_GROUPS,
  DEFAULT_DISTILL_TRAINING_CONFIG,
  validateDistillTrainingConfig,
} from './distill-training.schema.js';

// =============================================================================
// UL Training Schema
// =============================================================================
export {
  UL_STAGE_VALUES,
  UL_TRAINING_SCHEMA_VERSION,
  DEFAULT_UL_NOISE_SCHEDULE,
  DEFAULT_UL_PRIOR_ALIGNMENT,
  DEFAULT_UL_DECODER_SIGMOID_WEIGHT,
  DEFAULT_UL_FREEZE_GROUPS,
  DEFAULT_UL_TRAINING_CONFIG,
  validateUlTrainingConfig,
} from './ul-training.schema.js';

// =============================================================================
// Training Metrics Schema
// =============================================================================
export {
  DEFAULT_TRAINING_METRICS_REPORT,
  validateTrainingMetricsEntry,
  validateTrainingMetricsReport,
} from './training-metrics.schema.js';

// =============================================================================
// Backward Registry Schema
// =============================================================================
export {
  validateBackwardRegistry,
} from './backward-registry.schema.js';

// =============================================================================
// Quantization Defaults Schema
// =============================================================================
export {
  // Defaults
  DEFAULT_QUANTIZATION_DEFAULTS,
} from './quantization-defaults.schema.js';

// =============================================================================
// Quantization Constants (Invariants)
// =============================================================================
export {
  // Constants
  QK_K,
  Q4K_BLOCK_BYTES,
  Q6K_BLOCK_BYTES,
  Q8_0_BLOCK_BYTES,
  Q8_0_BLOCK_SIZE,
  K_SCALE_SIZE,
  QK4_K_BLOCK_SIZE,

  // Functions
  padToQ4KBlock,
  q4kBlockCount,
} from './quantization.schema.js';

// =============================================================================
// Unit Constants (Invariants)
// =============================================================================
export {
  KB,
  MB,
  GB,
  formatBytes,
  formatBytesCompact,
} from './units.schema.js';

// =============================================================================
// Kernel Thresholds Schema
// =============================================================================
export {
  // Constants
  DTYPE_SIZES,
  getDtypeSize,

  // Defaults
  DEFAULT_MATMUL_THRESHOLDS,
  DEFAULT_RMSNORM_THRESHOLDS,
  DEFAULT_SOFTMAX_THRESHOLDS,
  DEFAULT_FFN_THRESHOLDS,
  DEFAULT_SAMPLE_THRESHOLDS,
  DEFAULT_ROPE_DEFAULTS,
  DEFAULT_ATTENTION_THRESHOLDS,
  DEFAULT_CAST_THRESHOLDS,
  DEFAULT_KERNEL_THRESHOLDS,

  // Functions
  getKernelThresholds,
  setKernelThresholds,
  resetKernelThresholds,
} from './kernel-thresholds.schema.js';

// =============================================================================
// Kernel Warmup Schema
// =============================================================================
export {
  DEFAULT_KERNEL_WARMUP_CONFIG,
} from './kernel-warmup.schema.js';

// =============================================================================
// Emulation Schema
// =============================================================================
export {
  // Factory
  createEmulationConfig,
  getChipProfile,

  // Defaults
  DEFAULT_GH200_GPU_SPEC,
  DEFAULT_GH200_CPU_SPEC,
  DEFAULT_NVLINK_SPEC,
  DEFAULT_NVLINK_C2C_SPEC,
  DEFAULT_PARALLELISM_CONFIG,
  DEFAULT_EMULATION_CONFIG,
} from './emulation.schema.js';

// =============================================================================
// Shared Runtime Schema
// =============================================================================
export {
  DEFAULT_KERNEL_REGISTRY_CONFIG,
  DEFAULT_SHARED_RUNTIME_CONFIG,
} from './shared-runtime.schema.js';
export {
  DEFAULT_HARNESS_CONFIG,
} from './harness.schema.js';
export {
  DEFAULT_SPECULATIVE_CONFIG,
} from './speculative.schema.js';

// =============================================================================
// Self-Speculation Schema
// =============================================================================
export {
  SPECULATION_MODES,
  SPECULATION_VERIFY_MODES,
  DEFAULT_SELF_SPECULATION_CONFIG,
  validateSelfSpeculationConfig,
} from './speculation-self.schema.js';

// =============================================================================
// Doppler Master Config
// =============================================================================
export {
  // Defaults
  DEFAULT_LARGE_WEIGHT_CONFIG,
  DEFAULT_CHAT_TEMPLATE_CONFIG,
  DEFAULT_RUNTIME_CONFIG,
  DEFAULT_DOPPLER_CONFIG,

  // Factory
  createDopplerConfig,
} from './doppler.schema.js';
