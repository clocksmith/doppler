

import { getRuntimeConfig } from '../../../config/runtime.js';

export class PipelineState {
  constructor() {
    // Components

    this.tokenizer = null;

    this.kvCache = null;

    this.linearAttentionRuntime = {
      schemaVersion: 1,
      layers: new Map(),
    };

    this.convLayerStates = new Map();

    this.moeRouter = null;

    this.speculativeDecoder = null;

    this.decodeBuffers = null;

    this.decodeRing = null;

    this.finitenessBuffer = null;

    this.sampleReadbackBuffer = null;

    // Emulation context (null when emulation is disabled).

    this.emulation = null;

    // Debug flags (combined for both layer and logits)

    this.debugFlags = {};

    this.decodeStepCount = 0;

    this.resolvedKernelPath = null;

    this.kernelPathSource = 'none';

    this.executionPlanState = null;
    this.resolvedRuntimeSession = null;

    this.disableRecordedLogits = false;

    this.disableFusedDecode = false;

    // Model state

    this.manifest = null;

    this.modelConfig = null;

    this.weights = new Map();

    this.expertWeights = new Map();

    // Runtime state

    this.isLoaded = false;

    this.isGenerating = false;

    this.currentSeqLen = 0;

    this.currentTokenIds = null;

    this.runtimeConfig = getRuntimeConfig();
    this.commandContext = null;
    this.observationContext = null;
    this.operatorDiagnostics = null;

    // DopplerLoader instance

    this.dopplerLoader = null;
    this.ownsDopplerLoader = false;

    // GPU context

    this.gpuContext = null;

    this.useGPU = false;

    // Memory and storage contexts

    this.memoryContext = null;

    this.storageContext = null;

    // Stats

    this.stats = {
      prefillTimeMs: 0,
      decodeTimeMs: 0,
      ttftMs: 0,
      loadTiming: null,
      pipelineLoadTiming: null,
      prefillTokens: 0,
      decodeTokens: 0,
      memoryUsageBytes: 0,
      tokensGenerated: 0,
      totalTimeMs: 0,
      decodeRecordMs: 0,
      decodeRecordOps: 0,
      decodeRecordPasses: 0,
      decodeRecordOpLabels: {},
      decodeSubmitWaitMs: 0,
      decodeReadbackWaitMs: 0,
      decodeReadbackMapWaitMs: 0,
      decodeReadbackCleanupMs: 0,
      decodeReadbackCopyMs: 0,
      prefillRecordMs: 0,
      prefillRecordOps: 0,
      prefillRecordPasses: 0,
      prefillRecordOpLabels: {},
      prefillSubmitWaitMs: 0,
      prefillProfileSteps: [],
      decodeProfileSteps: [],
      executionPlan: null,
      kernelPathId: null,
      kernelPathSource: 'none',
      operatorDiagnostics: null,
      attentionInputs: [],
      decodeMode: null,
      batchGuardReason: null,
      singleTokenSubmitWaitMs: 0,
      singleTokenReadbackWaitMs: 0,
      singleTokenReadbackMapWaitMs: 0,
      singleTokenReadbackCleanupMs: 0,
      singleTokenReadbackCopyMs: 0,
      singleTokenOrchestrationMs: 0,
      plePreparedTokenCacheHits: 0,
      plePreparedTokenCacheMisses: 0,
      plePreparedTokenCacheEntries: 0,
      plePreparedTokenCacheBytes: 0,
      pleHotVocabularyHits: 0,
      pleHotVocabularyMisses: 0,
    };


    this.batchingStats = {
      batchedForwardCalls: 0,
      unbatchedForwardCalls: 0,
      totalBatchedTimeMs: 0,
      totalUnbatchedTimeMs: 0,
      gpuSubmissions: 0,
      requestedBatchTokens: 0,
      effectiveBatchTokens: 0,
      executedBatchTokens: 0,
      resolvedBatchTokens: 0,
      maxBatchTokenCap: null,
      batchClampCount: 0,
    };

    // Base URL for loading assets

    this.baseUrl = null;

    // RoPE frequency buffers (global for full_attention layers)

    this.ropeFreqsCos = null;

    this.ropeFreqsSin = null;
    // Local RoPE frequencies for sliding_attention layers (different theta than global)

    this.ropeLocalCos = null;

    this.ropeLocalSin = null;

    // Debug

    this.debug = false;
    // Optional layer pipeline plan (JSON-configured)

    this.layerPipelinePlan = null;

    // Tied embeddings

    this.useTiedEmbeddings = false;

    this.embeddingVocabSize = null;

    this.embeddingTranspose = false;

    this.embeddingPostprocessor = null;

    // MoE router weights per layer

    this.layerRouterWeights = null;

    // LoRA adapter (optional)

    this.lora = null;
    this.revocationIdentity = null;

    // Vision state (manifest-gated)

    this.visionCapable = false;

    this.imageTokenId = null;

    this.visionConfig = null;

    this.visionWeights = null;
  }
}
