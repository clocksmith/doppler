import { getKernelConfig } from './kernel-configs.js';
import { getCachedPipeline, getPipelineFast, getPipelineBindGroupLayout } from './pipeline-cache.js';
import { getDevice } from '../device.js';
import { dispatchKernel, dispatchIndirect, recordDispatchIndirect } from './dispatch.js';
import { createUniformBufferWithView as createUniformBuffer } from './uniform-utils.js';
import { getUniformByteLength, writeUniformsFromObject } from './uniform-utils.js';

const dataBindingsByConfig = new WeakMap();

function getDataBindings(config) {
  let cached = dataBindingsByConfig.get(config);
  if (cached) {
    return cached;
  }
  cached = config.bindings
    .filter(b => b.type !== 'uniform')
    .slice()
    .sort((a, b) => a.index - b.index);
  dataBindingsByConfig.set(config, cached);
  return cached;
}

export async function unifiedKernelWrapper(
  opName,
  target,
  variant,
  bindings,
  uniforms,
  workgroups,
  constants = null,
  extraBindings = null,
  dispatchLabel = null
) {
  const device = target?.device || getDevice();
  const recorder = target && typeof target.beginComputePass === 'function' ? target : null;
  const config = getKernelConfig(opName, variant);
  const pipeline = getCachedPipeline(opName, variant, constants)
    ?? await getPipelineFast(opName, variant, null, constants);

  const uniformBuffer = createUniformBuffer(
    `${opName}_uniforms`,
    getUniformByteLength(config),
    (view) => writeUniformsFromObject(view, config, uniforms),
    recorder,
    device
  );

  const bindGroupEntries = [
    { binding: 0, resource: { buffer: uniformBuffer } }
  ];

  const dataBindings = getDataBindings(config);

  if (bindings.length !== dataBindings.length) {
    throw new Error(
      `Kernel "${opName}/${variant}" expected ${dataBindings.length} bindings ` +
      `(excluding uniforms) but got ${bindings.length}`
    );
  }

  for (let i = 0; i < bindings.length; i++) {
    const binding = bindings[i];
    const bindingConfig = dataBindings[i];
    let index = bindingConfig.index;

    // Some variants change output binding index (e.g. gather f16 output uses binding 4).
    if (bindingConfig.name === 'output' && config.variantMetadata?.outputBinding != null) {
      index = config.variantMetadata.outputBinding;
    }

    const buffer = binding?.buffer || binding;
    const isGpuBuffer = buffer && (
      typeof GPUBuffer === 'undefined'
        ? true
        : buffer instanceof GPUBuffer
    );
    if (!isGpuBuffer) {
      const bindingLabel = binding?.label ?? buffer?.label ?? 'unknown';
      const bufferType = buffer === null ? 'null' : buffer === undefined ? 'undefined' : buffer.constructor?.name || typeof buffer;
      throw new Error(
        `Kernel "${opName}/${variant}" binding "${bindingConfig.name}" (index ${index}) requires a GPUBuffer ` +
        `(label=${bindingLabel}, type=${bufferType}).`
      );
    }

    bindGroupEntries.push({
      binding: index,
      resource: { buffer }
    });
  }

  // Append extra bindings not tracked in registry (e.g. OUTPUT_PRENORM residual_sum_output)
  if (extraBindings) {
    for (const extra of extraBindings) {
      const buf = extra.buffer?.buffer || extra.buffer;
      bindGroupEntries.push({
        binding: extra.binding,
        resource: { buffer: buf },
      });
    }
  }

  try {
    const bindGroup = device.createBindGroup({
      label: `${opName}_bind_group`,
      layout: getPipelineBindGroupLayout(pipeline, 0),
      entries: bindGroupEntries,
    });

    const label = typeof dispatchLabel === 'string' && dispatchLabel.length > 0
      ? dispatchLabel
      : opName;
    if (workgroups && typeof workgroups === 'object' && workgroups.indirectBuffer) {
      const indirectOffset = workgroups.indirectOffset ?? 0;
      if (recorder) {
        recordDispatchIndirect(recorder, pipeline, bindGroup, workgroups.indirectBuffer, indirectOffset, label);
      } else {
        dispatchIndirect(device, pipeline, bindGroup, workgroups.indirectBuffer, indirectOffset, label);
      }
    } else {
      dispatchKernel(target, pipeline, bindGroup, workgroups, label);
    }
  } catch (error) {
    if (!recorder) {
      uniformBuffer.destroy();
    }
    throw error;
  }

  if (!recorder) {
    device.queue.onSubmittedWorkDone()
      .then(() => {
        uniformBuffer.destroy();
      })
      .catch(() => {
        uniformBuffer.destroy();
      });
  }

  return true;
}
