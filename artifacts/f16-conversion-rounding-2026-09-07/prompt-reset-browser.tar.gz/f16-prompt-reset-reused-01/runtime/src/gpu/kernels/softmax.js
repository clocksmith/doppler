
import { getKernelCapabilities } from '../device.js';
import { acquireBuffer, releaseBuffer } from '../../memory/buffer-pool.js';
import { createTensor } from '../tensor.js';
import { unifiedKernelWrapper } from './kernel-execution.js';
import { createPipeline } from './pipeline-cache.js';
import { createUniformBufferWithView } from './uniform-utils.js';
import { createBindGroupWithValidation } from './bind-group-validation.js';
import { dispatchKernel } from './dispatch.js';
import { trace } from '../../debug/index.js';
import { getKernelThresholds } from '../../config/schema/index.js';
import { selectRuleValue } from './rule-registry.js';
import { getDevice } from '../device.js';

function selectSoftmaxVariant(innerSize) {
  const caps = getKernelCapabilities();
  const hasSubgroups = caps?.hasSubgroups ?? false;
  const { smallThreshold } = getKernelThresholds().softmax;
  const isSmall = innerSize <= smallThreshold;
  return selectRuleValue('softmax', 'variant', { hasSubgroups, isSmall });
}

async function _softmax(target, input, axis, options = {}) {
  const { batchSize = 1, size, seqLen, temperature = 1.0, outputBuffer = null } = options;
  if (input.dtype !== 'f32') {
    throw new Error(`Softmax requires f32 input, got ${input.dtype}.`);
  }

  const bytesPerElement = 4;
  const inferredSize = size || seqLen || (input.buffer.size / (batchSize * bytesPerElement));
  const variant = selectSoftmaxVariant(inferredSize);
  trace.kernels(`Softmax: size=${inferredSize}, variant=${variant}`);

  const outputSize = batchSize * inferredSize * bytesPerElement;
  const output = outputBuffer || acquireBuffer(outputSize, undefined, 'softmax_output');
  const ownedOutput = outputBuffer ? null : output;

  try {
    await unifiedKernelWrapper(
      'softmax', target, variant,
      [input, output],
      { inner_size: inferredSize, outer_size: batchSize, temperature },
      batchSize
    );
  } catch (error) {
    if (ownedOutput) {
      releaseBuffer(ownedOutput);
    }
    throw error;
  }

  return createTensor(output, 'f32', [batchSize, inferredSize], 'softmax_output');
}

export async function runSoftmax(input, axis, options = {}) {
  return _softmax(null, input, axis, options);
}

export async function recordSoftmax(recorder, input, axis, options = {}) {
  return _softmax(recorder, input, axis, options);
}

export async function runSoftmaxTopK(logits, numTokens, numExperts, topK, options = {}) {
  const device = getDevice();
  const {
    normalize = true,
    modelType = null,
  } = options;
  const inputDtype = options.inputDtype;
  const weightsDtype = options.weightsDtype;

  if (inputDtype !== 'f16' && inputDtype !== 'f32') {
    throw new Error(`SoftmaxTopK requires options.inputDtype to be "f16" or "f32", got ${String(inputDtype)}.`);
  }
  if (weightsDtype !== 'f16' && weightsDtype !== 'f32') {
    throw new Error(`SoftmaxTopK requires options.weightsDtype to be "f16" or "f32", got ${String(weightsDtype)}.`);
  }

  if (weightsDtype === 'f16' && inputDtype !== 'f16') {
    throw new Error('SoftmaxTopK f16 weights require f16 logits');
  }

  const caps = getKernelCapabilities();
  const variant = selectRuleValue('softmax', 'topkVariant', {
    modelType,
    inputDtype,
    weightsDtype,
    hasF16: caps?.hasF16 ?? false,
    hasSubgroups: caps?.hasSubgroups ?? false,
  });
  const pipeline = await createPipeline('topk', variant);

  const indicesSize = numTokens * topK * 4;
  const weightsBytesPerElement = weightsDtype === 'f16' ? 2 : 4;
  const weightsSize = numTokens * topK * weightsBytesPerElement;

  const indices = acquireBuffer(indicesSize, undefined, 'softmax_topk_indices');
  const weights = acquireBuffer(weightsSize, undefined, 'softmax_topk_weights');
  let completed = false;

  const uniformBuffer = createUniformBufferWithView(
    'softmax_topk_uniforms', 16,
    (view) => {
      view.setUint32(0, numTokens, true);
      view.setUint32(4, numExperts, true);
      view.setUint32(8, topK, true);
      view.setUint32(12, normalize ? 1 : 0, true);
    },
    null, device
  );

  try {
    const bindGroup = await createBindGroupWithValidation(device, {
      label: 'softmax_topk_bind_group',
      layout: pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: { buffer: logits } },
        { binding: 2, resource: { buffer: indices } },
        { binding: 3, resource: { buffer: weights } },
      ],
    }, `topk:${variant}`);

    dispatchKernel(null, pipeline, bindGroup, numTokens, 'softmax_topk');
    completed = true;
    return { indices, weights };
  } finally {
    uniformBuffer.destroy();
    if (!completed) {
      releaseBuffer(indices);
      releaseBuffer(weights);
    }
  }
}
