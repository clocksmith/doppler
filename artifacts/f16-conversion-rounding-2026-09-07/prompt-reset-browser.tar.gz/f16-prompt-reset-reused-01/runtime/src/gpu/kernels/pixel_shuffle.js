import { acquireBuffer, releaseBuffer } from '../../memory/buffer-pool.js';
import { createTensor, dtypeBytes } from '../tensor.js';
import { unifiedKernelWrapper } from './kernel-execution.js';
import { selectRuleValue } from './rule-registry.js';
import { WORKGROUP_SIZES } from './constants.js';

function selectPixelShuffleVariant(dtype) {
  return selectRuleValue('pixel_shuffle', 'variant', { dtype });
}

async function _pixelShuffle(target, input, options = {}) {
  const {
    outChannels, outHeight, outWidth,
    gridWidth, gridHeight, patchSize,
    patchChannels, outputBuffer = null,
  } = options;

  if (!Number.isFinite(outChannels) || !Number.isFinite(outHeight) || !Number.isFinite(outWidth) ||
      !Number.isFinite(gridWidth) || !Number.isFinite(gridHeight) || !Number.isFinite(patchSize)) {
    throw new Error('PixelShuffle requires explicit dimensions.');
  }

  const inferredPatchChannels = patchChannels ?? outChannels * patchSize * patchSize;
  const variant = selectPixelShuffleVariant(input.dtype);
  const bytesPerElement = dtypeBytes(input.dtype);
  const outputSize = outChannels * outHeight * outWidth * bytesPerElement;
  const output = outputBuffer || acquireBuffer(outputSize, undefined, 'pixel_shuffle_output');
  const ownedOutput = outputBuffer ? null : output;

  try {
    await unifiedKernelWrapper(
      'pixel_shuffle', target, variant,
      [input, output],
      {
        out_channels: outChannels, out_height: outHeight, out_width: outWidth,
        grid_width: gridWidth, grid_height: gridHeight, patch_size: patchSize,
        patch_channels: inferredPatchChannels, _pad0: 0,
      },
      [Math.ceil((outHeight * outWidth) / WORKGROUP_SIZES.DEFAULT), outChannels, 1]
    );

    return createTensor(output, input.dtype, [outChannels, outHeight, outWidth], 'pixel_shuffle_output');
  } catch (error) {
    if (ownedOutput) {
      releaseBuffer(ownedOutput);
    }
    throw error;
  }
}

export async function runPixelShuffle(input, options = {}) {
  return _pixelShuffle(null, input, options);
}

export async function recordPixelShuffle(recorder, input, options = {}) {
  return _pixelShuffle(recorder, input, options);
}
