
import { acquireBuffer, releaseBuffer } from '../../memory/buffer-pool.js';
import { createTensor, inferOutputDtype, dtypeBytes } from '../tensor.js';
import { WORKGROUP_SIZES, VEC4_ELEMENTS_PER_WG } from './constants.js';
import { unifiedKernelWrapper } from './kernel-execution.js';
import { castF16ToF32, castF32ToF16, recordCastF16ToF32, recordCastF32ToF16 } from './cast.js';
import { selectRuleValue } from './rule-registry.js';
import { assertImplicitDtypeTransitionAllowed } from '../../config/dtype-transition-contract.js';


function selectResidualVariant(outputDtype, useVec4) {
  return selectRuleValue(
    'residual',
    'residualVariant',
    { outputDtype, useVec4 }
  );
}

function selectBiasAddVariant(dataDtype, biasDtype) {
  return selectRuleValue(
    'residual',
    'biasAddVariant',
    { dataDtype, biasDtype }
  );
}

async function alignResidualInputs(a, b, recorder, executionPolicies = null) {
  if (a.dtype === b.dtype) {
    return { a, b, temps: [] };
  }
  if (a.dtype === 'f16' && b.dtype === 'f32') {
    assertImplicitDtypeTransitionAllowed({
      executionPolicies,
      fromDtype: a.dtype,
      toDtype: 'f32',
      op: 'residual_add',
      detail: 'Residual add would widen one input implicitly.',
    });
    const casted = recorder ? await recordCastF16ToF32(recorder, a) : await castF16ToF32(a);
    return { a: casted, b, temps: [casted.buffer] };
  }
  if (a.dtype === 'f32' && b.dtype === 'f16') {
    assertImplicitDtypeTransitionAllowed({
      executionPolicies,
      fromDtype: b.dtype,
      toDtype: 'f32',
      op: 'residual_add',
      detail: 'Residual add would widen one input implicitly.',
    });
    const casted = recorder ? await recordCastF16ToF32(recorder, b) : await castF16ToF32(b);
    return { a, b: casted, temps: [casted.buffer] };
  }
  return { a, b, temps: [] };
}

async function alignBiasTensor(data, bias, recorder, executionPolicies = null) {
  if (data.dtype === bias.dtype) {
    return { bias, temps: [] };
  }
  if (data.dtype === 'f16' && bias.dtype === 'f32') {
    assertImplicitDtypeTransitionAllowed({
      executionPolicies,
      fromDtype: bias.dtype,
      toDtype: 'f16',
      op: 'bias_add',
      detail: 'Bias add would narrow the bias tensor implicitly.',
    });
    const casted = recorder ? await recordCastF32ToF16(recorder, bias) : await castF32ToF16(bias);
    return { bias: casted, temps: [casted.buffer] };
  }
  if (data.dtype === 'f32' && bias.dtype === 'f16') {
    assertImplicitDtypeTransitionAllowed({
      executionPolicies,
      fromDtype: bias.dtype,
      toDtype: 'f32',
      op: 'bias_add',
      detail: 'Bias add would widen the bias tensor implicitly.',
    });
    const casted = recorder ? await recordCastF16ToF32(recorder, bias) : await castF16ToF32(bias);
    return { bias: casted, temps: [casted.buffer] };
  }
  return { bias, temps: [] };
}

function cleanupTemps(temps, recorder) {
  for (const temp of temps) {
    if (recorder) {
      recorder.trackTemporaryBuffer(temp);
    } else {
      releaseBuffer(temp);
    }
  }
}

function planResidualDispatch(target, size, elementsPerWorkgroup) {
  const device = target?.device;
  const maxPerDim = Number.isFinite(device?.limits?.maxComputeWorkgroupsPerDimension)
    ? device.limits.maxComputeWorkgroupsPerDimension
    : 65535;
  const dispatchStride = Math.min(size, maxPerDim * elementsPerWorkgroup);
  return {
    dispatchStride,
    workgroups: [
      Math.ceil(dispatchStride / elementsPerWorkgroup),
      Math.ceil(size / dispatchStride),
      1,
    ],
  };
}

function resolveResidualOutputScale(outputScale) {
  if (outputScale == null) {
    return 1;
  }
  const value = Number(outputScale);
  if (!Number.isFinite(value)) {
    throw new Error(`[Residual] outputScale must be finite; got "${String(outputScale)}".`);
  }
  return value;
}

async function _residualAdd(target, a, b, size, options = {}) {
  const recorder = target && typeof target.beginComputePass === 'function' ? target : null;
  const { useVec4 = true, outputBuffer = null } = options;
  const outputScale = resolveResidualOutputScale(options.outputScale);
  const ownsOutput = outputBuffer == null;

  const { a: aAligned, b: bAligned, temps } = await alignResidualInputs(
    a,
    b,
    recorder,
    options.executionPolicies ?? null
  );
  const outputDtype = inferOutputDtype(aAligned, bAligned);
  const bytesPerElement = dtypeBytes(outputDtype);

  const variant = selectResidualVariant(outputDtype, useVec4);
  const outputSize = size * bytesPerElement;
  const output = outputBuffer || acquireBuffer(outputSize, undefined, 'residual_output');

  const dispatchPlan = planResidualDispatch(
    target,
    size,
    useVec4 ? VEC4_ELEMENTS_PER_WG : WORKGROUP_SIZES.DEFAULT
  );

  try {
    await unifiedKernelWrapper(
      'residual', target, variant,
      [aAligned, bAligned, output],
      { size, scale: outputScale, _pad1: dispatchPlan.dispatchStride, _pad2: 0 },
      dispatchPlan.workgroups
    );
    return createTensor(output, outputDtype, [size], 'residual_output');
  } catch (error) {
    if (ownsOutput) {
      releaseBuffer(output);
    }
    throw error;
  } finally {
    cleanupTemps(temps, recorder);
  }
}

async function _biasAdd(target, data, bias, numTokens, dim, options = {}) {
  const recorder = target && typeof target.beginComputePass === 'function' ? target : null;
  const { dataOffset = 0, biasOffset = 0 } = options;

  const { bias: biasAligned, temps } = await alignBiasTensor(
    data,
    bias,
    recorder,
    options.executionPolicies ?? null
  );
  const variant = selectBiasAddVariant(data.dtype, biasAligned.dtype);
  const device = target?.device;
  const maxPerDim = Number.isFinite(device?.limits?.maxComputeWorkgroupsPerDimension)
    ? device.limits.maxComputeWorkgroupsPerDimension
    : 65535;
  const tokenStride = Math.min(numTokens, maxPerDim);

  const workgroups = [
    Math.ceil(dim / WORKGROUP_SIZES.DEFAULT),
    tokenStride,
    Math.ceil(numTokens / tokenStride),
  ];

  try {
    await unifiedKernelWrapper(
      'bias_add', target, variant,
      [data, biasAligned],
      {
        num_tokens: numTokens,
        dim,
        data_offset: dataOffset,
        bias_offset: biasOffset,
        token_stride: tokenStride,
        _pad0: 0,
        _pad1: 0,
        _pad2: 0,
      },
      workgroups
    );
    return createTensor(data.buffer, data.dtype, [numTokens, dim], 'bias_add_output');
  } finally {
    cleanupTemps(temps, recorder);
  }
}

export async function runResidualAdd(a, b, size, options = {}) {
  return _residualAdd(null, a, b, size, options);
}

export async function recordResidualAdd(recorder, a, b, size, options = {}) {
  return _residualAdd(recorder, a, b, size, options);
}

export async function runBiasAdd(data, bias, numTokens, dim, options = {}) {
  return _biasAdd(null, data, bias, numTokens, dim, options);
}

export async function recordBiasAdd(recorder, data, bias, numTokens, dim, options = {}) {
  return _biasAdd(recorder, data, bias, numTokens, dim, options);
}
