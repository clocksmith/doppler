

// Utilities
export {
  KERNEL_CONFIGS,
  getKernelConfig,
} from './kernel-configs.js';
export {
  validateAttentionLimits,
  hasRequiredFeatures,
} from './feature-check.js';
export {
  loadShaderSource,
  compileShader,
} from './shader-cache.js';
export {
  getOrCreateBindGroupLayout,
  getOrCreatePipelineLayout,
  createPipeline,
} from './pipeline-cache.js';
export {
  clearKernelCaches,
  clearPipelineCache,
  getCacheStats,
} from './kernel-cache-lifecycle.js';
export { prewarmKernels } from './kernel-prewarm.js';

// Matrix Multiplication
export {
  selectMatmulKernel,
  createMatmulBindGroupLayout,
  runMatmul,
  recordMatmul,
  isFusedQ4KDisabled,
} from './matmul.js';
export {
  recordLmHeadArgmax,
  recordLmHeadArgmaxF16,
} from './lm-head-argmax.js';
export {
  runLmHeadSelectLogitsF16,
} from './lm-head-select-logits.js';

// Dequantization
export {
  selectDequantKernel,
  createDequantBindGroupLayout,
  dequantize,
  dequantizeRowwise,
  dequantizeQ6K,
  dequantizeMXFP4,
  dequantizeMXFP4Expert,
  recordDequantize,
} from './dequant.js';

// Attention
export {
  runAttention,
  recordAttention,
  runAttentionTiered,
  recordAttentionTiered,
  runAttentionTieredQuant,
  recordAttentionTieredQuant,
  runAttentionBDPA,
  recordAttentionBDPA,
} from './attention.js';

// RMSNorm
export {
  selectRMSNormKernel,
  runRMSNorm,
  recordRMSNorm,
} from './rmsnorm.js';
export {
  canUseRMSNormQK,
  runRMSNormQK,
  recordRMSNormQK,
} from './rmsnorm-qk.js';
export {
  canUseSplitQKVRMSNormQK,
  runSplitQKVRMSNormQK,
  recordSplitQKVRMSNormQK,
} from './split-qkv-rmsnorm-qk.js';
export {
  canUseSplitQKVRMSNormRoPEQK,
  runSplitQKVRMSNormRoPEQK,
  recordSplitQKVRMSNormRoPEQK,
} from './split-qkv-rmsnorm-rope-qk.js';
export {
  RMSNORM_PAIR_CACHE_LIMIT,
  runSandwichRMSNormPair,
  recordSandwichRMSNormPair,
  runResidualNextRMSNormPair,
  recordResidualNextRMSNormPair,
} from './rmsnorm-pair.js';

// LayerNorm
export {
  selectLayerNormKernel,
  runLayerNorm,
  recordLayerNorm,
} from './layernorm.js';

// Softmax
export {
  runSoftmax,
  runSoftmaxTopK,
  recordSoftmax,
} from './softmax.js';

export {
  runSoftEmbeddingSplitF16,
  runSoftEmbeddingLogitsF16,
} from './soft-embedding.js';

export {
  runDiffusionGemmaCanvasStats,
} from './diffusion-gemma-sampling.js';
export {
  runGemma4RouteQ4MatmulF16A,
  runScatterAddRoutesF16ExpertScale,
} from './gemma4-route-expert.js';

// KV Quantization
export {
  runKVQuantize,
  recordKVQuantize,
} from './kv-quantize.js';

export {
  runKVCacheWriteF32ToF16,
  recordKVCacheWriteF32ToF16,
} from './kv-cache-write.js';

// Loss
export {
  runCrossEntropyLoss,
  recordCrossEntropyLoss,
} from './cross_entropy_loss.js';

// RoPE
export {
  runRoPE,
  recordRoPE,
} from './rope.js';
export {
  canUseRoPEQK,
  runRoPEQK,
  recordRoPEQK,
} from './rope-qk.js';

// SiLU Activation
export {
  runSiLU,
  runSwiGLURowsplitBias,
  runSiLURowSplit,
  recordSiLU,
  recordSiLURowSplit,
} from './silu.js';

// GeLU Activation
export {
  runGeLU,
  recordGeLU,
} from './gelu.js';

// Scale (Element-wise Multiply by Scalar)
export {
  selectScaleKernel,
  runScale,
  recordScale,
} from './scale.js';

// Clamp
export {
  runClamp,
  recordClamp,
} from './clamp.js';

// Static activation quantize/dequantize
export {
  runActivationStaticQdq,
  recordActivationStaticQdq,
} from './activation-static-qdq.js';

// Energy (EBM helpers)
export {
  runEnergyEval,
  recordEnergyEval,
  runEnergyUpdate,
  recordEnergyUpdate,
  runEnergyQuintelUpdate,
  recordEnergyQuintelUpdate,
  runEnergyQuintelReduce,
  recordEnergyQuintelReduce,
  runEnergyQuintelGrad,
  recordEnergyQuintelGrad,
} from './energy.js';

// Conv2D
export {
  runConv2D,
  recordConv2D,
} from './conv2d.js';

export {
  runDepthwiseConv2D,
  recordDepthwiseConv2D,
} from './depthwise_conv2d.js';

export {
  runDepthwiseConv1D,
  recordDepthwiseConv1D,
} from './depthwise_conv1d.js';

export {
  runGroupedPointwiseConv2D,
  recordGroupedPointwiseConv2D,
} from './grouped_pointwise_conv2d.js';

// Gather (Embedding Lookup)
export {
  runGather,
  recordGather,
  runGatherSplit4,
  recordGatherSplit4,
  runGatherSplit8,
  recordGatherSplit8,
  runGatherSplit,
  recordGatherSplit,
} from './gather.js';

// GroupNorm
export {
  runGroupNorm,
  recordGroupNorm,
} from './groupnorm.js';

// Modulate
export {
  runModulate,
  recordModulate,
} from './modulate.js';

// Residual Connections
export {
  runResidualAdd,
  runBiasAdd,
  recordResidualAdd,
  recordBiasAdd,
} from './residual.js';

// Pixel Shuffle
export {
  runPixelShuffle,
  recordPixelShuffle,
} from './pixel_shuffle.js';

// Upsample2D
export {
  runUpsample2D,
  recordUpsample2D,
} from './upsample2d.js';

// Mixture of Experts
export {
  runTopK,
  runMoEGather,
  runMoEBuildTokenOffsets,
  recordMoEBuildTokenOffsets,
  runScatterAdd,
  runScatterAddDynamic,
} from './moe.js';

// Type Casting
export {
  castF32ToF16,
  recordCastF32ToF16,
  castF16ToF32,
  recordCastF16ToF32,
  runBF16ToF32,
  runBF16ToF16,
} from './cast.js';

// GPU-Side Sampling
export {
  runArgmax,
  runGPUSample,
  recordArgmax,
  isGPUSamplingAvailable,
} from './sample.js';

export {
  runLinearAttention,
  recordLinearAttention,
} from './linear_attention.js';

export {
  runRepeatChannels,
  recordRepeatChannels,
} from './repeat_channels.js';

export {
  runReLU,
  recordReLU,
} from './relu.js';

// Fused FFN (Tier 2 P0)
export {
  runFusedFFN,
  recordFusedFFN,
  runFusedFFNFromRMSNormStats,
  recordFusedFFNFromRMSNormStats,
  calculateFusedFFNSavings,
} from './fused_ffn.js';

export {
  runRMSNormStats,
  recordRMSNormStats,
} from './rmsnorm-stats.js';

// Fused Matmul + RMSNorm (P0 - 1.2-1.5x decode speedup)
export {
  selectMatmulRMSNormFusedVariant,
  runMatmulRMSNormFused,
  recordMatmulRMSNormFused,
  shouldUseFusedMatmulRMSNorm,
} from './fused_matmul_rmsnorm.js';

// Re-export for convenience in layer.ts integration
export { recordMatmulRMSNormFused as doRecordMatmulRMSNormFused } from './fused_matmul_rmsnorm.js';

// Fused Matmul + Residual (P1 - eliminates 1 dispatch per layer for attention output)
export {
  runMatmulResidualFused,
  recordMatmulResidualFused,
  shouldUseFusedMatmulResidual,
} from './fused_matmul_residual.js';

// Re-export CommandRecorder types for convenience
export {
  CommandRecorder,
  createCommandRecorder,
  createProfilingRecorder,
} from '../command-recorder.js';

// Split QKV
export {
  runSplitQKV,
  recordSplitQKV,
} from './split_qkv.js';

export { runVisionPatchEmbed } from './vision-patch-embed.js';
export { runVisionSpatialMerge } from './vision-spatial-merge.js';
export { runVisionRope2D } from './vision-rope-2d.js';
export { runVisionAveragePool } from './vision-average-pool.js';
export { runVisionPositionEmbedding } from './vision-position-embedding.js';

// Split Q and Gate (de-interleave attentionOutputGate q_proj output)
export {
  runSplitQG,
  recordSplitQG,
} from './split_qg.js';

// Transpose
export {
  runTranspose,
  recordTranspose,
} from './transpose.js';

// Training Backward Kernels
export {
  runEmbedBackward,
  recordEmbedBackward,
  runBiasAddBackward,
  runUpsample2DBackward,
  runGroupNormBackward,
  runConv2DBackward,
  runMatmulBackward,
  recordMatmulBackward,
  runSoftmaxBackward,
  recordSoftmaxBackward,
  runRmsNormBackward,
  recordRmsNormBackward,
  runGatedRmsNormBackward,
  recordGatedRmsNormBackward,
  runCausalConv1dSiluBackward,
  recordCausalConv1dSiluBackward,
  runGatedDeltaRecurrentBackward,
  runLayerNormBackward,
  recordLayerNormBackward,
  runAttentionBackward,
  recordAttentionBackward,
  runRoPEBackward,
  recordRoPEBackward,
  runSiluBackward,
  recordSiluBackward,
  runGeluBackward,
  recordGeluBackward,
  runScaleBackward,
  recordScaleBackward,
  runCrossEntropyBackward,
  recordCrossEntropyBackward,
  runAdam,
  recordAdam,
} from './backward/index.js';

// Re-export profiling utilities
