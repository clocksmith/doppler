import { readdir, readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

import { writeJsonArtifact } from './operator-artifacts.js';

async function listCheckpointMarkers(checkpointsDir) {
  const absoluteDir = resolve(String(checkpointsDir));
  const entries = await readdir(absoluteDir, { withFileTypes: true });
  const markers = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }
    const entryPath = join(absoluteDir, entry.name);
    const markerPath = join(entryPath, 'checkpoint.complete.json');
    try {
      await readFile(markerPath, 'utf8');
      markers.push(markerPath);
      continue;
    } catch (error) {
      if (error?.code !== 'ENOENT') {
        throw error;
      }
    }
    markers.push(...await listCheckpointMarkers(entryPath));
  }
  return markers.sort((left, right) => left.localeCompare(right));
}

async function ensureDirectoryExists(directoryPath) {
  try {
    const entries = await readdir(directoryPath, { withFileTypes: true });
    return Array.isArray(entries);
  } catch (error) {
    if (error?.code === 'ENOENT') {
      return false;
    }
    throw error;
  }
}

async function readProcessedManifest(manifestPath) {
  try {
    const raw = await readFile(manifestPath, 'utf8');
    const parsed = JSON.parse(raw);
    const processed = Array.isArray(parsed?.processedCheckpointMarkers)
      ? parsed.processedCheckpointMarkers.filter((entry) => typeof entry === 'string')
      : [];
    return new Set(processed);
  } catch (error) {
    if (error?.code === 'ENOENT') {
      return new Set();
    }
    throw error;
  }
}

function createWatchResult(processed, manifestPath, aborted = false) {
  return {
    ok: true,
    processedCount: processed.size,
    manifestPath,
    aborted,
  };
}

async function waitForPollInterval(pollIntervalMs, signal) {
  if (!signal) {
    await new Promise((resolvePromise) => setTimeout(resolvePromise, pollIntervalMs));
    return true;
  }
  if (signal.aborted) {
    return false;
  }
  return new Promise((resolvePromise) => {
    const onAbort = () => {
      clearTimeout(timer);
      resolvePromise(false);
    };
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolvePromise(true);
    }, pollIntervalMs);
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

export async function watchFinalizedCheckpoints(options) {
  const checkpointsDir = resolve(String(options.checkpointsDir));
  const manifestPath = resolve(String(options.manifestPath));
  const pollIntervalMs = Number.isFinite(options.pollIntervalMs)
    ? Math.max(100, Math.floor(options.pollIntervalMs))
    : 2000;
  const stopWhenIdle = options.stopWhenIdle === true;
  const onCheckpoint = typeof options.onCheckpoint === 'function'
    ? options.onCheckpoint
    : null;
  const signal = options.signal ?? null;
  if (!onCheckpoint) {
    throw new Error('watchFinalizedCheckpoints requires onCheckpoint(markerPath).');
  }

  const processed = await readProcessedManifest(manifestPath);
  let idlePolls = 0;
  for (;;) {
    if (signal?.aborted) {
      return createWatchResult(processed, manifestPath, true);
    }
    const checkpointsExist = await ensureDirectoryExists(checkpointsDir);
    const markers = checkpointsExist
      ? await listCheckpointMarkers(checkpointsDir)
      : [];
    let sawNewMarker = false;
    for (const markerPath of markers) {
      if (processed.has(markerPath)) continue;
      sawNewMarker = true;
      await onCheckpoint(markerPath);
      processed.add(markerPath);
      await writeJsonArtifact(manifestPath, {
        artifactType: 'training_checkpoint_watch_manifest',
        schemaVersion: 1,
        generatedAt: new Date().toISOString(),
        processedCheckpointMarkers: [...processed].sort((left, right) => left.localeCompare(right)),
      });
    }
    if (!sawNewMarker) {
      idlePolls += 1;
      if (stopWhenIdle && idlePolls > 0) {
        return createWatchResult(processed, manifestPath);
      }
    } else {
      idlePolls = 0;
    }
    const shouldContinue = await waitForPollInterval(pollIntervalMs, signal);
    if (!shouldContinue) {
      return createWatchResult(processed, manifestPath, true);
    }
  }
}
