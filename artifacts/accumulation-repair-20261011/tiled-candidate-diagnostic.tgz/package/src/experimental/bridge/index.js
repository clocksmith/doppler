

export {
  MAGIC,
  HEADER_SIZE,
  MAX_CHUNK_SIZE,
  Command,
  Flag,
  ErrorCode,
  CMD,
  FLAGS,
  ERROR_CODES,
  encodeMessage,
  decodeHeader,
  createReadRequest,
  createAck,
  parseReadResponse,
  parseErrorResponse,
} from './protocol.js';

export {
  ExtensionBridgeClient,
  BridgeStatus,
  getBridgeClient,
  isBridgeAvailable,
} from './extension-client.js';


export async function createBridgeClient(extensionId = null) {
  const { getBridgeClient, isBridgeAvailable } = await import('./extension-client.js');

  if (!isBridgeAvailable()) {
    throw new Error('Native bridge not available - Chrome extension API required');
  }

  const client = getBridgeClient();
  await client.connect(extensionId);
  return client;
}


export async function readFileNative(path, offset = 0, length = 0, extensionId = null) {
  const { getBridgeClient } = await import('./extension-client.js');
  const client = getBridgeClient();

  if (!client.isConnected()) {
    await client.connect(extensionId);
  } else if ((extensionId ?? null) !== (client.getExtensionId?.() ?? null)) {
    throw new Error('Bridge client already connected to a different extension target');
  }

  return client.read(path, offset, length);
}
