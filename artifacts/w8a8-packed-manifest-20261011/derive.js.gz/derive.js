import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = process.cwd();
const owner = file => import(pathToFileURL(path.join(root, file)).href);
const { buildArtifactIdentity } = await owner('src/converter/artifact-identity.js');
const { validateManifest } = await owner('src/formats/rdrr/validation.js');
const { KERNEL_REF_CONTENT_DIGESTS } = await owner('src/config/kernels/kernel-ref-digests.js');
const [source, target, receiptPath] = process.argv.slice(2);
assert(source && target && receiptPath && source !== target);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const originalBytes = await fs.readFile(path.join(source, 'manifest.json'));
const original = JSON.parse(originalBytes);
assert.equal(sha(originalBytes), '6bd380101b72d79aa05c23d51783a9faab9505808d63c4bd86520e95d255c03c');
assert.equal(original.inference.execution.kernels.w8a8.kernel, 'matmul_w8a8.wgsl');
const derivative = structuredClone(original);
const kernel = derivative.inference.execution.kernels.w8a8;
kernel.kernel = 'matmul_w8a8_packed.wgsl';
kernel.digest = 'sha256:' + KERNEL_REF_CONTENT_DIGESTS[kernel.kernel + '#' + kernel.entry];
assert(!kernel.digest.endsWith('undefined'));
const identity = structuredClone(original.artifactIdentity);
delete identity.conversionConfigPath;
delete identity.conversionConfigDigest;
delete identity.manifestVariantId;
const manifestConfig = { artifactIdentity: identity };
derivative.artifactIdentity = await buildArtifactIdentity({ explicitArtifactIdentity: identity,
  modelId: original.modelId, modelType: original.modelType, inference: derivative.inference,
  quantizationInfo: original.quantizationInfo, manifestConfig, hashString: sha });
assert.notEqual(derivative.artifactIdentity.manifestVariantId, original.artifactIdentity.manifestVariantId);
const validation = validateManifest(derivative);
assert.equal(validation.valid, true, JSON.stringify(validation));
await fs.mkdir(target);
const artifacts = [];
for (const entry of await fs.readdir(source, { withFileTypes: true })) {
  assert(entry.isFile(), 'Diagnostic source has unexpected nested entries');
  if (entry.name === 'manifest.json') continue;
  const bytes = await fs.readFile(path.join(source, entry.name));
  await fs.copyFile(path.join(source, entry.name), path.join(target, entry.name));
  const copied = await fs.readFile(path.join(target, entry.name));
  assert.equal(sha(copied), sha(bytes));
  artifacts.push({ path: entry.name, bytes: bytes.length, sha256: sha(bytes) });
}
const derivedBytes = Buffer.from(JSON.stringify(derivative, null, 2) + '\n');
await fs.writeFile(path.join(target, 'manifest.json'), derivedBytes);
assert.equal(sha(await fs.readFile(path.join(source, 'manifest.json'))), sha(originalBytes));
const receipt = { schema: 'doppler.w8a8-packed-diagnostic-derivation/v1', source, target,
  sourceManifestSha256: sha(originalBytes), derivedManifestSha256: sha(derivedBytes),
  scope: 'Diagnostic manifest derivation only; no conversion postflight, quality qualification, or promotion.',
  originalArtifactIdentity: original.artifactIdentity, derivedArtifactIdentity: derivative.artifactIdentity,
  manifestConfig, originalKernel: original.inference.execution.kernels.w8a8, derivedKernel: kernel,
  removedProvenanceFields: ['conversionConfigPath', 'conversionConfigDigest'], validation, artifacts };
await fs.mkdir(path.dirname(receiptPath), { recursive: true });
await fs.writeFile(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({ target, manifestSha256: receipt.derivedManifestSha256, files: artifacts.length, validation }));
