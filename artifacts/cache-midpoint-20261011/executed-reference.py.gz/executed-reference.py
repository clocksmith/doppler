#!/usr/bin/env python3
"""Independent, offline Transformers control using identified deployed RDRR weights.

This diagnostic never changes Run or activates an acceptance reference. Q4_K
unpacking comes from gguf; model equations come from Transformers. The explicit
KV boundary matches the deployed F16 storage with F32 attention arithmetic.
"""
import argparse
import base64
from contextlib import contextmanager, nullcontext
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path

import blake3
import numpy as np
import torch
from gguf import GGMLQuantizationType, dequantize
from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig
from transformers.models.qwen3_5.modeling_qwen3_5 import (
    DynamicCache, Qwen3_5ForCausalLM, Qwen3_5TextRotaryEmbedding, torch_recurrent_gated_delta_rule,
    Qwen3_5RMSNorm,
)


def read_json(path):
    data = Path(path).read_bytes()
    return json.loads(gzip.decompress(data) if data[:2] == b'\x1f\x8b' else data)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tree_rms_normalize(value, epsilon):
    """Offline F32 reduction-order control for declared 256-lane main RMSNorm.

    Products and additions round separately to F32; inverse root rounds once
    to F32. This is a sensitivity control, not a GPU-instruction emulator or
    permission to replace either accepted reference or runtime arithmetic.
    """
    assert value.device.type == 'cpu' and value.dtype == torch.float32
    x = value.detach().numpy()
    assert x.shape[-1] > 0 and np.isfinite(x).all() and epsilon > 0
    width, lanes = x.shape[-1], 256
    per_lane = (width + lanes - 1) // lanes
    padded = np.zeros((*x.shape[:-1], lanes * per_lane), dtype=np.float32)
    padded[..., :width] = x
    groups = padded.reshape(*x.shape[:-1], lanes, per_lane)
    partial = np.zeros(groups.shape[:-1], dtype=np.float32)
    for offset in range(per_lane):
        partial = partial + groups[..., offset] * groups[..., offset]
    stride = lanes // 2
    while stride:
        partial = partial[..., :stride] + partial[..., stride:stride * 2]
        stride //= 2
    variance = partial / np.float32(width) + np.float32(epsilon)
    inverse = (1 / np.sqrt(variance.astype(np.float64))).astype(np.float32)
    return torch.from_numpy(x * inverse)


class ObservedCacheControl:
    """Offline intervention on cache operands; never an independent oracle."""
    def __init__(self, model, capture):
        self.history, self.positions = {}, {}
        for index, layer in enumerate(model.model.layers):
            if not hasattr(layer, 'self_attn'):
                continue
            shape = (model.config.num_key_value_heads, layer.self_attn.head_dim)
            pair = []
            for name in ['k_rope', 'v_proj']:
                parts = [capture_values(row.get('capture'))
                         for row in capture['observation']['timeline']
                         if row['opId'] == f'layer.{index}.attn.{name}']
                assert parts and all(part is not None for part in parts), 'missing cache history'
                values = np.concatenate(parts).reshape(-1, *shape).astype(np.float16)
                assert values.size and np.isfinite(values).all(), 'invalid cache history'
                pair.append(torch.from_numpy(values.transpose(1, 0, 2).copy()).unsqueeze(0))
            assert pair[0].shape == pair[1].shape, 'unequal cache histories'
            self.history[index], self.positions[index] = pair, 0
        assert self.history, 'no captured attention cache'

    def take(self, index, keys, values):
        assert keys.shape == values.shape and keys.shape[0] == 1
        assert index in self.history, 'uncaptured cache layer'
        start, count = self.positions[index], keys.shape[-2]
        pair = [value[:, :, start:start + count] for value in self.history[index]]
        assert all(value.shape == keys.shape for value in pair), 'incomplete cache history'
        self.positions[index] += count
        return pair

    def assert_consumed(self):
        assert all(self.positions[index] == pair[0].shape[-2]
                   for index, pair in self.history.items()), 'unused cache history'


class StoredHalfCache(DynamicCache):
    def __init__(self, *args, observe_storage=False, observed_control=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.storage_observations = {} if observe_storage else None
        self.observed_control = observed_control

    def update(self, key_states, value_states, layer_idx, *args, **kwargs):
        if self.storage_observations is not None:
            history = self.storage_observations.setdefault(layer_idx, {'k_rope': [], 'v_proj': []})
            for name, value in [('k_rope', key_states), ('v_proj', value_states)]:
                history[name].append(value.detach().cpu().numpy()[0].transpose(1, 0, 2).copy())
        if self.observed_control is not None:
            key_states, value_states = self.observed_control.take(layer_idx, key_states, value_states)
        keys, values = super().update(key_states.half(), value_states.half(), layer_idx, *args, **kwargs)
        return keys.float(), values.float()


def compare_storage_rounding(source, observed):
    """Separate pre-storage differences from F16 rounding amplification."""
    assert source.shape == observed.shape and source.size
    assert np.isfinite(source).all() and np.isfinite(observed).all()
    source_half, observed_half = source.astype(np.float16), observed.astype(np.float16)
    assert np.isfinite(source_half).all() and np.isfinite(observed_half).all()
    before = np.abs(source.astype(np.float64) - observed.astype(np.float64))
    after = np.abs(source_half.astype(np.float64) - observed_half.astype(np.float64))
    changed = source_half != observed_half
    lower = np.minimum(source_half, observed_half)
    upper = np.maximum(source_half, observed_half)
    adjacent = changed & (np.nextafter(lower, np.float16(np.inf)) == upper)
    return {'values': int(source.size), 'differentStoredValues': int(changed.sum()),
            'adjacentStoredValues': int(adjacent.sum()),
            'preStorageMaxAbsError': float(before.max()),
            'postStorageMaxAbsError': float(after.max()),
            'amplifiedValues': int(np.count_nonzero(after > before)),
            'maxAddedAbsoluteError': float(np.maximum(after - before, 0).max())}


def compare(actual, encoded):
    expected = np.frombuffer(base64.b64decode(encoded), dtype='<f4')
    assert expected.shape == actual.shape and np.isfinite(actual).all()
    assert np.isfinite(expected).all()
    error = np.abs(actual - expected)
    return {'maxAbsError': float(error.max()), 'rmsError': float(np.sqrt(np.mean(error.astype(np.float64) ** 2))),
            'sampledToken': int(actual.argmax()), 'comparedValues': int(actual.size),
            'withinTolerance': bool(error.max() <= 0.001)}


def capture_values(capture):
    if not capture:
        return None
    if capture.get('data') is not None:
        return np.asarray(capture['data'], dtype=np.float32)
    if capture.get('dataBase64') is not None:
        assert capture.get('encoding') == 'base64-f32le'
        return np.frombuffer(base64.b64decode(capture['dataBase64'], validate=True), dtype='<f4')
    return None


def compare_cache_midpoints(gpu, source, gpu_precise, source_precise):
    """Separate local rounding from inherited operands, with independent F64 math.

    Float64 values use each implementation's own incoming operands. A difference
    between their rounded F64 results is inherited at this operation boundary;
    this does not decide whether an earlier operation was correct.
    """
    arrays = [np.asarray(value, dtype=np.float64) for value in
              (gpu, source, gpu_precise, source_precise)]
    gpu, source, gp, sp = arrays
    assert gpu.size and all(value.shape == gpu.shape and np.isfinite(value).all()
                            for value in arrays), 'invalid midpoint operands'
    rounded = [value.astype(np.float16) for value in arrays]
    assert all(np.isfinite(value).all() for value in rounded), 'nonfinite half result'
    gh, sh, gph, sph = [value.astype(np.float64) for value in rounded]
    different = gh != sh
    inherited = gph != sph
    gpu_local, source_local = gh != gph, sh != sph
    coords = np.argwhere(different)
    # Retain a bounded selection: largest observed cache difference, stable order.
    order = np.argsort(-np.abs(gh[different] - sh[different]), kind='stable')[:16]
    samples = []
    for offset in order:
        coordinate = tuple(coords[offset])
        lo, hi = sorted((gh[coordinate], sh[coordinate]))
        adjacent = bool(float(np.nextafter(np.float16(lo), np.float16(np.inf))) == hi)
        samples.append({'coordinate': list(map(int, coordinate)),
                        'gpu': float(gpu[coordinate]), 'source': float(source[coordinate]),
                        'gpuFloat64': float(gp[coordinate]), 'sourceFloat64': float(sp[coordinate]),
                        'gpuStored': float(gh[coordinate]), 'sourceStored': float(sh[coordinate]),
                        'gpuFloat64Stored': float(gph[coordinate]), 'sourceFloat64Stored': float(sph[coordinate]),
                        'adjacent': adjacent, 'midpoint': float((lo + hi) / 2) if adjacent else None})
    return {'values': int(gpu.size), 'differentStoredValues': int(different.sum()),
            'gpuLocalMaxAbsError': float(np.max(np.abs(gpu - gp))),
            'sourceLocalMaxAbsError': float(np.max(np.abs(source - sp))),
            'inheritedOperandMaxAbsEffect': float(np.max(np.abs(gp - sp))),
            'crossingCounts': {
                'inheritedRoundingDifference': int((different & inherited).sum()),
                'sameFloat64Rounding': int((different & ~inherited).sum()),
                'gpuDiffersFromOwnFloat64Rounding': int((different & gpu_local).sum()),
                'sourceDiffersFromOwnFloat64Rounding': int((different & source_local).sum()),
                'bothMatchOwnFloat64Rounding': int((different & ~gpu_local & ~source_local).sum())},
            'samples': samples}


def precise_text_rope(value, theta, rotary_dim):
    """Independent F64 rotate-half equation for contiguous text positions from zero."""
    x = np.asarray(value, dtype=np.float64)
    assert x.ndim == 3 and np.isfinite(x).all()
    assert theta > 0 and 0 < rotary_dim <= x.shape[-1] and rotary_dim % 2 == 0
    half = rotary_dim // 2
    angles = np.arange(x.shape[0], dtype=np.float64)[:, None] / (
        theta ** (np.arange(half, dtype=np.float64) * 2 / rotary_dim))
    cosine, sine = np.cos(angles)[:, None, :], np.sin(angles)[:, None, :]
    result = x.copy()
    result[..., :half] = x[..., :half] * cosine - x[..., half:rotary_dim] * sine
    result[..., half:rotary_dim] = x[..., half:rotary_dim] * cosine + x[..., :half] * sine
    return result


class CacheProducerAudit:
    """Read-only first-full-attention history; hooks never replace source outputs."""
    def __init__(self, model):
        self.model = model
        self.index = next(index for index, layer in enumerate(model.model.layers)
                          if hasattr(layer, 'self_attn'))
        layer = model.model.layers[self.index]
        self.modules = {'post_input_norm': layer.input_layernorm,
                        **{name: getattr(layer.self_attn, name) for name in ['k_proj', 'v_proj', 'k_norm']}}
        self.history = {name: [] for name in self.modules}

    @contextmanager
    def observe(self):
        handles = []
        def hook(name):
            def retain(_module, _inputs, output):
                self.history[name].append(output.detach().float().numpy().copy())
            return retain
        try:
            for name, module in self.modules.items():
                handles.append(module.register_forward_hook(hook(name)))
            yield
        finally:
            for handle in handles:
                handle.remove()

    def compare(self, capture, cache):
        model, index = self.model, self.index
        attention = model.model.layers[index].self_attn
        heads, dim = model.config.num_key_value_heads, attention.head_dim
        def gpu_history(name, width):
            parts = [capture_values(row.get('capture')) for row in capture['observation']['timeline']
                     if row['opId'] == f'layer.{index}.attn.{name}']
            assert parts and all(part is not None for part in parts), 'missing cache producer history'
            return np.concatenate(parts).reshape(-1, width).astype(np.float64)
        gpu = {name: gpu_history(name, model.config.hidden_size if name == 'post_input_norm' else heads * dim)
               for name in [*self.modules, 'k_rope']}
        source = {name: np.concatenate([part.reshape(-1, gpu[name].shape[-1]) for part in parts])
                  for name, parts in self.history.items()}
        source['k_rope'] = np.concatenate(cache.storage_observations[index]['k_rope']).reshape(-1, heads * dim)
        assert all(source[name].shape == values.shape for name, values in gpu.items()), 'incomplete cache producer history'
        checks = []
        for name in ['k_proj', 'v_proj']:
            module = getattr(attention, name)
            assert module.bias is None
            weight = module.weight.detach().float().numpy().astype(np.float64)
            gp, sp = [values['post_input_norm'] @ weight.T for values in [gpu, source]]
            checks.append({'boundary': name, 'inputBoundary': 'post_input_norm',
                           **compare_cache_midpoints(gpu[name], source[name], gp, sp)})
        def norm(values):
            x = values['k_proj'].reshape(-1, heads, dim).astype(np.float64)
            weight = attention.k_norm.weight.detach().float().numpy().astype(np.float64)
            return (x / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + attention.k_norm.eps)
                    * (1 + weight)).reshape(-1, heads * dim)
        checks.append({'boundary': 'k_norm', 'inputBoundary': 'k_proj',
                       **compare_cache_midpoints(gpu['k_norm'], source['k_norm'], norm(gpu), norm(source))})
        params = model.config.rope_parameters
        assert params['rope_type'] == 'default', 'midpoint audit requires unscaled text RoPE'
        rotary_dim = int(dim * params['partial_rotary_factor'])
        gp, sp = [precise_text_rope(values['k_norm'].reshape(-1, heads, dim),
                                   params['rope_theta'], rotary_dim).reshape(-1, heads * dim)
                  for values in [gpu, source]]
        checks.append({'boundary': 'k_rope', 'inputBoundary': 'k_norm',
                       **compare_cache_midpoints(gpu['k_rope'], source['k_rope'], gp, sp)})
        return {'layer': index, 'tokens': gpu['k_rope'].shape[0], 'kvHeads': heads, 'headDim': dim,
                'scope': 'Independent Float64 equations on each implementation\'s own captured operands; no model qualification',
                'coordinates': '[text position, flattened key/value head coordinate]',
                'rounding': 'F16 nearest-even; only v_proj and k_rope are actual storage boundaries',
                'checks': checks}


def compare_physical_cache(capture, layers, kv_heads, head_dim):
    """Compare direct GPU cache readbacks with independently rounded inputs.

    This certifies only storage/conversion/indexing at captured boundaries.
    Source-model numerical accuracy remains a separate question.
    """
    observation = capture['observation']
    rows = observation['physicalCache']
    target = observation['target']['step']
    assert observation['maximumUnmaskedDifference'] == 0
    assert len(observation['prefixDifferences']) == target + 1
    assert all(row['maximumUnmaskedDifference'] == 0 for row in observation['prefixDifferences'])
    assert len(rows) == len(layers) * (target + 1), 'missing or duplicate physical cache readback'
    physical = {(row['step'], row['layer']): row for row in rows}
    assert len(physical) == len(rows), 'duplicate physical cache boundary'
    history = {layer: {'k': [], 'v': []} for layer in layers}
    current = -1
    inputs = {}
    for row in observation['timeline']:
        if row['opId'] == 'embed.out':
            current += 1
        for layer in layers:
            for name, op in [('k', 'k_rope'), ('v', 'v_proj')]:
                if row['opId'] == f'layer.{layer}.attn.{op}':
                    values = capture_values(row.get('capture'))
                    assert values is not None and np.isfinite(values).all()
                    key = (current, layer, name)
                    assert key not in inputs, 'duplicate pre-storage input'
                    inputs[key] = np.asarray(values, dtype=np.float32).reshape(-1, kv_heads, head_dim)
    assert current == target, 'pre-storage capture must cover every selected prefix'
    comparisons = []
    for step in range(target + 1):
        for layer in layers:
            physical_row = physical[(step, layer)]
            assert physical_row['dtype'] == 'f16' and physical_row['layout'] == 'contiguous'
            assert physical_row['byteOffset'] == 0
            assert physical_row['reads'], 'actual attention cache read required'
            if step:
                previous = physical[(step - 1, layer)]
                assert physical_row['seqLen'] == previous['seqLen'] + 1
                assert (physical_row['keysId'], physical_row['valuesId']) == (previous['keysId'], previous['valuesId'])
            for read in physical_row['reads']:
                assert read['seqLen'] == physical_row['seqLen']
                assert (read['keysId'], read['valuesId']) == (physical_row['keysId'], physical_row['valuesId'])
            for name in ['k', 'v']:
                history[layer][name].append(inputs[(step, layer, name)])
                expected = np.concatenate(history[layer][name]).astype('<f2')
                assert list(expected.shape) == physical_row['shape']
                assert expected.shape[0] == physical_row['seqLen']
                assert expected.nbytes == physical_row['byteLength']
                value = physical_row['values'][name]
                assert value['encoding'] == 'base64-f16le'
                data = base64.b64decode(value['dataBase64'], validate=True)
                assert len(data) == expected.nbytes
                actual = np.frombuffer(data, dtype='<f2').reshape(expected.shape)
                assert np.isfinite(actual).all()
                different = actual.view('<u2') != expected.view('<u2')
                indices = np.argwhere(different)
                comparisons.append({'step': step, 'layer': layer, 'cache': name,
                                    'shape': list(actual.shape), 'values': actual.size,
                                    'differentBits': int(different.sum()),
                                    'firstMismatch': indices[0].tolist() if len(indices) else None,
                                    'maxAbs': float(np.max(np.abs(actual.astype(np.float64) - expected.astype(np.float64))))})
    return {'scope': 'Physical F16 cache storage and subsequent read identity; not independent model qualification',
            'passed': all(row['differentBits'] == 0 for row in comparisons), 'comparisons': comparisons}


def compare_attention_history(model, capture, cache):
    """Compare observed attention against its actual captured cache operands.

    Reconstruct only history emitted by this capture. Missing tokens or shapes
    reject the diagnostic rather than substituting independently evolved state.
    No reconstructed value is fed back into either execution.
    """
    timeline = capture['observation']['timeline']
    layer_indices = sorted({int(row['opId'].split('.')[1]) for row in timeline
                            if row['opId'].startswith('layer.')
                            and row['opId'].endswith('.attn.core_out')
                            and capture_values(row.get('capture')) is not None})
    comparisons = []
    for index in layer_indices:
        attention = model.model.layers[index].self_attn
        head_dim = attention.head_dim
        kv_heads = model.config.num_key_value_heads
        heads = model.config.num_attention_heads
        prefix = f'layer.{index}.attn.'
        histories = {'k_rope': [], 'v_proj': []}
        last = {}
        for row in timeline:
            if row['opId'] == 'embed.out':
                last = {}
            if not row['opId'].startswith(prefix):
                continue
            data = capture_values(row.get('capture'))
            if data is None:
                continue
            name = row['opId'][len(prefix):]
            values = np.asarray(data, dtype=np.float32)
            assert np.isfinite(values).all(), row['opId']
            last[name] = values
            if name in histories:
                histories[name].append(values.reshape(-1, kv_heads, head_dim))
        query = last['q_rope'].reshape(-1, heads, head_dim)
        # This boundary diagnostic intentionally requires a single decode token.
        assert query.shape[0] == 1, 'attention history requires a decode capture'
        actual = last['core_out'].reshape(heads, head_dim).astype(np.float64)
        stored = {name: np.concatenate(parts).astype(np.float16)
                  for name, parts in histories.items()}
        reference_layer = cache.layers[index]
        cache_rows = []
        source_stored = {}
        for name, source in [('k_rope', reference_layer.keys), ('v_proj', reference_layer.values)]:
            source = source.detach().cpu().numpy()[0].transpose(1, 0, 2)
            source_stored[name] = source.astype(np.float64)
            observed = stored[name]
            assert source.dtype == observed.dtype == np.float16
            assert source.shape == observed.shape, 'capture must include complete cache history'
            error = np.abs(source.astype(np.float64) - observed.astype(np.float64))
            cache_rows.append({'boundary': prefix + name, 'tokens': int(source.shape[0]),
                               'values': int(source.size),
                               'differentStoredValues': int(np.count_nonzero(source != observed)),
                               'maxAbsError': float(error.max()),
                               'rmsError': float(np.sqrt(np.mean(error ** 2))),
                               'sourceCacheSha256': hashlib.sha256(source.copy().tobytes()).hexdigest(),
                               'capturedCacheSha256': hashlib.sha256(observed.tobytes()).hexdigest()})
            observations = getattr(cache, 'storage_observations', None)
            if observations is not None:
                before = np.concatenate(observations[index][name])
                cache_rows[-1]['rounding'] = compare_storage_rounding(before, np.concatenate(histories[name]))
        keys = np.repeat(stored['k_rope'].astype(np.float64), heads // kv_heads, axis=1)
        values = np.repeat(stored['v_proj'].astype(np.float64), heads // kv_heads, axis=1)
        scores = np.einsum('hd,thd->ht', query[0].astype(np.float64), keys) * attention.scaling
        scores -= scores.max(axis=-1, keepdims=True)
        probabilities = np.exp(scores)
        probabilities /= probabilities.sum(axis=-1, keepdims=True)
        precise = np.einsum('ht,thd->hd', probabilities, values)
        # Counterfactual diagnostic: hold the observed query fixed and substitute
        # independently evolved cache operands. Nothing feeds either execution.
        source_keys = np.repeat(source_stored['k_rope'], heads // kv_heads, axis=1)
        source_values = np.repeat(source_stored['v_proj'], heads // kv_heads, axis=1)
        source_scores = np.einsum('hd,thd->ht', query[0].astype(np.float64), source_keys) * attention.scaling
        source_scores -= source_scores.max(axis=-1, keepdims=True)
        source_probabilities = np.exp(source_scores)
        source_probabilities /= source_probabilities.sum(axis=-1, keepdims=True)
        source_precise = np.einsum('ht,thd->hd', source_probabilities, source_values)
        error = np.abs(actual - precise)
        comparisons.append({'boundary': prefix + 'core_out',
                            'scope': 'Captured query and full captured K/V history, F16 storage, float64 reference',
                            'values': int(actual.size), 'tokens': int(keys.shape[0]),
                            'maxAbsError': float(error.max()),
                            'rmsError': float(np.sqrt(np.mean(error ** 2))),
                            'cacheOnlyOutputMaxAbsDifference': float(np.abs(source_precise - precise).max()),
                            'independentlyEvolvedCache': cache_rows})
    return comparisons


def compare_linear_history(model, capture, layer_index=0):
    """Offline float64 source equations over one layer's captured projection history.

    This replays convolution and recurrence from zero, not from independently
    evolved model inputs. It neither observes nor replaces live GPU state.
    """
    layer = model.model.layers[layer_index].linear_attn
    prefix = f'layer.{layer_index}.attn.'
    dimensions = {'qkv_proj': layer.conv_dim, 'linear_z_proj': layer.value_dim,
                  'linear_a_proj': layer.num_v_heads, 'linear_b_proj': layer.num_v_heads,
                  'linear_core_out': layer.value_dim}
    history = {name: [] for name in dimensions}
    for row in capture['observation']['timeline']:
        name = row['opId'].removeprefix(prefix)
        if name not in history:
            continue
        values = capture_values(row.get('capture'))
        assert values is not None and np.isfinite(values).all(), row['opId']
        history[name].append(values.reshape(-1, dimensions[name]).astype(np.float64))
    lengths = [[len(batch) for batch in batches] for batches in history.values()]
    assert lengths[0] and all(length == lengths[0] for length in lengths), 'incomplete linear history'
    inputs = {name: np.concatenate(batches) for name, batches in history.items()}

    def weight(value):
        return value.detach().cpu().numpy().astype(np.float64)

    conv_weight = weight(layer.conv1d.weight).squeeze(1)
    conv_state = np.zeros_like(conv_weight)
    state = np.zeros((layer.num_v_heads, layer.head_k_dim, layer.head_v_dim))
    norm_weight = weight(layer.norm.weight)
    a_log, dt_bias = weight(layer.A_log), weight(layer.dt_bias)
    assert layer.num_v_heads % layer.num_k_heads == 0
    outputs = []
    for index, projected in enumerate(inputs['qkv_proj']):
        conv_state[:, :-1] = conv_state[:, 1:]
        conv_state[:, -1] = projected
        mixed = np.sum(conv_state * conv_weight, axis=-1)
        mixed = mixed / (1 + np.exp(-mixed))
        query, key, value = np.split(mixed, [layer.key_dim, 2 * layer.key_dim])
        query = query.reshape(layer.num_k_heads, layer.head_k_dim)
        key = key.reshape(layer.num_k_heads, layer.head_k_dim)
        value = value.reshape(layer.num_v_heads, layer.head_v_dim)
        # Transformers' gated delta rule explicitly uses l2norm epsilon 1e-6.
        query /= np.sqrt(np.sum(query ** 2, axis=-1, keepdims=True) + 1e-6)
        key /= np.sqrt(np.sum(key ** 2, axis=-1, keepdims=True) + 1e-6)
        repeats = layer.num_v_heads // layer.num_k_heads
        query = np.repeat(query, repeats, axis=0) / np.sqrt(layer.head_k_dim)
        key = np.repeat(key, repeats, axis=0)
        beta = 1 / (1 + np.exp(-inputs['linear_b_proj'][index]))
        decay = np.exp(-np.exp(a_log) * np.logaddexp(0, inputs['linear_a_proj'][index] + dt_bias))
        state *= decay[:, None, None]
        memory = np.sum(state * key[:, :, None], axis=1)
        delta = (value - memory) * beta[:, None]
        state += key[:, :, None] * delta[:, None, :]
        output = np.sum(state * query[:, :, None], axis=1)
        output /= np.sqrt(np.mean(output ** 2, axis=-1, keepdims=True) + layer.norm.variance_epsilon)
        gate = inputs['linear_z_proj'][index].reshape(layer.num_v_heads, layer.head_v_dim)
        output *= norm_weight * gate / (1 + np.exp(-gate))
        outputs.append(output.reshape(-1))
    precise = np.stack(outputs)
    error = np.abs(precise - inputs['linear_core_out'])
    assert np.isfinite(error).all()
    return {'boundary': prefix + 'linear_core_out',
            'scope': 'Captured projection history, zero initial state, float64 source equations',
            'tokens': len(outputs), 'values': int(error.size),
            'maxAbsError': float(error.max()), 'lastTokenMaxAbsError': float(error[-1].max()),
            'rmsError': float(np.sqrt(np.mean(error ** 2)))}


def compare_linear_histories(model, capture):
    indices = sorted({int(row['opId'].split('.')[1])
                      for row in capture['observation']['timeline']
                      if row['opId'].startswith('layer.')
                      and row['opId'].endswith('.attn.linear_core_out')
                      and capture_values(row.get('capture')) is not None})
    return [compare_linear_history(model, capture, index) for index in indices]


def compare_boundaries(model, capture, input_ids, cache, producer_audit=None):
    """Observe the selected prefix; hooks never replace model values."""
    retained = {}
    timeline = capture['observation']['timeline']
    start = max(index for index, row in enumerate(timeline) if row['opId'] == 'embed.out')
    for row in timeline[start:]:
        values = capture_values(row.get('capture'))
        if values is not None:
            retained[row['opId']] = {**row['capture'], 'data': values}
    modules = {'embed.out': model.model.embed_tokens, 'final_norm.out': model.model.norm}
    for index, layer in enumerate(model.model.layers):
        modules[f'layer.{index}.attn.post_input_norm'] = layer.input_layernorm
        modules[f'layer.{index}.layer.out'] = layer
        modules[f'layer.{index}.ffn.in'] = layer.post_attention_layernorm
        modules[f'layer.{index}.ffn.out'] = layer.mlp
    modules['logits.out'] = model.lm_head
    layer = model.model.layers[0]
    for name, module in {
        'attn.qkv_proj': layer.linear_attn.in_proj_qkv,
        'attn.linear_z_proj': layer.linear_attn.in_proj_z,
        'attn.linear_a_proj': layer.linear_attn.in_proj_a,
        'attn.linear_b_proj': layer.linear_attn.in_proj_b,
        'attn.out': layer.linear_attn.out_proj,
        'ffn.in': layer.post_attention_layernorm,
        'ffn.gate': layer.mlp.gate_proj,
        'ffn.up': layer.mlp.up_proj,
        'ffn.out': layer.mlp.down_proj,
    }.items():
        modules['layer.0.' + name] = module
    attention = model.model.layers[3].self_attn
    for name in ['q_proj', 'k_proj', 'v_proj', 'q_norm', 'k_norm', 'o_proj']:
        boundary = 'out' if name == 'o_proj' else name
        if 'layer.3.attn.' + boundary in retained:
            modules['layer.3.attn.' + boundary] = getattr(attention, name)
    comparisons, handles = [], []

    def observe(name):
        def hook(_module, _inputs, value):
            if isinstance(value, tuple):
                value = value[0]
            if name == 'layer.3.attn.q_proj':
                value = value.reshape(-1, model.config.num_attention_heads, attention.head_dim * 2)[..., :attention.head_dim]
            actual = value.detach().float().cpu().numpy().reshape(-1)
            expected = np.asarray(retained[name]['data'], dtype=np.float32)
            assert actual.shape == expected.shape, name
            error = np.abs(actual - expected)
            assert np.isfinite(error).all(), name
            comparisons.append({'boundary': name, 'values': int(actual.size),
                                'maxAbsError': float(error.max()),
                                'rmsError': float(np.sqrt(np.mean(error.astype(np.float64) ** 2))),
                                'actualSha256': hashlib.sha256(actual.tobytes()).hexdigest()})
        return hook

    operands = []
    def compare_operand(name, input_name, module, kind):
        if name not in retained:
            return
        assert input_name in retained, f'Missing operand {input_name} for {name}'
        x = np.asarray(retained[input_name]['data'], dtype=np.float32).reshape(-1, module.weight.shape[-1])
        expected = np.asarray(retained[name]['data'], dtype=np.float32).reshape(-1)
        native = module(torch.from_numpy(x.copy())).detach().float().numpy().reshape(-1)
        weight = module.weight.detach().float().numpy().astype(np.float64)
        precise_input = x.astype(np.float64)
        if kind == 'rmsnorm':
            precise = precise_input / np.sqrt(np.mean(precise_input ** 2, axis=-1, keepdims=True) + module.eps)
            precise *= (1 + weight)
        else:
            assert module.bias is None
            precise = precise_input @ weight.T
        precise = precise.reshape(-1)
        assert expected.shape == native.shape == precise.shape
        operands.append({'boundary': name, 'inputBoundary': input_name, 'operation': kind,
                         'values': int(expected.size),
                         'gpuVsFloat64': float(np.max(np.abs(expected.astype(np.float64) - precise))),
                         'sourceF32VsFloat64': float(np.max(np.abs(native.astype(np.float64) - precise))),
                         'gpuVsSourceF32SameOperands': float(np.max(np.abs(expected - native)))})

    try:
        for name, module in modules.items():
            if name not in retained:
                continue  # Fused decode kernels need not expose unfused FFN intermediates.
            handles.append(module.register_forward_hook(observe(name)))
        with producer_audit.observe() if producer_audit else nullcontext():
            output = model(input_ids=input_ids, past_key_values=cache, use_cache=True, logits_to_keep=1)
        assert len(comparisons) == len(handles)
        for handle in handles:
            handle.remove()
        handles.clear()
        for index, layer in enumerate(model.model.layers):
            compare_operand(f'layer.{index}.attn.post_input_norm',
                            'embed.out' if index == 0 else f'layer.{index - 1}.layer.out',
                            layer.input_layernorm, 'rmsnorm')
        compare_operand('final_norm.out', 'final_norm.pre', model.model.norm, 'rmsnorm')
        compare_operand('logits.out', 'final_norm.out', model.lm_head, 'linear')
        for index, layer in enumerate(model.model.layers):
            name, input_name = f'layer.{index}.ffn.out', f'layer.{index}.ffn.in'
            if name not in retained:
                continue
            assert input_name in retained, f'Missing operand {input_name} for {name}'
            x = np.asarray(retained[input_name]['data'], dtype=np.float32).reshape(-1, model.config.hidden_size)
            native = layer.mlp(torch.from_numpy(x.copy())).detach().float().numpy().reshape(-1)
            def weight(module):
                assert module.bias is None
                return module.weight.detach().float().numpy().astype(np.float64)
            gate = x.astype(np.float64) @ weight(layer.mlp.gate_proj).T
            up = x.astype(np.float64) @ weight(layer.mlp.up_proj).T
            precise = ((gate * np.exp(-np.logaddexp(0, -gate))) * up) @ weight(layer.mlp.down_proj).T
            expected = np.asarray(retained[name]['data'], dtype=np.float64).reshape(-1)
            precise = precise.reshape(-1)
            assert expected.shape == native.shape == precise.shape and np.isfinite(precise).all()
            operands.append({'boundary': name, 'inputBoundary': input_name, 'operation': 'swiglu-ffn',
                             'values': int(expected.size),
                             'gpuVsFloat64': float(np.max(np.abs(expected - precise))),
                             'sourceF32VsFloat64': float(np.max(np.abs(native.astype(np.float64) - precise))),
                             'gpuVsSourceF32SameOperands': float(np.max(np.abs(expected - native)))})
        for name in ['qkv_proj', 'linear_z_proj', 'linear_a_proj', 'linear_b_proj']:
            compare_operand('layer.0.attn.' + name, 'layer.0.attn.post_input_norm',
                            modules['layer.0.attn.' + name], 'linear')
        for name in ['gate', 'up']:
            if 'layer.0.ffn.' + name not in retained:
                continue
            compare_operand('layer.0.ffn.' + name, 'layer.0.ffn.in', modules['layer.0.ffn.' + name], 'linear')
        if 'layer.3.attn.k_rope' in retained:
            for name in ['k_proj', 'v_proj']:
                compare_operand('layer.3.attn.' + name, 'layer.3.attn.post_input_norm', getattr(attention, name), 'linear')
            compare_operand('layer.3.attn.q_norm', 'layer.3.attn.q_proj', attention.q_norm, 'rmsnorm')
            compare_operand('layer.3.attn.k_norm', 'layer.3.attn.k_proj', attention.k_norm, 'rmsnorm')
        history = compare_attention_history(model, capture, cache) if input_ids.shape[-1] == 1 else []
        return output, comparisons, operands, [name for name in modules if name not in retained], history
    finally:
        for handle in handles:
            handle.remove()


def replay_generation(model, config, manifest, args, report):
    """Independent greedy replay of an identified deployed generation receipt."""
    from tokenizers import Tokenizer
    control = read_json(args.generation_control)
    assert control['modelIdentity'] == report['modelIdentity']
    settings = control['input']['generation']
    assert settings['temperature'] == 0 and settings['topK'] == 1 and settings['topP'] == 1
    assert settings['presencePenalty'] == 0 and settings['stopSequences'] == []
    assert settings['suppressTokenIds'] == [] and settings['repetitionPenaltyWindow'] == 0
    tokenizer = Tokenizer.from_file(str(Path(args.model) / 'tokenizer.json'))
    prompt = control['result']['tokenIds']
    assert tokenizer.encode(tokenizer.decode(prompt, skip_special_tokens=False), add_special_tokens=False).ids == prompt
    expected = control['result']['evidence']['tokenIds']
    assert len(prompt) + settings['maxTokens'] <= settings['maxSeqLen']
    report.update({'schema': 'doppler.source-generation-diagnostic/v1',
                   'generationControlSha256': sha256(args.generation_control),
                   'tokenization': 'Exact captured IDs; independently round-tripped through deployed tokenizer',
                   'inputIds': prompt, 'settings': settings, 'eosTokenIds': manifest['eos_token_id'],
                   'generatedTokenIds': [], 'firstTokenDivergence': None, 'stopReason': None})
    cache = StoredHalfCache(config=config)
    history = list(prompt)
    input_ids = prompt
    for step in range(settings['maxTokens']):
        with torch.inference_mode():
            result = model(input_ids=torch.tensor([input_ids]), past_key_values=cache, use_cache=True, logits_to_keep=1)
            logits = result.logits[0, -1].float().numpy().copy()
        assert np.isfinite(logits).all()
        # Independent scalar expression of the declared full-history repetition penalty.
        for token in set(history):
            value = float(logits[token])
            logits[token] = value / settings['repetitionPenalty'] if value > 0 else value * settings['repetitionPenalty']
        if config.pad_token_id is not None:
            logits[config.pad_token_id] = -np.inf
        token = int(logits.argmax())
        report['generatedTokenIds'].append(token)
        if report['firstTokenDivergence'] is None and (step >= len(expected) or token != expected[step]):
            report['firstTokenDivergence'] = {'step': step, 'sourceToken': token,
                                              'dopplerToken': expected[step] if step < len(expected) else None}
        history.append(token)
        input_ids = [token]
        if token in manifest['eos_token_id']:
            report['stopReason'] = 'eos'
        elif step + 1 == settings['maxTokens']:
            report['stopReason'] = 'max-tokens'
        if step % 32 == 0 or report['stopReason']:
            report['outputText'] = tokenizer.decode(report['generatedTokenIds'], skip_special_tokens=True)
            Path(args.out).write_text(json.dumps(report) + '\n')
            print(json.dumps({'step': step, 'token': token, 'stopReason': report['stopReason'],
                              'firstTokenDivergence': report['firstTokenDivergence'],
                              'textTail': report['outputText'][-100:]}), flush=True)
        if report['stopReason']:
            break
    return report


def run(args):
    torch.set_num_threads(args.threads)
    root = Path(args.model)
    manifest = read_json(root / 'manifest.json')
    observed = read_json(args.capture)
    assert observed['manifestIdentity'] == 'sha256:' + sha256(root / 'manifest.json')
    assert manifest['inference']['session']['compute']['defaults']['activationDtype'] == 'f32'
    assert manifest['inference']['session']['kvcache']['kvDtype'] == 'f16'
    source = read_json(args.source_config)['text_config']
    assert source['hidden_size'] == manifest['architecture']['hiddenSize']
    assert source['layer_types'] == manifest['inference']['layerPattern']['layerTypes']
    assert source['rms_norm_eps'] == manifest['inference']['normalization']['rmsNormEps']
    config = Qwen3_5TextConfig(**source)
    # The deployed LM head is separately quantized; retying would change weights.
    config.tie_word_embeddings = False
    config.dtype = 'float32'
    config._attn_implementation = 'eager'
    with torch.device('meta'):
        model = Qwen3_5ForCausalLM(config)
    model.model.rotary_emb = Qwen3_5TextRotaryEmbedding(config, device='cpu')
    wanted = model.state_dict()
    shards, weights, identities = {}, {}, []
    pieces = read_json(args.piece_index)
    assert 'sha256:' + sha256(args.piece_index) == args.piece_index_identity
    files = {entry['path']: entry for entry in pieces['files']}
    tokenizer_bytes = (root / 'tokenizer.json').read_bytes()
    assert len(tokenizer_bytes) == files['tokenizer.json']['size']
    for piece in files['tokenizer.json']['pieces']:
        block = tokenizer_bytes[piece['offset']:piece['offset'] + piece['size']]
        assert 'sha256:' + hashlib.sha256(block).hexdigest() == piece['identity']
    assert manifest['hashAlgorithm'] == 'blake3'
    for index, shard in enumerate(manifest['shards']):
        filename = root / shard['filename']
        data = filename.read_bytes()
        assert len(data) == shard['size'] == files[shard['filename']]['size']
        cursor = 0
        for piece in files[shard['filename']]['pieces']:
            assert piece['offset'] == cursor
            block = data[cursor:cursor + piece['size']]
            assert 'sha256:' + hashlib.sha256(block).hexdigest() == piece['identity']
            cursor += piece['size']
        assert cursor == len(data)
        shards[index] = data
        identities.append({'filename': shard['filename'], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                           'legacyManifestHash': shard['hash'], 'standardBlake3': blake3.blake3(data).hexdigest()})
    for name, entry in manifest['tensors'].items():
        if not name.startswith('model.language_model.'):
            continue
        key = name.replace('model.language_model.', 'model.', 1)
        if key == 'model.lm_head.weight':
            key = 'lm_head.weight'
        assert key in wanted, key
        spans = entry.get('spans') or [{'shardIndex': entry['shard'], 'offset': entry['offset'], 'size': entry['size']}]
        data = b''.join(shards[x['shardIndex']][x['offset']:x['offset'] + x['size']] for x in spans)
        assert len(data) == entry['size']
        if entry['dtype'] == 'Q4_K_M':
            assert entry['layout'] == 'row'
            array = dequantize(np.frombuffer(data, dtype=np.uint8).copy(), GGMLQuantizationType.Q4_K)
        else:
            assert entry['dtype'] in ('F16', 'F32')
            array = np.frombuffer(data, dtype='<f2' if entry['dtype'] == 'F16' else '<f4').astype(np.float32)
        weights[key] = torch.from_numpy(array.copy().reshape(wanted[key].shape))
    del shards
    model.load_state_dict(weights, strict=True, assign=True)
    del weights
    model.eval()
    if args.normalization == 'source-tree':
        assert manifest['inference']['execution']['kernels']['rmsnorm']['entry'] == 'main'
        for module in model.modules():
            if isinstance(module, Qwen3_5RMSNorm):
                module._norm = lambda x, eps=module.eps: tree_rms_normalize(x, eps)
    if args.linear_prefill == 'source-recurrent':
        # Independent source sensitivity control, never a runtime substitution.
        # Both functions implement the same recurrence with different F32 order.
        for layer in model.model.layers:
            if hasattr(layer, 'linear_attn'):
                layer.linear_attn.chunk_gated_delta_rule = torch_recurrent_gated_delta_rule
    report = {'schema': 'doppler.source-model-reference-diagnostic/v1', 'qualified': False,
              'scope': 'Independent model-equation diagnostic, not reference activation or runtime fallback',
              'linearPrefillReference': args.linear_prefill,
              'normalizationReference': args.normalization,
              'tolerance': 0.001, 'tokenization': 'Exact captured prompt IDs, followed by frozen reference tokens',
              'modelIdentity': observed['manifestIdentity'], 'sourceConfigSha256': sha256(args.source_config),
              'captureSha256': sha256(args.capture), 'pieceIndexIdentity': args.piece_index_identity,
              'pieceIndexManifestIdentity': pieces['manifestIdentity'],
              'integrityScope': 'Pinned SHA-256 pieces, separate from the retained legacy shard hash implementation', 'toolSha256': sha256(__file__),
              'tokenizerSha256': sha256(root / 'tokenizer.json'), 'shards': identities,
              'versions': {name: importlib.metadata.version(name) for name in ['torch', 'transformers', 'gguf', 'numpy']},
              'precision': {'arithmetic': 'float32', 'kvStorage': 'float16', 'weights': 'exact deployed bytes decoded to float32'},
              'results': []}
    if args.generation_control:
        return replay_generation(model, config, manifest, args, report)
    reference = read_json(args.reference)
    reference_bytes = Path(args.reference).read_bytes()
    reference_bytes = gzip.decompress(reference_bytes) if reference_bytes[:2] == b'\x1f\x8b' else reference_bytes
    assert observed['referenceSha256'] == hashlib.sha256(reference_bytes).hexdigest()
    report['referenceSha256'] = observed['referenceSha256']
    targets = observed['results'][:args.prefixes]
    assert len(targets) == args.prefixes
    boundary_capture = read_json(args.boundary_capture) if args.boundary_capture else None
    if boundary_capture:
        target = targets[-1]
        bound = boundary_capture.get('observationTarget', {'index': 0, 'step': 0})
        assert (target['index'], target['step']) == (bound['index'], bound['step'])
        matching = [row for row in boundary_capture['results']
                    if row['index'] == target['index'] and row['step'] == target['step']][-1]
        assert matching['inputIds'] == target['inputIds']
        assert matching['logits'] == target['logits']
        report['boundaryCaptureSha256'] = sha256(args.boundary_capture)
        report['boundaryCaptureManifestIdentity'] = boundary_capture['manifestIdentity']
        assert boundary_capture['manifestIdentity'] == observed['manifestIdentity']
    observed_control = None
    if args.observed_cache_control:
        assert boundary_capture, 'observed cache control requires a boundary capture'
        observed_control = ObservedCacheControl(model, boundary_capture)
        report['scope'] = 'Captured-cache counterfactual; not independent numerical qualification'
        report['observedCacheControl'] = {'requestIndex': targets[-1]['index'],
                                          'layers': sorted(observed_control.history)}
    producer_audit = None
    if args.cache_midpoint_audit:
        assert boundary_capture and not args.observed_cache_control, 'midpoint audit requires independent source state'
        producer_audit = CacheProducerAudit(model)
    cache, active_request, next_step = None, None, 0
    for target in targets:
        if target['step'] == 0:
            active_request, next_step = target['index'], 0
            selected = target['index'] == targets[-1]['index']
            cache = StoredHalfCache(config=config, observe_storage=bool(boundary_capture and selected),
                                    observed_control=observed_control if selected else None)
            input_ids = target['inputIds']
        else:
            input_ids = [reference['expected'][target['index']]['steps'][target['step'] - 1]['tokenId']]
        assert active_request == target['index'] and next_step == target['step']
        next_step += 1
        with torch.inference_mode():
            if boundary_capture and target is targets[-1]:
                result, report['boundaryComparisons'], report['operandComparisons'], report['unobservedBoundaries'], report['attentionHistoryComparisons'] = compare_boundaries(
                    model, boundary_capture, torch.tensor([input_ids]), cache, producer_audit)
                report['linearHistoryComparisons'] = compare_linear_histories(model, boundary_capture)
                report['linearHistoryComparison'] = next((row for row in report['linearHistoryComparisons']
                                                         if row['boundary'] == 'layer.0.attn.linear_core_out'), None)
            else:
                with producer_audit.observe() if producer_audit and selected else nullcontext():
                    result = model(input_ids=torch.tensor([input_ids]), past_key_values=cache,
                                   use_cache=True, logits_to_keep=1)
            output = result.logits[0, -1].float().numpy().copy()
        row = {'index': target['index'], 'step': target['step'], 'ordinal': target['ordinal'],
               'inputIds': input_ids, 'comparison': compare(output, target['logits']),
               'logitsSha256': hashlib.sha256(output.tobytes()).hexdigest(),
               'logits': base64.b64encode(output.astype('<f4').tobytes()).decode()}
        report['results'].append(row)
        Path(args.out).write_text(json.dumps(report) + '\n')
        print(json.dumps({key: value for key, value in row.items() if key != 'logits'}), flush=True)
    if observed_control is not None:
        observed_control.assert_consumed()
        report['observedCacheControl']['completeHistoryConsumed'] = True
        Path(args.out).write_text(json.dumps(report) + '\n')
    if producer_audit is not None:
        report['cacheProducerMidpoints'] = producer_audit.compare(boundary_capture, cache)
        Path(args.out).write_text(json.dumps(report) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ['model', 'source-config', 'capture', 'out', 'reference', 'piece-index', 'piece-index-identity']:
        parser.add_argument('--' + field, required=True)
    parser.add_argument('--prefixes', type=int, required=True)
    parser.add_argument('--threads', type=int, required=True)
    parser.add_argument('--generation-control', help='Replay exact deployed greedy generation with independent source equations')
    parser.add_argument('--linear-prefill', choices=['source-chunk', 'source-recurrent'], default='source-chunk',
                        help='Independent source recurrence ordering sensitivity; never reference activation')
    parser.add_argument('--normalization', choices=['source', 'source-tree'], default='source',
                        help='Offline normalization reduction-order control; never runtime or reference activation')
    parser.add_argument('--boundary-capture', help='Retained GPU observations for the last requested prefix')
    parser.add_argument('--observed-cache-control', action='store_true',
                        help='Offline captured-cache intervention; cannot qualify independent accuracy')
    parser.add_argument('--cache-midpoint-audit', action='store_true',
                        help='Offline first-attention cache producer history; separate local and inherited rounding')
    options = parser.parse_args()
    assert options.prefixes > 0 and options.threads > 0
    assert not (options.observed_cache_control and options.generation_control)
    assert not (options.cache_midpoint_audit and (options.observed_cache_control or options.generation_control))
    run(options)
