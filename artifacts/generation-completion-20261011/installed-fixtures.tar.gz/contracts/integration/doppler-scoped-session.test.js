import assert from 'node:assert/strict';
import { test } from 'node:test';

import { createScopedModelSession } from '../../node_modules/doppler-gpu/src/client/runtime/scoped-session.js';

function makeHandle(overrides = {}) {
  let unloaded = 0;
  const evidence = {
    outputText: 'hello',
    tokenIds: [1, 2],
    resolution: {
      schema: 'doppler.resolution-identity/v1',
      logicalModelId: 'fixture-logical',
      resolvedArtifactVariantId: `sha256:${'a'.repeat(64)}`,
      resolvedExecutionId: `sha256:${'b'.repeat(64)}`,
    },
    runtimeProfile: {
      model: {
        modelId: 'fixture-model',
        manifestHash: 'sha256:manifest',
      },
    },
    runtimeProfileHash: 'sha256:runtime',
    backendIdentityHash: 'sha256:backend',
    backendIdentity: {
      executionPlanId: 'primary',
      kernelPathId: 'fixture-path',
    },
    stats: null,
  };
  const handle = {
    modelId: 'fixture-model',
    manifestHash: 'sha256:manifest',
    manifest: { modelId: 'fixture-model' },
    loaded: true,
    supportsEmbedding: false,
    supportsSequence: false,
    activeLoRA: null,
    deviceInfo: { vendor: 'fixture' },
    advanced: { tokenizeText: () => [1] },
    async generateWithEvidence() {
      return evidence;
    },
    async *generate() {
      yield 'hel';
      yield 'lo';
    },
    async embed() {
      return { embedding: [1, 2] };
    },
    async encodeSequence() {
      return { embedding: [3, 4] };
    },
    async loadLoRA() {},
    async unloadLoRA() {},
    resetGenerationState() {},
    async unload() {
      unloaded += 1;
      handle.loaded = false;
    },
    get unloadCount() {
      return unloaded;
    },
    inspect: {
      async generate(_prompt, options = {}) {
        const modifiesExecution = options.policyId !== 'demo/always-on';
        return {
          schema: 'doppler.model-inspection-receipt/v1',
          policy: {
            id: options.policyId,
            modifiesExecution,
          },
          fingerprint: {
            schema: 'doppler.comparison-fingerprint/v1',
            fullDigest: 'sha256:fingerprint',
            executionPlanId: 'primary',
          },
          outputText: 'hello',
          generatedTokenIds: [1, 2],
          wallTimingMs: 1,
          performanceRepresentative: !modifiesExecution,
          tokens: modifiesExecution ? [{ tokenId: 1, surprisal: 0.5 }] : [],
          quality: modifiesExecution ? { words: [] } : null,
          generationEvidence: evidence,
        };
      },
    },
    ...overrides,
  };
  return handle;
}

test('scoped session exposes explicit capabilities and stable results', async () => {
  const handle = makeHandle();
  const session = createScopedModelSession(handle);
  assert.equal(session.supports('generate'), true);
  assert.equal(session.require('generate'), true);

  const result = await session.generate('prompt');
  assert.equal(result.schema, 'doppler.generation-result/v1');
  assert.equal(result.outputText, 'hello');
  assert.equal(result.observation.executionClassification, 'representative');
  assert.equal(result.observation.executionChanged, false);
  assert.equal(result.resolution.logicalModelId, 'fixture-logical');
  assert.equal(result.resolution.resolvedArtifactVariantId, `sha256:${'a'.repeat(64)}`);
  assert.equal(result.resolution.resolvedExecutionId, `sha256:${'b'.repeat(64)}`);
  assert.equal(result.fingerprint.executionPlanId, 'primary');
  assert.equal(session.logicalModelId, 'fixture-model');
  assert.equal(session.manifest.modelId, 'fixture-model');
});

test('stream emits semantic events instead of return-dependent unions', async () => {
  const session = createScopedModelSession(makeHandle());
  const events = [];
  for await (const event of session.stream('prompt')) events.push(event);
  assert.deepEqual(events.map((event) => event.type), ['text-delta', 'text-delta', 'complete']);
  assert.equal(events.at(-1).outputText, 'hello');
  assert.equal(events.at(-1).completion, null);
});

test('scoped completion preserves declared stopping reasons and raw token counts', async () => {
  for (const stopReason of ['max-tokens', 'eos-token', 'stop-token', 'stop-sequence']) {
    const stats = { stopReason, prefillTokens: 4, tokensGenerated: 7 };
    const base = makeHandle();
    const evidence = await base.generateWithEvidence();
    const session = createScopedModelSession(makeHandle({
      inspect: null,
      advanced: { getStats: () => stats },
      generateWithEvidence: async () => ({ ...evidence, tokenIds: [1, 2, 3, 4, 5, 6, 7], stats }),
      async *generate() { yield ''; yield 'answer'; },
    }));
    const events = [];
    for await (const event of session.stream('prompt')) events.push(event);
    const expected = { schema: 'doppler.generation-completion/v1', stopReason,
      promptTokenCount: 4, generatedTokenCount: 7 };
    assert.deepEqual(events.at(-1).completion, expected);
    assert.deepEqual((await session.generate('prompt')).completion, expected);
    stats.tokensGenerated = 99;
    assert.equal(events.at(-1).completion.generatedTokenCount, 7);
  }
});

test('scoped stream never invents completion on failure or early consumer return', async () => {
  const events = [];
  const session = createScopedModelSession(makeHandle({ async *generate() { yield 'partial'; throw new Error('cancelled'); } }));
  await assert.rejects(async () => { for await (const event of session.stream('prompt')) events.push(event); }, /cancelled/);
  assert.deepEqual(events.map(event => event.type), ['text-delta']);
  const iterator = createScopedModelSession(makeHandle()).stream('prompt');
  assert.equal((await iterator.next()).value.type, 'text-delta');
  assert.equal((await iterator.return()).done, true);
});

test('scoped completion rejects invalid reasons or counters instead of inferring EOS', async () => {
  for (const stats of [{ stopReason: 'invented', prefillTokens: 1, tokensGenerated: 1 },
    { stopReason: 'max-tokens', prefillTokens: 1, tokensGenerated: -1 }]) {
    const session = createScopedModelSession(makeHandle({ advanced: { getStats: () => stats } }));
    await assert.rejects(async () => { for await (const _event of session.stream('prompt')) {} }, /stopping metadata/);
  }
});

test('specialized models reject generation and streaming capabilities', async () => {
  for (const flags of [{ supportsEmbedding: true }, { supportsSequence: true }]) {
    const session = createScopedModelSession(makeHandle(flags));
    assert.throws(() => session.require('generate'), /does not support/);
    assert.throws(() => session.require('stream'), /does not support/);
    await assert.rejects(session.generate('prompt'), /does not support/);
  }
});

test('unsupported observation policies fail closed on a generation session', async () => {
  const session = createScopedModelSession(makeHandle());
  await assert.rejects(
    session.generate('prompt', { observe: 'mystery-mode' }),
    /Unsupported Doppler observation policy/
  );
});

test('close is idempotent and blocks later work', async () => {
  const handle = makeHandle();
  const session = createScopedModelSession(handle);
  await session.close();
  await session.close();
  assert.equal(handle.unloadCount, 1);
  assert.equal(session.closed, true);
  await assert.rejects(session.generate('prompt'), /session is closed/);
});

test('concurrent close and disposal wait for the same unload', async () => {
  const unloading = Promise.withResolvers();
  let unloadCount = 0;
  const session = createScopedModelSession(makeHandle({
    async unload() {
      unloadCount += 1;
      await unloading.promise;
    },
  }));
  const first = session.close();
  const second = session.close();
  const disposal = session[Symbol.asyncDispose]();
  let secondFinished = false;
  second.then(() => { secondFinished = true; });
  try {
    await Promise.resolve();
    assert.equal(session.closed, true, 'closing immediately rejects new work');
    await assert.rejects(session.generate('prompt'), /session is closed/);
    assert.equal(secondFinished, false, 'close cannot report completion before resources are released');
  } finally {
    unloading.resolve();
    await Promise.all([first, second, disposal]);
  }
  assert.equal(unloadCount, 1);
});

test('every close caller observes the original unload failure without retrying cleanup', async () => {
  for (const synchronous of [false, true]) {
    const unloading = Promise.withResolvers();
    const failure = new Error('unload failed');
    let unloadCount = 0;
    const session = createScopedModelSession(makeHandle({
      unload() {
        unloadCount += 1;
        if (synchronous) throw failure;
        return unloading.promise;
      },
    }));
    const first = assert.rejects(session.close(), error => error === failure);
    const second = assert.rejects(session.close(), error => error === failure);
    const disposal = assert.rejects(session[Symbol.asyncDispose](), error => error === failure);
    if (!synchronous) unloading.reject(failure);
    await Promise.all([first, second, disposal]);
    await assert.rejects(session.close(), error => error === failure);
    assert.equal(unloadCount, 1);
  }
});

test('guided and deep inspection disclose non-representative execution', async () => {
  const session = createScopedModelSession(makeHandle());
  const guided = await session.inspect('prompt');
  assert.equal(guided.policy.id, 'demo/guided-quality');
  assert.equal(guided.policy.modifiesExecution, true);
  assert.ok(guided.quality);
  const deep = await session.inspect('prompt', {
    observationPolicy: 'deep-xray',
  });
  assert.equal(deep.policy.id, 'demo/deep-xray');
});
