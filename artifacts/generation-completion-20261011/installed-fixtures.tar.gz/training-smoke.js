import { getTrainingCapabilities, TRAINING_BACKENDS } from 'doppler-gpu/training';
const capabilities = getTrainingCapabilities({ kind: 'lora', baseModelId: 'qwen-3-5-0-8b-q4k-ehaf16', pipeline: { datasetFormat: 'text-pairs', taskType: 'text_generation' } });
if (!capabilities.supported || capabilities.backends.webgpuNative.supported || !capabilities.backends.external.supported) throw new Error('training capability contract mismatch');
if (TRAINING_BACKENDS.join(',') !== 'webgpu_native,external') throw new Error('training backend registry mismatch');
console.log('package training API smoke passed');
